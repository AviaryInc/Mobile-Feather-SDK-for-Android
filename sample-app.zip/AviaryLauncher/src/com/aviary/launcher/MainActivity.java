package com.aviary.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore.Images;
import android.provider.MediaStore.Images.ImageColumns;
import android.provider.MediaStore.Images.Media;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.aviary.android.feather.FeatherActivity;
import com.aviary.android.feather.library.utils.ImageLoader;

public class MainActivity extends Activity {

	private static final int ACTION_REQUEST_GALLERY = 99;
	private static final int ACTION_REQUEST_FEATHER = 100;
	private static final int EXTERNAL_STORAGE_UNAVAILABLE = 1;

	/**
	 * apikey and apisecret are required to use the remote effect api for more informations and to obtain your key/secret pair go to
	 * http://developers.aviary.com/geteffectskey
	 */
	private static final String API_KEY = "d2703c903";
	private static final String API_SECRET = "f9c23bc20";

	private static final String FOLDER_NAME = "aviary";
	protected static final String LOG_TAG = "feather";
	
	Button mButton;
	Button mButton2;
	ImageView mImage;
	File mOutputFile;
	View mImageContainer;
	Uri mImageUri;
	int imageWidth, imageHeight;
	private File mGalleryFolder;
	private Handler mHandler = new Handler();

	@Override
	protected void onCreate( Bundle savedInstanceState ) {
		super.onCreate( savedInstanceState );
		setContentView( R.layout.main );

		DisplayMetrics metrics = getResources().getDisplayMetrics();
		imageWidth = metrics.widthPixels;
		imageHeight = metrics.heightPixels;
		
		mButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				pickFromGallery();
			}
		} );

		mButton2.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mImageUri != null ) {
					startFeather( mImageUri );
				}
			}
		} );

		mImageContainer.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				Uri uri = pickRandomImage();
				if ( uri != null ) {
					Log.d( LOG_TAG, "image uri: " + uri );
					mImageUri = uri;
					setImageURI( mImageUri );
				}
			}
		} );

		Toast.makeText( this, "launcher: " + getLibraryVersion() + ", sdk: " + FeatherActivity.SDK_VERSION, Toast.LENGTH_SHORT )
				.show();

		mGalleryFolder = createFolders();
	}
	
	@Override
	protected void onResume() {
		super.onResume();
		
		if ( getIntent() != null ) {
			handleIntent( getIntent() );
			setIntent( new Intent() );
		}
	}

	private void handleIntent( Intent intent ) {

		String action = intent.getAction();

		if ( null != action ) {

			if ( Intent.ACTION_SEND.equals( action ) ) {

				Bundle extras = intent.getExtras();
				if ( extras != null && extras.containsKey( Intent.EXTRA_STREAM ) ) {
					Uri uri = (Uri) extras.get( Intent.EXTRA_STREAM );
					loadAsync( uri );
				}
			} else if( Intent.ACTION_VIEW.equals( action )) {
				Uri data = intent.getData();
				Log.d( LOG_TAG, "data: " + data );
				loadAsync( data );
			}
		}
	}
	
	private void loadAsync( final Uri uri ){
		
		final Runnable r = new Runnable() {
			
			@Override
			public void run() {
				int w = mImageContainer.getWidth();
				Log.d( LOG_TAG, "width: " + w );
				if( w > 0 )
				{
					mHandler.post( new Runnable() {
						
						@Override
						public void run() {
							mImageUri = uri;
							setImageURI( mImageUri );
						}
					} );
				} else {
					loadAsync( uri );
				}
			}
		};
		
		mHandler.post( r );
		
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();

		if ( mOutputFile != null ) {
			Log.d( LOG_TAG, "deleting: " + mOutputFile.getAbsolutePath() );
			mOutputFile.delete();
			mOutputFile = null;
		}
	}

	@Override
	public void onContentChanged() {
		super.onContentChanged();

		mButton = (Button) findViewById( R.id.button1 );
		mButton2 = (Button) findViewById( R.id.button2 );
		mImage = ( (ImageView) findViewById( R.id.image ) );
		mImageContainer = findViewById( R.id.image_container );
	}

	@Override
	public boolean onCreateOptionsMenu( Menu menu ) {
		MenuInflater inflater = getMenuInflater();
		inflater.inflate( R.menu.main_menu, menu );
		return true;
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item ) {

		Intent intent;

		final int id = item.getItemId();

		if ( id == R.id.view_documentation ) {
			intent = new Intent( Intent.ACTION_VIEW );
			intent.setData( Uri.parse( "http://developers.aviary.com/android-sdk" ) );
			startActivity( intent );
		} else if ( id == R.id.get_sdk ) {

			intent = new Intent( Intent.ACTION_VIEW );
			intent.setData( Uri.parse( "https://github.com/AviaryInc/Mobile-Feather-SDK-for-Android" ) );
			startActivity( intent );
		}
		return super.onOptionsItemSelected( item );
	}

	@Override
	protected Dialog onCreateDialog( int id ) {
		Dialog dialog = null;
		switch ( id ) {
			case EXTERNAL_STORAGE_UNAVAILABLE:
				dialog = new AlertDialog.Builder( this ).setTitle( R.string.external_storage_na_title )
						.setMessage( R.string.external_storage_na_message ).create();
				break;
		}
		return dialog;
	}

	@Override
	public void onActivityResult( int requestCode, int resultCode, Intent data ) {
		if ( resultCode == RESULT_OK ) {
			switch ( requestCode ) {
				case ACTION_REQUEST_GALLERY:
					// user chose an image from the gallery
					mImageUri = data.getData();
					setImageURI( mImageUri );
					break;

				case ACTION_REQUEST_FEATHER:
					// feather activity result
					// this is the same uri passed to feather in the startActivity
					// intent as "output"
					mImageUri = data.getData();

					// replace the current image with the new one
					setImageURI( mImageUri );

					// save the image to the user gallery
					saveToGallery( mImageUri );
					mOutputFile = null;
					break;
			}
		} else if ( resultCode == RESULT_CANCELED ) {
			switch ( requestCode ) {
				case ACTION_REQUEST_FEATHER:
					// feather was canceled, so delete the previously created file
					if ( mOutputFile != null ) {
						Log.d( LOG_TAG, "deleting: " + mOutputFile.getAbsolutePath() );
						mOutputFile.delete();
						mOutputFile = null;
					}
					break;
			}
		}
	}

	/**
	 * Given an Uri load the bitmap into the current ImageView and resize it to fit the image container size
	 * 
	 * @param uri
	 */
	private void setImageURI( Uri uri ) {
		
		Drawable toRecycle = mImage.getDrawable();
		if ( toRecycle != null && toRecycle instanceof BitmapDrawable ) {
			if ( ( (BitmapDrawable) mImage.getDrawable() ).getBitmap() != null )
				( (BitmapDrawable) mImage.getDrawable() ).getBitmap().recycle();
		}
		

		Bitmap bitmap;
		try {
			imageWidth = mImageContainer.getWidth() - ( mImageContainer.getPaddingLeft() + mImageContainer.getPaddingRight() );
			imageHeight = mImageContainer.getHeight() - ( mImageContainer.getPaddingTop() + mImageContainer.getPaddingBottom() );
			Log.d( LOG_TAG, "destSize: " + imageWidth + "x" + imageHeight );
			bitmap = ImageLoader.loadFromUri( this, uri, imageWidth, imageHeight, null );
			Log.d( LOG_TAG, "image size: " + bitmap.getWidth() + "x" + bitmap.getHeight() );
			mImage.setImageBitmap( bitmap );
			mImage.setBackgroundDrawable( null );
		} catch ( IOException e ) {
			e.printStackTrace();
		}

		mButton2.setEnabled( true );
	}
	
	/**
	 * Given an Uri save the bitmap into the user gallery
	 * 
	 * @param uri
	 */
	private void saveToGallery( Uri uri ) {
		ContentValues values = new ContentValues( 3 );
		values.put( Media.DESCRIPTION, "Created with Aviary!" );
		values.put( Media.MIME_TYPE, "image/jpeg" );
		values.put( Media.BUCKET_DISPLAY_NAME, "Aviary Feather" );

		Uri result = getContentResolver().insert( Media.EXTERNAL_CONTENT_URI, values );
		try {
			OutputStream output = getContentResolver().openOutputStream( result );
			FileInputStream input = new FileInputStream( uri.getPath() );

			byte[] buf = new byte[1024];
			int len;
			while ( ( len = input.read( buf ) ) > 0 ) {
				output.write( buf, 0, len );
			}
			input.close();
			output.close();

			// Notify the system of the newly created image
			getContentResolver().notifyChange( result, null );

		} catch ( Exception e ) {
			e.printStackTrace();
		}

		Toast.makeText( this, "Image saved into " + uri.getPath(), Toast.LENGTH_SHORT ).show();
	}

	/**
	 * Pick a random image from the user gallery
	 * 
	 * @return
	 */
	private Uri pickRandomImage() {
		Cursor c = getContentResolver().query( Images.Media.EXTERNAL_CONTENT_URI, new String[] { ImageColumns.DATA },
				ImageColumns.SIZE + ">?", new String[] { "90000" }, null );
		Uri uri = null;
		if ( c != null ) {
			int total = c.getCount();
			int position = (int) ( Math.random() * total );
			Log.d( LOG_TAG, "pickRandomImage. total images: " + total + ", position: " + position );
			if ( total > 0 ) {
				if ( c.moveToPosition( position ) ) {
					String data = c.getString( c.getColumnIndex( Images.ImageColumns.DATA ) );
					uri = Uri.parse( data );
					Log.d( LOG_TAG, uri.toString() );
				}
			}
			c.close();
		}
		return uri;
	}

	/**
	 * Return the current application version string
	 * 
	 * @return
	 */
	private String getLibraryVersion() {
		String result = "";

		try {
			PackageManager manager = getPackageManager();
			PackageInfo info = manager.getPackageInfo( getPackageName(), 0 );
			result = info.versionName;
		} catch ( Exception e ) {}

		return result;
	}

	/**
	 * Once you've chosen an image you can start the feather activity
	 * 
	 * @param uri
	 */
	private void startFeather( Uri uri ) {

		Log.d( LOG_TAG, "uri: " + uri );

		// first check the external storage availability
		if ( !isExternalStorageAvilable() ) {
			showDialog( EXTERNAL_STORAGE_UNAVAILABLE );
			return;
		}

		// create a temporary file where to store the resulting image
		try {
			File file = new File( mGalleryFolder, "aviary_" + System.currentTimeMillis() + ".jpg" );
			file.createNewFile();
			mOutputFile = file;
		} catch ( IOException e ) {
			e.printStackTrace();
			new AlertDialog.Builder( this ).setTitle( android.R.string.dialog_alert_title ).setMessage( e.getMessage() ).show();
			return;
		}

		// Create the intent needed to start feather
		Intent newIntent = new Intent( this, FeatherActivity.class );

		// set the source image uri
		newIntent.setData( uri );

		// pass the required api_key and secret ( see
		// http://developers.aviary.com/geteffectskey )
		newIntent.putExtra( "API_KEY", API_KEY );
		newIntent.putExtra( "API_SECRET", API_SECRET );

		// pass the uri of the destination image file (optional)
		// This will be the same uri you will receive in the onActivityResult
		newIntent.putExtra( "output", Uri.parse( "file://" + mOutputFile.getAbsolutePath() ) );

		// format of the destination image (optional)
		newIntent.putExtra( "output-format", Bitmap.CompressFormat.JPEG.name() );

		// output format quality (optional)
		newIntent.putExtra( "output-quality", 85 );

		// you can force feather to display only a certain
		// newIntent.putExtra( "tools-list", new String[]{"CROP", "ROTATE", "EFFECTS", "STICKERS" } );

		// you want the result bitmap inline. (optional)
		// newIntent.putExtra( Constants.EXTRA_RETURN_DATA, true );

		// you want to hide the exit alert dialog shown when back is pressed
		// without saving image first
		// newIntent.putExtra( Constants.EXTRA_HIDE_EXIT_UNSAVE_CONFIRMATION, true );

		// ..and start feather
		startActivityForResult( newIntent, ACTION_REQUEST_FEATHER );
	}

	/**
	 * Check the external storage status
	 * 
	 * @return
	 */
	private boolean isExternalStorageAvilable() {
		String state = Environment.getExternalStorageState();
		if ( Environment.MEDIA_MOUNTED.equals( state ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Start the activity to pick an image from the user gallery
	 */
	private void pickFromGallery() {
		Intent intent = new Intent( Intent.ACTION_GET_CONTENT );
		intent.setType( "image/*" );

		Intent chooser = Intent.createChooser( intent, "Choose a Picture" );
		startActivityForResult( chooser, ACTION_REQUEST_GALLERY );
	}

	private File createFolders() {

		File baseDir;

		if ( android.os.Build.VERSION.SDK_INT < 8 ) {
			baseDir = Environment.getExternalStorageDirectory();
		} else {
			baseDir = Environment.getExternalStoragePublicDirectory( Environment.DIRECTORY_PICTURES );
		}

		if ( baseDir == null ) return Environment.getExternalStorageDirectory();

		Log.d( LOG_TAG, "Pictures folder: " + baseDir.getAbsolutePath() );
		File aviaryFolder = new File( baseDir, FOLDER_NAME );

		if ( aviaryFolder.exists() ) return aviaryFolder;

		if ( aviaryFolder.mkdirs() ) return aviaryFolder;

		return Environment.getExternalStorageDirectory();
	}
}
