package com.aviary.launcher;

import android.content.Context;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.Process;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;



public final class BackgroundLooper {

	private Logger logger = LoggerFactory.getLogger( "background-looper", LoggerType.ConsoleLoggerType );
	private boolean running;
	private volatile Looper mServiceLooper;
	private InternalHandler mServiceHandler;
	private Context mContext;

	private HandlerThread thread = new HandlerThread( "hiresthread", Process.THREAD_PRIORITY_BACKGROUND );

	private final class InternalHandler extends Handler {

		public InternalHandler( Looper looper ) {
			super( looper );
		}

		@Override
		public void handleMessage( Message msg ) {
			super.handleMessage( msg );
		}
	}

	public BackgroundLooper( Context context ) {
		mContext = context;
		thread.start();
	}

	public void start() {
		if ( !running ) {
			mServiceLooper = thread.getLooper();
			mServiceHandler = new InternalHandler( mServiceLooper );
			running = true;
		}
	}

	public boolean isRunning() {
		return running;
	}

	public void stop() {
		running = false;
		mServiceLooper.quit();
	}

	public void sendMessage( final Message message ) {
		mServiceHandler.sendMessage( message );
	}

	public Message obtainMessage() {
		return mServiceHandler.obtainMessage();
	}

	public Message obtainMessage( int what ) {
		return mServiceHandler.obtainMessage( what );
	}
}