# Aviary Editor Standalone reference #


The Aviary Editor standalone application can be started using different Intent actions.

*	**android.intent.action.EDIT**

This is the default action used in android when an application requests a particular content to be edited. You can see an example in the new ICS gallery application. When user will click on the "edit" action menu button, if aviary editor is installed, android will ask which application should be used to edit that image.
In order to use this action, your intent must be created in this way:
	
	Intent intent = new Intent( Intent.ACTION_EDIT );
	intent.setDataAndType( uri, "image/*" );
	try {
		startActivityForResult( newIntent, ACTION_REQUEST_FEATHER );
	} catch( ActivityNotFoundException e ){
		e.printStackTrace();
	}
	
	

*	**android.intent.action.SEND**

This is the default action used in almost all the applications on sharing content.
The intent should be like this:
	
	Intent intent = new Intent( Intent.ACTION_SEND );
	intent.setType("image/*");
	intent.putExtra( Intent.EXTRA_STREAM, uri );
	
	try {
		startActivityForResult( newIntent, ACTION_REQUEST_FEATHER );
	} catch( ActivityNotFoundException e ){
		e.printStackTrace();
	}


*	**aviary.intent.action.EDIT**

In both the previous examples, if more than 1 image editing app is installed on the device, then android will present a choser dialog to the user and then the user can chose which application to use for that particular content.
If you want to start Aviary Editor directly you should use the following intent:
	
	Intent newIntent = new Intent( "aviary.intent.action.EDIT" );
	newIntent.setDataAndType( uri, "image/*" ); // required
	newIntent.putExtra( "API_KEY", "you api key" ); // required
	newIntent.putExtra( "app-id", getPackageName() ); // required ( it's your app unique package name )
	
	// optional, the destination file. if omitted then aviary editor will save the 
	// new image into the user camera album
	newIntent.putExtra( "output", Uri.parse( "file://" + mOutputFile.getAbsolutePath() ) ); 
	
	// optional, the destination file format
	newIntent.putExtra( "output-format", Bitmap.CompressFormat.JPEG.name() );
	
	// optional, the destination image quality ( only for jpegs )
	newIntent.putExtra( "output-quality", 90 );
	
	// optional, the list of tools to display
	newIntent.putExtra( "tools-list", new String[] {
		"ENHANCE", "EFFECTS", "STICKERS", "ADJUST", "CROP", "BRIGHTNESS", "CONTRAST", "SATURATION", "SHARPNESS", "DRAWING",
		"TEXT", "MEME", "RED_EYE", "WHITEN", "BLEMISH", } );
		
	try {
		startActivityForResult( newIntent, ACTION_REQUEST_FEATHER );
	} catch( ActivityNotFoundException e ){
		Toast.makeText( this, "Aviary Feather is not installed!", Toast.LENGTH_SHORT ).show();
		e.printStackTrace();
	}
	
	
	

Inside your app, if you want to check if Aviary Editor is currently installed on the user device you can use this code:

	public boolean isAviaryInstalled(){
		Intent intent = new Intent( "aviary.intent.action.EDIT" );
		intent.setType( "image/*" );
		List<ResolveInfo> list = getPackageManager().queryIntentActivities( intent, PackageManager.MATCH_DEFAULT_ONLY );  
		return list.size() > 0; 
	}

So, if the editor is not installed, you can send the user to the market:
	
	Intent intent = new Intent( Intent.ACTION_VIEW );
	intent.setData( Uri.parse( "market://details?id=com.aviary.android.feather" ) );
	startActivity( intent );
	