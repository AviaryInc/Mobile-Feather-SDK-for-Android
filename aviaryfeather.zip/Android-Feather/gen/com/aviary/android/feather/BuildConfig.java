/** Automatically generated file. DO NOT MODIFY */
package com.aviary.android.feather;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}