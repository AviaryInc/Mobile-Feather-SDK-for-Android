package it.sephiroth.android.library.imagezoom;

/**
 * A convenience class to extend when you only want to listen for a subset
 * of scaling-related events. This implements all methods in
 * {@link OnScaleGestureListener} but does nothing.
 * {@link OnScaleGestureListener#onScale(ScaleGestureDetector7)} returns
 * {@code false} so that a subclass can retrieve the accumulated scale
 * factor in an overridden onScaleEnd.
 * {@link OnScaleGestureListener#onScaleBegin(ScaleGestureDetector7)} returns
 * {@code true}.
 */
public class SimpleOnScaleGestureListener implements OnScaleGestureListener {

	@Override
	public boolean onScale( IScaleGestureDetector detector ) {
		return false;
	}

	@Override
	public boolean onScaleBegin( IScaleGestureDetector detector ) {
		return true;
	}

	@Override
	public void onScaleEnd( IScaleGestureDetector detector ) {
		// Intentionally empty
	}
}