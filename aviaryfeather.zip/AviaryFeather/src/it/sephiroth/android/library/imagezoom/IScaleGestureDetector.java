package it.sephiroth.android.library.imagezoom;

import android.view.MotionEvent;

public interface IScaleGestureDetector {

	public abstract boolean onTouchEvent( MotionEvent event );

	public abstract boolean isInProgress();

	public abstract float getCurrentSpan();

	public abstract float getPreviousSpan();

	public abstract float getScaleFactor();

	public abstract float getFocusX();

	public abstract float getFocusY();
}