package com.aviary.android.feather.utils;

import android.app.ProgressDialog;
import android.os.Handler;

import com.aviary.android.feather.MonitoredActivity;

public class ThreadUtils {

	public static void startBackgroundJob( MonitoredActivity activity, String title, String message, Runnable job, Handler handler ) {
		ProgressDialog dialog = ProgressDialog.show( activity, title, message, true, false );
		new Thread( new BackgroundJob( activity, job, dialog, handler ) ).start();
	}

	private static class BackgroundJob extends MonitoredActivity.LifeCycleAdapter implements Runnable {

		private final MonitoredActivity mActivity;
		private final ProgressDialog mDialog;
		private final Runnable mJob;
		private final Handler mHandler;
		private final Runnable mCleanupRunner = new Runnable() {

			@Override
			public void run() {
				mActivity.removeLifeCycleListener( BackgroundJob.this );
				if( mDialog.getWindow() != null )
					mDialog.dismiss();
			}
		};

		public BackgroundJob( MonitoredActivity activity, Runnable job, ProgressDialog dialog, Handler handler ) {
			mActivity = activity;
			mDialog = dialog;
			mJob = job;
			mActivity.addLifeCycleListener( this );
			mHandler = handler;
		}

		@Override
		public void run() {
			try {
				mJob.run();
			} finally {
				mHandler.post( mCleanupRunner );
			}
		}

		@Override
		public void onActivityDestroyed( MonitoredActivity activity ) {
			mCleanupRunner.run();
			mHandler.removeCallbacks( mCleanupRunner );
		}

		@Override
		public void onActivityStopped( MonitoredActivity activity ) {
			mDialog.hide();
		}

		@Override
		public void onActivityStarted( MonitoredActivity activity ) {
			mDialog.show();
		}
	}

}
