package com.aviary.android.feather.utils;

import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;


/**
 * Variuos UI utilities
 * 
 * @author alessandro
 *
 */
public class UIUtils {

	private static Context mContext;
	private static LayoutInflater mLayoutInflater;

	public static void init( Context context ){
		mContext = context;
		mLayoutInflater = (LayoutInflater) context.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
	}
	
	public static void showCustomToast( int viewResId )
	{
		showCustomToast( viewResId, Toast.LENGTH_SHORT );
	}
	
	public static void showCustomToast( int viewResId, int duration )
	{
		showCustomToast( viewResId, duration, Gravity.CENTER_HORIZONTAL|Gravity.BOTTOM );
	}
	
	/**
	 * Display a system Toast using a custom ui view 
	 * @param viewResId
	 * @param duration
	 * @param gravity
	 */
	public static void showCustomToast( int viewResId, int duration, int gravity )
	{
		View layout = mLayoutInflater.inflate( viewResId, null);

		Toast toast = new Toast( mContext.getApplicationContext() );
		
		toast.setGravity( gravity, 0, 0 );
		toast.setDuration( duration );
		toast.setView( layout );
		toast.show();
	}
	
}
