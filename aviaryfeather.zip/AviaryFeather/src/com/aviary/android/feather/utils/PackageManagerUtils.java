package com.aviary.android.feather.utils;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;


public class PackageManagerUtils {
	
	private static ApplicationInfo mInfo;

	public static synchronized ApplicationInfo getApplicationInfo( Context context ) {
		
		if( mInfo == null )
		{
			PackageManager manager = context.getPackageManager();
			try {
				mInfo = manager.getApplicationInfo( context.getPackageName(), 0 );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
		}
		
		return mInfo;
	}
}
