package com.aviary.android.feather.utils;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;


public class PackageManagerUtils {

	public static String getApplicationName( Context context ) {
		PackageManager manager = context.getPackageManager();
		
		if( manager == null )
			return "";
		
		try {
			PackageInfo info = manager.getPackageInfo( context.getPackageName(), 0 );
			return info.packageName;
			
		} catch ( Exception e ) {
			e.printStackTrace();
		}
		return "";
	}
}
