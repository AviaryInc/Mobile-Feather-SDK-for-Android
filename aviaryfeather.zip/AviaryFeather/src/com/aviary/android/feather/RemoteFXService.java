package com.aviary.android.feather;

import java.io.FileNotFoundException;

import org.apache.http.client.HttpClient;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.http.AndroidHttpClient;

import com.aviary.android.feather.library.log.Logger;
import com.aviary.image.sdk.AviaryFX;
import com.aviary.image.sdk.RenderResponse;
import com.aviary.image.sdk.Response;
import com.aviary.image.sdk.Ticket;
import com.aviary.image.sdk.UploadResponse;

public class RemoteFXService extends EffectContextService {

	AviaryFX mAviaryFx;

	protected RemoteFXService( EffectContext context ) {
		super( context );
	}

	public void init( String api_key, String api_secret ) {
		if( mAviaryFx == null ) {
			mAviaryFx = new AviaryFX( api_key, api_secret, AviaryFX.createDefaultHttpClient() );
		}
	}

	public Response<RenderResponse> render( Ticket ticket ) {
		return mAviaryFx.render( ticket );
	}

	public Response<UploadResponse> upload( String path, CompressFormat format ) throws FileNotFoundException {
		return mAviaryFx.upload( path, format );
	}

	public Response<UploadResponse> upload( Bitmap bitmap, CompressFormat format, int quality ) {
		return mAviaryFx.upload( bitmap, format, quality );
	}

	@Override
	public void dispose() {
		Logger.info( this, "dispose" );

		if( android.os.Build.VERSION.SDK_INT >= 8 ) {

			if( mAviaryFx != null ) {
				HttpClient client = mAviaryFx.getHttpClient();
				if( client instanceof AndroidHttpClient ) {
					((AndroidHttpClient) client).close();
				}
			}
		}
	}
}
