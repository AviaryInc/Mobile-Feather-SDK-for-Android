package com.aviary.android.feather.receivers;

import java.util.Iterator;
import java.util.Set;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.aviary.android.feather.content.FeatherIntent;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;


public class FeatherSystemReceiver extends BroadcastReceiver {

	public static final String PLUGIN_BASE_PACKAGE = "com.aviary.android.feather.plugins.";
	static Logger logger = LoggerFactory.getLogger( "FeatherSystemReceiver", LoggerType.ConsoleLoggerType );
	
	@Override
	public void onReceive( Context context, Intent intent ) {
		
		final String action = intent.getAction();
		
		if( null != action )
		{
			logger.info( "onReceive", action );
			
			if( Intent.ACTION_PACKAGE_ADDED.equals( action ) ) {
				handlePackageAdded( context, intent );
			} else if( Intent.ACTION_PACKAGE_REMOVED.equals( action )){
				handlePackageRemoved( context, intent );
			} else if( Intent.ACTION_PACKAGE_REPLACED.equals( action )){
				handlePackageReplaced( context, intent );
			}
		}
	}
	
	private void handlePackageReplaced( Context context, Intent intent ){
		Uri data = intent.getData();
		String path = data.getSchemeSpecificPart();
		logger.log( "	", path );
		
		printBundle( intent.getExtras() );
		
		if( null != path ){
			if( path.startsWith( PLUGIN_BASE_PACKAGE )){
				Intent newIntent = new Intent( FeatherIntent.ACTION_PLUGIN_REPLACED );
				newIntent.setData( data );
				context.sendBroadcast( newIntent );
			}
		}		
	}
	
	private void handlePackageRemoved( Context context, Intent intent ){
		Uri data = intent.getData();
		String path = data.getSchemeSpecificPart();
		logger.log( "	", path );
		
		Bundle extras = intent.getExtras();
		boolean is_replacing = isReplacing( extras );
		printBundle( extras );
		
		if( null != path && !is_replacing ){
			if( path.startsWith( PLUGIN_BASE_PACKAGE )){
				Intent newIntent = new Intent( FeatherIntent.ACTION_PLUGIN_REMOVED );
				newIntent.setData( data );
				context.sendBroadcast( newIntent );
			}
		}		
	}
	
	
	private void handlePackageAdded( Context context, Intent intent ){
		Uri data = intent.getData();
		String path = data.getSchemeSpecificPart();
		logger.log( "	", path );
		
		Bundle extras = intent.getExtras();
		boolean is_replacing = isReplacing( extras );
		printBundle( extras );
		
		if( null != path && !is_replacing ){
			if( path.startsWith( PLUGIN_BASE_PACKAGE )){
				Intent newIntent = new Intent( FeatherIntent.ACTION_PLUGIN_ADDED );
				newIntent.setData( data );
				context.sendBroadcast( newIntent );
			}
		}
	}
	
	private void printBundle( Bundle bundle ) {
		if( null != bundle ){
			
			Set<String> set = bundle.keySet();
			Iterator<String> iterator = set.iterator();
			while( iterator.hasNext() ){
				String key = iterator.next();
				Object value = bundle.get( key );
				logger.log( "		", key, value );
			}
		}
	}

	/**
	 * The operation 
	 * @param bundle
	 * @return
	 */
	private boolean isReplacing( Bundle bundle )
	{
		if( bundle != null && bundle.containsKey( Intent.EXTRA_REPLACING ) )
			return bundle.getBoolean( Intent.EXTRA_REPLACING );
		return false;

	}

}
