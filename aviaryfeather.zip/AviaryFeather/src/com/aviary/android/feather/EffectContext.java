package com.aviary.android.feather;

import android.content.Context;
import android.graphics.Matrix;

public interface EffectContext {

	public static final String EFFECT_LOADER = "effect-loader";
	public static final String CONFIG_SERVICE = "config-service";
	public static final String CACHE_SERVICE = "cache-service";
	public static final String REMOTE_FX_SERVICE = "remote-fx-service";
	public static final String FILTER_SERVICE = "filter-service";

	EffectContextService getService( String name );

	/**
	 * Return the current max heap space available
	 * for the current application ( in Mb )
	 * 
	 * @return
	 */
	int getApplicationMaxMemory();

	/**
	 * Return the current context
	 * 
	 * @return
	 */
	Context getBaseContext();

	/**
	 * Return the default specified minimum height
	 * of the bottom option panel
	 * 
	 * @return
	 */
	int getOptionPanelMinimumHeight();

	/**
	 * Return the current image display matrix.
	 * This is useful if you want to replicate the same
	 * image zoom and pan on a panel image view
	 * 
	 * @return
	 */
	Matrix getCurrentImageViewMatrix();

	/**
	 * Check the current network connection.
	 * It requires android.permission.ACCESS_NETWORK_STATE
	 * 
	 * @return
	 */
	boolean isConnectedOrConnecting();

	/**
	 * run a runnable action on the main ui thread
	 * 
	 * @param action
	 */
	void runOnUiThread( Runnable action );
}
