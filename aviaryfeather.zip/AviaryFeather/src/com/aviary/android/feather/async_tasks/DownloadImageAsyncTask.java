package com.aviary.android.feather.async_tasks;

import java.io.IOException;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import com.aviary.android.feather.Constants;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.library.utils.ImageLoader;

public class DownloadImageAsyncTask extends AsyncTask<Context, Void, Bitmap> {

	public static interface OnImageDownloadListener {

		void onDownloadStart();

		void onDownloadComplete( Bitmap result );

		void onDownloadError( String error );
	};

	public static interface OnImageSizeListener {

		void onImageSize( String originalSize, String scaledSize, String bucket );
	};

	private OnImageDownloadListener mListener;
	private OnImageSizeListener mSizeListener;
	private Uri mUri;
	private String error;
	private ImageLoader.ImageSizes mImageSize;

	public DownloadImageAsyncTask( Uri uri ) {
		super();
		mUri = uri;
	}

	public void setOnLoadListener( OnImageDownloadListener listener ) {
		mListener = listener;
	}

	public void setOnImageSizeListener( OnImageSizeListener listener ) {
		mSizeListener = listener;
	}

	@Override
	protected void onPreExecute() {
		super.onPreExecute();

		if ( mListener != null ) mListener.onDownloadStart();
		mImageSize = new ImageLoader.ImageSizes();
	}

	@Override
	protected Bitmap doInBackground( Context... params ) {
		Context context = params[0];

		try {
			return ImageLoader.loadFromUri( context, mUri, Constants.getManagedMaxImageSize(), Constants.getManagedMaxImageSize(), mImageSize );
		} catch ( IOException e ) {
			Logger.error( this, "error: " + e );
			error = e.getMessage();
		}
		return null;
	}

	@Override
	protected void onPostExecute( Bitmap result ) {
		super.onPostExecute( result );

		if ( mListener != null ) {
			if ( result != null ) {
				mListener.onDownloadComplete( result );
			} else {
				mListener.onDownloadError( error );
			}
		}
		
		if( mSizeListener != null && result != null ){
			mSizeListener.onImageSize( mImageSize.getOriginalSize(), mImageSize.getNewSize(), mImageSize.getBucketSize() );
		}

		mListener = null;
		mSizeListener = null;
		mUri = null;
		error = null;
	}
}
