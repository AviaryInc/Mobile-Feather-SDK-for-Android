package com.aviary.android.feather.async_tasks;

import java.lang.ref.SoftReference;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageView;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.BitmapUtils.FLIP_MODE;
import com.aviary.android.feather.library.utils.BitmapUtils.ROTATION;
import com.aviary.android.feather.library.utils.ImageLoader;

public class AssetsAsyncDownloadManager {

	// handler messages
	public static final int THUMBNAIL_LOADED = 1;
	
	/**
	 * Cache variables
	 */
	private static final int HARD_CACHE_CAPACITY = 10;
	private static final int DELAY_BEFORE_PURGE = 60 * 1000;
	private final Handler purgeHandler = new Handler();
	
	@SuppressWarnings("unused")
	private Context mContext;
	private int mThumbSize = -1;
	private Handler mHandler;
	private Boolean mStopped = false;
	private final int nThreads;
	private final PoolWorker[] threads;
	private final LinkedList<MyRunnable> mQueue;

	public AssetsAsyncDownloadManager( Context context, Handler handler ) {
		mContext = context;
		mHandler = handler;
		nThreads = 1;
		mQueue = new LinkedList<MyRunnable>();
		threads = new PoolWorker[nThreads];

		for( int i = 0; i < nThreads; i++ ) {
			threads[i] = new PoolWorker();
			threads[i].start();
		}
	}

	public int getThumbSize() {
		return mThumbSize;
	}

	/**
	 * set the default thumbnail size when
	 * resizing a bitmap
	 * @param size
	 */
	public void setThumbSize( int size ) {
		mThumbSize = size;
	}

	public void shutDownNow() {
		mStopped = true;
		
		synchronized( mQueue ) {
			mQueue.clear();
		}
		
		mContext = null;
	}
	
	private abstract class MyRunnable implements Runnable {
		public WeakReference<ImageView> view;
		
		public MyRunnable( ImageView image ) {
			this.view = new WeakReference<ImageView>( image );
		}
	};

	public void loadAsset( final Resources resource, final String srcFile, final ImageView view ) {

		if( mStopped || mThumbSize < 1 )
			return;

		resetPurgeTimer();
		
		runTask( new MyRunnable( view ) {
			
			@Override
			public void run() {
				if( mStopped )
					return;
				
				Message message = mHandler.obtainMessage();
				
				Bitmap bitmap = getBitmapFromCache( srcFile );
				if( bitmap != null ) {
					message.what = THUMBNAIL_LOADED;
					message.obj = new Thumb( bitmap, view.get() );
				} else {
					bitmap = downloadBitmap( resource, srcFile, view.get() );
					if( bitmap != null )
						addBitmapToCache( srcFile, bitmap );
					
					ImageView imageView = view.get();
					
					if( imageView != null ) {
						MyRunnable bitmapTask = getBitmapTask( imageView );
						if( this == bitmapTask ) {
							imageView.setTag( null );
							message.what = THUMBNAIL_LOADED;
							message.obj = new Thumb( bitmap, imageView );
						} else {
							Logger logger = LoggerFactory.getLogger( "AssetsDownloadManager", LoggerType.ConsoleLoggerType );
							logger.error( "image tag is different than current task!" );
						}
					}
				}
				
				if( message.what == THUMBNAIL_LOADED )
					mHandler.sendMessage( message );
			}
		} );
	}

	public void loadAssetIcon( final ApplicationInfo info, final PackageManager pm, final ImageView view ) {

		if( mStopped || mThumbSize < 1 )
			return;

		resetPurgeTimer();
		
		runTask( new MyRunnable( view ) {
			
			@Override
			public void run() {
				if( mStopped )
					return;
				
				Message message = mHandler.obtainMessage();
				
				Bitmap bitmap = getBitmapFromCache( info.packageName );
				if( bitmap != null ) {
					message.what = THUMBNAIL_LOADED;
					message.obj = new Thumb( bitmap, view.get() );
				} else {
					bitmap = downloadIcon( info, pm, view.get() );
					if( bitmap != null )
						addBitmapToCache( info.packageName, bitmap );
					
					ImageView imageView = view.get();
					
					if( imageView != null ) {
						MyRunnable bitmapTask = getBitmapTask( imageView );
						if( this == bitmapTask ) {
							imageView.setTag( null );
							message.what = THUMBNAIL_LOADED;
							message.obj = new Thumb( bitmap, imageView );
						} else {
							Logger logger = LoggerFactory.getLogger( "AssetsDownloadManager", LoggerType.ConsoleLoggerType );
							logger.error( "image tag is different than current task!" );
						}
					}
				}
				
				if( message.what == THUMBNAIL_LOADED )
					mHandler.sendMessage( message );
			}
		} );
	}
	
	
	private void runTask( MyRunnable task ) {
		synchronized( mQueue ) {
			
			Iterator<MyRunnable> iterator = mQueue.iterator();
			while( iterator.hasNext() ) {
				MyRunnable current = iterator.next();
				ImageView image = current.view.get();
				
				if( image == null ) {
					mQueue.remove( current );
				} else {
					if( image.equals( task.view.get() )) {
						current.view.get().setTag( null );
						mQueue.remove( current );
						break;
					}
				}
			}
			
			task.view.get().setTag( new CustomTag( task ) );
			
			mQueue.add( task );
			mQueue.notify();
			
		}
	}
	
	Bitmap downloadBitmap( Resources resource, String url, View view ) {
		
		if( view == null )
			return null;

		try {
			Bitmap bitmap = ImageLoader.loadFromAsset( resource, url, mThumbSize, mThumbSize );
			Bitmap result = BitmapUtils.createThumbnail( bitmap, mThumbSize, mThumbSize, ROTATION.ROTATE_NULL, FLIP_MODE.None, null, Color.WHITE, Color.WHITE, 5, 6 );
			bitmap.recycle();
			return result;
		} catch( Exception e ) {
			return null;
		}
	}
	
	Bitmap downloadIcon( ApplicationInfo info, PackageManager pm, View view )
	{
		if( view == null )
			return null;
		
		Drawable d = info.loadIcon( pm );
		if( d instanceof BitmapDrawable ){
			Bitmap bitmap = ((BitmapDrawable)d).getBitmap();
			//Bitmap result = BitmapUtils.createThumbnail( bitmap, mThumbSize, mThumbSize, ROTATION.ROTATE_NULL, FLIP_MODE.None, null, Color.WHITE, Color.WHITE, 5, 5 );
			//bitmap.recycle();
			return bitmap;
		}
		
		return null;
		
	}


	private class PoolWorker extends Thread {

		@Override
		public void run() {
			Runnable r;

			while( mStopped != true ) {
				synchronized( mQueue ) {
					while( mQueue.isEmpty() ) {
						if( mStopped )
							break;
						try {
							mQueue.wait();
						} catch( InterruptedException ignored ) {
						}
					}
					r = (Runnable) mQueue.removeFirst();
				}

				try {
					r.run();
				} catch( RuntimeException e ) {
					Logger logger = LoggerFactory.getLogger( "AssetsDownloadManager", LoggerType.ConsoleLoggerType );
					logger.error( e.getMessage() );
				}
			}
		}
	}
	
	static class CustomTag {

		private final WeakReference<MyRunnable> taskReference;

		public CustomTag( MyRunnable task ) {
			super();
			taskReference = new WeakReference<MyRunnable>( task );
		}

		public MyRunnable getDownloaderTask() {
			return taskReference.get();
		}
	}

	private static MyRunnable getBitmapTask( ImageView imageView ) {
		if( imageView != null ) {
			Object tag = imageView.getTag();
			if( tag instanceof CustomTag ) {
				CustomTag runnableTag = (CustomTag) tag;
				return runnableTag.getDownloaderTask();
			}
		}
		return null;
	}

	
	/**
	 * Hard cache, 
	 * with a fixed maximum capacity and a life duration
	 */
	private final HashMap<String, Bitmap> sHardBitmapCache = new LinkedHashMap<String, Bitmap>( HARD_CACHE_CAPACITY / 2, 0.75f, true ) {

		private static final long serialVersionUID = 7320831300767054723L;

		@Override
		protected boolean removeEldestEntry( LinkedHashMap.Entry<String, Bitmap> eldest )
		{
			if( size() > HARD_CACHE_CAPACITY )
			{
				// Entries push-out of hard reference cache are transferred to soft
				// reference cache
				sSoftBitmapCache.put( eldest.getKey(), new SoftReference<Bitmap>( eldest.getValue() ) );
				return true;
			} else
				return false;
		}
	};
	
	/**
	 * Soft cache for bitmaps kicked out of hard cache
	 */
	private final static ConcurrentHashMap<String, SoftReference<Bitmap>> sSoftBitmapCache = new ConcurrentHashMap<String, SoftReference<Bitmap>>( HARD_CACHE_CAPACITY / 2 );
	
	private final Runnable mPurger = new Runnable() {
		
		@Override
		public void run() {
			clearCache();
		}
	};
	
	/**
	 * Clears the image cache used internally to improve performance. Note that
	 * for memory efficiency reasons, the cache will automatically be cleared
	 * after a certain inactivity delay.
	 */
	public void clearCache() {
		sHardBitmapCache.clear();
		sSoftBitmapCache.clear();
	}
	
	/**
	 * Allow a new delay before the automatic cache clear is done.
	 */
	private void resetPurgeTimer() {
		purgeHandler.removeCallbacks( mPurger );
		purgeHandler.postDelayed( mPurger, DELAY_BEFORE_PURGE );
	}

	/**
	 * Try to get the image from cache first
	 * @param url
	 * @return
	 */
	private Bitmap getBitmapFromCache( String url ) {
		// First try the hard reference cache
		synchronized( sHardBitmapCache ) {
			final Bitmap bitmap = sHardBitmapCache.get( url );
			if( bitmap != null ) {
				// Bitmap found in hard cache
				// Move element to first position, so that it is removed last
				sHardBitmapCache.remove( url );
				sHardBitmapCache.put( url, bitmap );
				return bitmap;
			}
		}

		// Then try the soft reference cache
		SoftReference<Bitmap> bitmapReference = sSoftBitmapCache.get( url );
		if( bitmapReference != null ) {
			final Bitmap bitmap = bitmapReference.get();
			if( bitmap != null ) {
				// Bitmap found in soft cache
				return bitmap;
			} else {
				// Soft reference has been Garbage Collected
				sSoftBitmapCache.remove( url );
			}
		}

		return null;
	}

	/**
	 * Adds this bitmap to the cache.
	 * @param bitmap. The newly downloaded bitmap.
	 */
	private void addBitmapToCache( String url, Bitmap bitmap ) {
		if( bitmap != null ) {
			synchronized( sHardBitmapCache ) {
				sHardBitmapCache.put( url, bitmap );
			}
		}
	}
	
	public static class Thumb {
		public Bitmap bitmap;
		public ImageView image;
		
		public Thumb( Bitmap bmp, ImageView img) {
			image = img;
			bitmap = bmp;
		}
	}
}
