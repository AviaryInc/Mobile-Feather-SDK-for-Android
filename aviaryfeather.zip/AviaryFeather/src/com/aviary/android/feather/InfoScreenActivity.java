package com.aviary.android.feather;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import com.aviary.android.feather.library.utils.ConnectionUtils;

public class InfoScreenActivity extends Activity {

	private TextView mTextView01;
	//private TextView mTextView03;
	private Button mLinkButton;
	private final String FORM_URI = "http://aviaryforms.wufoo.com/forms/r7x3a7/";

	@Override
	protected void onCreate( Bundle savedInstanceState ) {
		super.onCreate( savedInstanceState );
		
		requestWindowFeature( Window.FEATURE_NO_TITLE );
		setContentView( R.layout.feather_infoscreen );

		mTextView01.setText( mTextView01.getText() + " " + FeatherActivity.SDK_VERSION );

		//SpannableString content = new SpannableString( mTextView03.getText() );
		//content.setSpan( new UnderlineSpan(), 0, content.length(), 0 );
		//mTextView03.setText( content );
		
		mLinkButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {

				if ( !ConnectionUtils.getNetworkAvailable( getBaseContext() ) ) {
					AlertDialog dialog = new AlertDialog.Builder( InfoScreenActivity.this ).setIcon( android.R.drawable.ic_dialog_alert )
							.setTitle( R.string.attention ).setMessage( R.string.connection_not_available ).create();
					dialog.show();
					return;
				}

				Intent intent = new Intent( Intent.ACTION_VIEW );
				intent.setData( Uri.parse( FORM_URI ) );

				try {
					startActivity( intent );
				} catch ( ActivityNotFoundException e ) {
					e.printStackTrace();
				}
			}
		} );
	}

	@Override
	public void onContentChanged() {
		super.onContentChanged();

		mTextView01 = (TextView) findViewById( R.id.textView1 );
		//mTextView03 = (TextView) findViewById( R.id.textView3 );
		mLinkButton = (Button) findViewById( R.id.button1 );
	}
}
