package com.aviary.android.feather;

import it.sephiroth.android.library.imagezoom.IDisposable;


public abstract class EffectContextService implements IDisposable {
	
	private EffectContext mContext;
	
	protected EffectContextService( EffectContext context ) {
		mContext = context;
	}
	
	public EffectContext getContext(){
		return mContext;
	}
	
	@Override
	public abstract void dispose();
}
