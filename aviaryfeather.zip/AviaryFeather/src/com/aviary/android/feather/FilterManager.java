package com.aviary.android.feather;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import java.util.HashMap;
import android.app.ActivityManager;
import android.app.ActivityManager.MemoryInfo;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.net.ConnectivityManager;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import com.aviary.android.feather.effects.AbstractEffectPanel;
import com.aviary.android.feather.effects.AbstractEffectPanel.ContentPanel;
import com.aviary.android.feather.effects.AbstractEffectPanel.DynamicHeightOptionPanel;
import com.aviary.android.feather.effects.AbstractEffectPanel.OnApplyResultListener;
import com.aviary.android.feather.effects.AbstractEffectPanel.OnContentReadyListener;
import com.aviary.android.feather.effects.AbstractEffectPanel.OnErrorListener;
import com.aviary.android.feather.effects.AbstractEffectPanel.OnPreviewListener;
import com.aviary.android.feather.effects.AbstractEffectPanel.OptionPanel;
import com.aviary.android.feather.effects.EffectLoaderService;
import com.aviary.android.feather.effects.EffectLoaderService.EffectEntry;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.EffectContextService;
import com.aviary.android.feather.library.services.ServiceLoader;
import com.aviary.android.feather.library.tracking.Tracker;
import com.aviary.android.feather.plugins.PluginManager;
import com.aviary.android.feather.services.BackgroundService;
import com.aviary.android.feather.services.CacheManagerService;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.services.FilterService;
import com.aviary.android.feather.services.RemoteFXService;
import com.aviary.android.feather.widget.FilterOptionsSlider.OnPanelCloseListener;
import com.aviary.android.feather.widget.FilterOptionsSlider.OnPanelOpenListener;

final class FilterManager implements OnPreviewListener, OnApplyResultListener, EffectContext, OnErrorListener,
		OnContentReadyListener {

	interface FeatherContext {}

	public static interface OnToolListener {

		void onToolCompleted();
	}

	static enum STATE {
		CLOSED_CANCEL, CLOSED_CONFIRMED, CLOSING, DISABLED, OPENED, OPENING,
	}

	public static final int			STATE_OPENING	= 0;
	public static final int			STATE_OPENED	= 1;
	public static final int			STATE_CLOSING	= 2;
	public static final int			STATE_CLOSED	= 3;

	public static final int			STATE_DISABLED	= 4;

	private Bitmap						mBitmap;
	private FeatherActivity			mContext;
	private AbstractEffectPanel	mCurrentEffect;
	private EffectEntry				mCurrentEntry;
	private STATE						mCurrentState;
	private LayoutInflater			mLayoutInflater;
	private OnToolListener			mToolListener;
	private final Handler			mHandler;
	private final ServiceLoader<EffectContextService>	mServiceLoader;
	private EffectLoaderService	mEffectLoader;
	private Logger logger;

	private boolean					mChanged;

	FilterManager(final FeatherContext context, final Handler handler, final String apikey, final String apisecret) {
		final FeatherActivity activity = (FeatherActivity) context;
		mContext = activity;
		mHandler = handler;
		mLayoutInflater = (LayoutInflater) activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		logger = LoggerFactory.getLogger( "FilterManager", LoggerType.ConsoleLoggerType );

		mServiceLoader = new ServiceLoader<EffectContextService>();
		
		// background tasks queue manager for very simple tasks
		mServiceLoader.register( BackgroundService.class );
		mServiceLoader.register( CacheManagerService.class );
		mServiceLoader.register( ConfigService.class );
		mServiceLoader.register( FilterService.class );
		mServiceLoader.register( RemoteFXService.class );
		mServiceLoader.register( EffectLoaderService.class );
		
		// register the remote effect service
		try {
			final RemoteFXService remoteService = getService(RemoteFXService.class);
			remoteService.init(apikey, apisecret);
		} catch( IllegalAccessException e ){
			e.printStackTrace();
		}

		// Register the plugin manager task in the background task queue
		BackgroundService background;
		try {
			PluginManager pluginManager = new PluginManager( activity, "com.aviary.android.feather" );
			background = getService( BackgroundService.class );
			background.start();
			background.register( pluginManager, false );
			// request immediate update
			pluginManager.update();
			
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}

		setCurrentState(STATE.DISABLED);
		mChanged = false;
	}

	public void activateEffect(final EffectEntry tag) {
		if (!getEnabled() || !isClosed()) return;

		if (mCurrentEffect != null) throw new IllegalStateException("There is already an active effect. Cannot activate new");

		if (mEffectLoader == null) try {
			mEffectLoader = (EffectLoaderService) getService(EffectLoaderService.class);
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}

		final AbstractEffectPanel effect = mEffectLoader.load(tag);

		if (effect != null) {
			mCurrentEffect = effect;
			mCurrentEntry = tag;

			setCurrentState(STATE.OPENING);
			prepareEffectPanel(effect, tag);

			Tracker.recordTag( mContext.getBaseContext().getString(mCurrentEntry.labelResourceId) + ": opened" );
			
			mContext.getOptionsSlider().setOnPanelOpenListener(new OnPanelOpenListener() {

				@Override
				public void onOpened() {
					setCurrentState(STATE.OPENED);
					mContext.getOptionsSlider().setOnPanelOpenListener(null);
				}

				@Override
				public void onOpening() {}
			});

			mContext.getOptionsSlider().open();
		}
	}

	public void dispose() {
		mServiceLoader.dispose();
		mContext = null;
		mLayoutInflater = null;
		mToolListener = null;
	}

	@Override
	public int getApplicationMaxMemory() {
		return Constants.getApplicationMaxMemory();
	}

	@Override
	public Context getBaseContext() {
		return mContext;
	}

	public Bitmap getBitmap() {
		return mBitmap;
	}

	private boolean getBitmapChanged(final Bitmap bmp1, final Bitmap bmp2) {
		if ((bmp1.getWidth() != bmp2.getWidth()) || (bmp2.getHeight() != bmp2.getHeight())) return true;
		return false;
	}

	public boolean getBitmapIsChanged() {
		return mChanged;
	}

	public EffectEntry getCurrentEffect() {
		return mCurrentEntry;
	}

	@Override
	public Matrix getCurrentImageViewMatrix() {
		return mContext.getMainImage().getDisplayMatrix();
	}

	public boolean getEnabled() {
		return mCurrentState != STATE.DISABLED;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <T> T getService(Class<T> cls) throws IllegalAccessException {
		return (T) mServiceLoader.getService((Class<EffectContextService>) cls, this);
	}

	public boolean isClosed() {
		return (mCurrentState == STATE.CLOSED_CANCEL) || (mCurrentState == STATE.CLOSED_CONFIRMED);
	}

	@Override
	public boolean isConnectedOrConnecting() {
		try {
			final ConnectivityManager conn = (ConnectivityManager) getBaseContext().getSystemService(Context.CONNECTIVITY_SERVICE);
			if ((conn.getActiveNetworkInfo() == null) || !conn.getActiveNetworkInfo().isConnectedOrConnecting()) return false;
			return true;
		} catch (final SecurityException e) {
			// the android.permission.ACCESS_NETWORK_STATE is not set, so we're
			// assuming
			// an internet connection is available
			logger.error("android.permission.ACCESS_NETWORK_STATE is not defined. Assuming network is fine");
			return true;
		}
	}

	public boolean isOpened() {
		return mCurrentState == STATE.OPENED;
	}

	public void onActivate(final Bitmap bitmap) {
		if (mCurrentState != STATE.DISABLED) throw new IllegalStateException("Cannot activate. Already active!");

		if ((mBitmap != null) && !mBitmap.isRecycled()) {
			mBitmap.recycle();
			//Logger.warning(this, "bitmap.recycled(1)");
			mBitmap = null;
		}

		mBitmap = bitmap;
		mChanged = false;
		setCurrentState(STATE.CLOSED_CONFIRMED);
	}

	public void onApply() {
		if (!getEnabled() || !isOpened()) return;

		if (mCurrentEffect == null) throw new IllegalStateException("there is no current effect active in the context");

		if (mCurrentEffect.getIsChanged()) {
			mCurrentEffect.onSave();
			// a new Bitmap came
			mChanged = true;
		} else
			onComplete(null, null);
	}

	private void onApplyNewBitmap(final AbstractEffectPanel effect, final Bitmap result) {

		if (effect instanceof ContentPanel) {
			final ImageViewTouch image = ((ContentPanel) effect).getImageView();
			final boolean changed = getBitmapChanged(image.getDisplayBitmap().getBitmap(), result);
			mContext.getMainImage().setImageBitmapReset(result, true, changed ? null : image.getDisplayMatrix());
		} else {
			final boolean changed = getBitmapChanged(mContext.getMainImage().getDisplayBitmap().getBitmap(), result);
			mContext.getMainImage().setImageBitmapReset(result, changed);
		}
	}

	public boolean onBackPressed() {
		if (isClosed()) return false;
		if (mCurrentState != STATE.DISABLED) {
			if (isOpened()) onCancel();
			return true;
		}
		return false;
	}

	public void onCancel() {
		if (!getEnabled() || !isOpened()) return;

		if (mCurrentEffect == null) throw new IllegalStateException("there is no current effect active in the context");

		Tracker.recordTag( getBaseContext().getString(mCurrentEntry.labelResourceId) + ": cancelled" );
		
		// check changed image
		if (mCurrentEffect.getIsChanged())
			onApplyNewBitmap(mCurrentEffect, mBitmap);
		else if (mCurrentEffect instanceof ContentPanel) {
			final ImageViewTouch image = ((ContentPanel) mCurrentEffect).getImageView();
			mContext.getMainImage().setImageBitmapReset(mBitmap, true, image.getDisplayMatrix());
		}

		onClose(false);
	}

	private void onClose(final boolean isConfirmed) {
		setCurrentState(STATE.CLOSING);

		mContext.getOptionsSlider().setOnPanelCloseListener(new OnPanelCloseListener() {

			@Override
			public void onClosed() {
				setCurrentState(isConfirmed ? STATE.CLOSED_CONFIRMED : STATE.CLOSED_CANCEL);
				mContext.getOptionsSlider().setOnPanelCloseListener(null);
			}

			@Override
			public void onClosing() {}
		});

		mContext.getOptionsSlider().close();

	}

	@Override
	public void onComplete(final Bitmap result, HashMap<String, String> trackingAttributes ) {
		Tracker.recordTag( mContext.getBaseContext().getString(mCurrentEntry.labelResourceId) + ": applied", trackingAttributes );
		
		if ((result != null) && !result.equals(mBitmap)) {

			onApplyNewBitmap(mCurrentEffect, result);

			if (!mBitmap.isRecycled()) {
				mBitmap.recycle();
				//Logger.warning(this, "bitmap.recycled(3)");
			}
			mBitmap = null;
			mBitmap = result;
		}

		onClose(true);
	}

	@Override
	public void onError(final String error) {
		new AlertDialog.Builder(mContext).setTitle(R.string.generic_error_title).setMessage(error)
				.setIcon(android.R.drawable.ic_dialog_alert).show();
	}

	@Override
	public void onPreviewChange(final Bitmap result) {
		if (!getEnabled() || !isOpened()) return;

		final boolean changed = getBitmapChanged(mContext.getMainImage().getDisplayBitmap().getBitmap(), result);
		mContext.getMainImage().setImageBitmapReset(result, changed);

		if( LoggerFactory.LOG_ENABLED ){
			final ActivityManager activityManager = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
			final MemoryInfo mi = new MemoryInfo();
			activityManager.getMemoryInfo(mi);
			logger.log("memory free", (mi.availMem / 1048576L));
		}
	}

	@Override
	public void onReady(final AbstractEffectPanel panel) {
		runOnUiThread(new Runnable() {

			@Override
			public void run() {
				mContext.getMainImage().setVisibility(View.GONE);
			}
		});
	}

	public void onRedo() {
		if (!getEnabled() || !isClosed()) return;
	}

	/**
	 * Replace the current bitmap
	 * 
	 * @param bitmap
	 */
	public void onReplaceImage(final Bitmap bitmap) {
		if (!getEnabled() || !isClosed()) throw new IllegalStateException("Cannot replace bitmap. Not active nor closed!");

		if ((mBitmap != null) && !mBitmap.isRecycled()) {
			mBitmap.recycle();
			//Logger.warning(this, "bitmap.recycled(2)");
			mBitmap = null;
		}
		mChanged = false;
		mBitmap = bitmap;
	}

	public void onSave() {
		if (!getEnabled() || !isClosed()) return;
	}

	public void onUndo() {
		if (!getEnabled() || !isClosed()) return;
	}

	private void prepareEffectPanel(final AbstractEffectPanel effect, final EffectEntry entry) {
		View option_child = null;
		View drawing_child = null;

		if (effect instanceof OptionPanel) {
			option_child = ((OptionPanel) effect).getOptionView(mLayoutInflater);

			LayoutParams params = null;

			if (option_child.getLayoutParams() == null) {
				params = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
				((LinearLayout.LayoutParams) params).weight = 1;
			} else
				params = option_child.getLayoutParams();

			mContext.getOptionsSlider().getContent().addView(option_child, -1, params);
			
			if( !(effect instanceof DynamicHeightOptionPanel) ){
				mContext.getOptionsSlider().getContent().setHeight( mContext.getBottomBar().getHeight() );
			} else {
				mContext.getOptionsSlider().getContent().setHeight( LayoutParams.WRAP_CONTENT );
			}
		}

		if (effect instanceof ContentPanel) {
			drawing_child = ((ContentPanel) effect).getContentView(mLayoutInflater);
			drawing_child.setLayoutParams(new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
			mContext.getDrawingImageContainer().addView(drawing_child);
		}

		effect.onCreate(mBitmap);
	}

	@Override
	public void runOnUiThread(final Runnable action) {
		if (mContext != null) mContext.runOnUiThread(action);
	}

	private void setCurrentState(final STATE newState) {
		if (newState != mCurrentState) {
			final STATE previousState = mCurrentState;
			mCurrentState = newState;

			switch (newState) {
				case OPENING:
					mCurrentEffect.setOnPreviewListener(this);
					mCurrentEffect.setOnApplyResultListener(this);
					mCurrentEffect.setOnErrorListener(this);

					if (mCurrentEffect instanceof ContentPanel) ((ContentPanel) mCurrentEffect).setOnReadyListener(this);

					mHandler.sendEmptyMessage(FilterManager.STATE_OPENING);
					break;

				case OPENED:
					mCurrentEffect.onActivate();
					mHandler.sendEmptyMessage(FilterManager.STATE_OPENED);
					break;

				case CLOSING:
					mHandler.sendEmptyMessage(FilterManager.STATE_CLOSING);
					mCurrentEffect.onDeactivate();

					if (mCurrentEffect instanceof ContentPanel) ((ContentPanel) mCurrentEffect).setOnReadyListener(null);
					break;

				case CLOSED_CANCEL:
				case CLOSED_CONFIRMED:

					mContext.getDrawingImageContainer().removeAllViews();

					if (previousState != STATE.DISABLED) {
						mCurrentEffect.onDestroy();
						mCurrentEffect.setOnPreviewListener(null);
						mCurrentEffect.setOnApplyResultListener(null);
						mCurrentEffect.setOnErrorListener(null);
						mCurrentEffect = null;
						mCurrentEntry = null;
					}

					mHandler.sendEmptyMessage(FilterManager.STATE_CLOSED);
					mContext.getOptionsSlider().getContent().removeAllViews();

					if ((newState == STATE.CLOSED_CONFIRMED) && (previousState != STATE.DISABLED))
						if (mToolListener != null) mToolListener.onToolCompleted();

					break;

				case DISABLED:
					mHandler.sendEmptyMessage(FilterManager.STATE_DISABLED);
					break;
			}
		}
	}

	public void setEnabled(final boolean value) {
		if (!value) if (isClosed())
			setCurrentState(STATE.DISABLED);
		else
			throw new IllegalStateException("FilterManager must be closed to change state");
	}

	public void setOnToolListener(final OnToolListener listener) {
		mToolListener = listener;
	}
	
	/**
	 * Main Activity configuration changed
	 * We want to dispatch the configuration event also
	 * to the opened panel
	 * @param newConfig
	 * @return true if the event has been handled
	 */
	public boolean onConfigurationChanged( Configuration newConfig ){
		if( mCurrentEffect != null )
		{
			if( mCurrentEffect.isCreated() ){
				logger.info( "onConfigurationChanged, sending event to ", mCurrentEffect );
				mCurrentEffect.onConfigurationChanged( newConfig );
				return true;
			}
		}
		return false;
	}
}
