package com.aviary.android.feather;

import com.aviary.android.feather.library.filters.FilterLoaderFactory;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;


public final class FilterService extends EffectContextService {

	protected FilterService( EffectContext context ) {
		super( context );
	}
	
	public IFilter load( Filters type ){
		return FilterLoaderFactory.get( type );
	}

	@Override
	public void dispose() {
	}
}
