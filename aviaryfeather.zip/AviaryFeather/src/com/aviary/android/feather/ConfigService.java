package com.aviary.android.feather;

import android.content.res.Resources;

public class ConfigService extends EffectContextService {

	Resources mResources;

	ConfigService( EffectContext context ) {
		super( context );
		mResources = context.getBaseContext().getResources();
	}

	public int getInteger( int res ) {
		return mResources.getInteger( res );
	}
	
	public int[] getIntArray( int res ){
		return mResources.getIntArray( res );
	}
	
	public int getColor( int res ){
		return mResources.getColor( res );
	}
	
	public boolean getBoolean( int res ){
		return mResources.getBoolean( res );
	}

	@Override
	public void dispose() {
	}
}
