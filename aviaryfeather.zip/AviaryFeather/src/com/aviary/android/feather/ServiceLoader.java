package com.aviary.android.feather;

import it.sephiroth.android.library.imagezoom.IDisposable;

import java.util.HashMap;
import java.util.Iterator;

import com.aviary.android.feather.effects.EffectLoaderService;
import com.aviary.android.feather.library.log.Logger;

public class ServiceLoader implements IDisposable {

	HashMap<String, EffectContextService> mServices;

	ServiceLoader() {
		mServices = new HashMap<String, EffectContextService>();
	}

	EffectContextService getService( String name, EffectContext context ) {

		if( mServices.containsKey( name ) ) {
			return mServices.get( name );
		}

		EffectContextService service = get( name, context );
		if( service != null ) {
			mServices.put( name, service );
			return service;
		}

		return null;
	}

	private EffectContextService get( String name, EffectContext context ) {

		if( EffectContext.EFFECT_LOADER.equals( name ) )
			return new EffectLoaderService( context );
		else if( EffectContext.CONFIG_SERVICE.equals( name ) )
			return new ConfigService( context );
		else if( EffectContext.CACHE_SERVICE.equals( name ) )
			return new CacheManagerService( context );
		else if( EffectContext.REMOTE_FX_SERVICE.equals( name ) )
			return new RemoteFXService( context );
		else if( EffectContext.FILTER_SERVICE.equals( name )){
			return new FilterService( context );
		}
		return null;
	}

	@Override
	public void dispose() {
		Logger.info( this, "dispose" );

		try {
			Iterator<String> iterator = mServices.keySet().iterator();

			while( iterator.hasNext() ) {
				EffectContextService service = mServices.get( iterator.next() );
				service.dispose();
			}
		} catch( Exception e ) {
			e.printStackTrace();
		} finally {
			mServices.clear();
		}
	}
}
