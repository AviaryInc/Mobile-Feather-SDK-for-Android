package com.aviary.android.feather;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore.Images.Media;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import com.aviary.android.feather.FilterManager.FeatherContext;
import com.aviary.android.feather.FilterManager.OnToolListener;
import com.aviary.android.feather.async_tasks.DownloadImageAsyncTask;
import com.aviary.android.feather.async_tasks.DownloadImageAsyncTask.OnImageDownloadListener;
import com.aviary.android.feather.async_tasks.DownloadImageAsyncTask.OnImageSizeListener;
import com.aviary.android.feather.effects.EffectLoaderService;
import com.aviary.android.feather.effects.EffectLoaderService.EffectEntry;
import com.aviary.android.feather.library.filters.FilterLoaderFactory;
import com.aviary.android.feather.library.filters.NativeFilter;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.library.tracking.Tracker;
import com.aviary.android.feather.library.utils.IOUtils;
import com.aviary.android.feather.utils.ThreadUtils;
import com.aviary.android.feather.widget.EggView;
import com.aviary.android.feather.widget.FilterOptionsSlider;
import com.aviary.android.feather.widget.ToolbarView;
import com.aviary.android.feather.widget.ToolbarView.OnToolbarClickListener;
import com.aviary.android.feather.widget.WorkspaceCellLayout;
import com.aviary.android.feather.widget.WorkspaceCellLayout.OnEggClickListener;
import com.aviary.android.feather.widget.WorkspaceIndicator;
import com.aviary.android.feather.widget.WorkspaceView;
import com.aviary.android.feather.widget.WorkspaceView.OnLayoutChangeListener;
import com.aviary.android.feather.widget.WorkspaceView.OnPageChangeListener;

public class FeatherActivity extends MonitoredActivity implements OnToolbarClickListener, OnImageDownloadListener,
		OnEggClickListener, OnToolListener, FeatherContext, OnImageSizeListener {

	private static final int ALERT_CONFIRM_EXIT = 0;
	private static final int ALERT_DOWNLOAD_ERROR = 1;
	private static final int ALERT_REVERT_IMAGE = 2;
	
	/**
	 * Version of the Aviary Feather SDK
	 */
	public static final int SDK_INT = 25;
	public static final String SDK_VERSION = "1.1.0";

	private int pResultCode = RESULT_CANCELED;
	private ToolbarView mToolbar;
	private WorkspaceView mWorkspace;
	private ImageViewTouch mImageView;
	private ViewGroup mDrawingViewContainer;
	private View mInlineProgressLoader;
	private FilterOptionsSlider mSlidingDrawer;
	private FilterManager mFilterManager;
	private View mArrowLeft;
	private View mArrowRight;
	private View mGreenCheckmark;
	private View mBottomBar;

	private String mApiKey, mApiSecret;
	private Uri mOriginalUri;
	private Uri mSaveUri;
	private List<String> mToolList;
	private CompressFormat mOutputFormat = CompressFormat.JPEG;
	private final Handler mHandler = new Handler();

	// extra options
	private boolean mHideExitAlertConfirmation = false;
	
	private final Handler mUIHandler = new Handler() {

		@Override
		public void handleMessage( Message msg ) {
			super.handleMessage( msg );

			switch( msg.what ) {
				case FilterManager.STATE_OPENING:
					mToolbar.setClickable( false );
					mWorkspace.setEnabled( false );
					mToolbar.setTitle( mFilterManager.getCurrentEffect().labelResourceId );
					break;

				case FilterManager.STATE_OPENED:
					mToolbar.setClickable( true );
					mWorkspace.setVisibility( View.INVISIBLE );
					mToolbar.setState( ToolbarView.STATE.STATE_APPLY, false );
					break;

				case FilterManager.STATE_CLOSING:
					getMainImage().setVisibility( View.VISIBLE );
					mWorkspace.setVisibility( View.VISIBLE );
					mToolbar.setClickable( false );
					break;

				case FilterManager.STATE_CLOSED:
					mWorkspace.setEnabled( true );
					mToolbar.setClickable( true );
					mToolbar.setState( ToolbarView.STATE.STATE_SAVE, true );
					mToolbar.setSaveEnabled( true );
					break;

				case FilterManager.STATE_DISABLED:
					mWorkspace.setEnabled( false );
					mToolbar.setClickable( false );
					mToolbar.setSaveEnabled( false );
					mToolbar.setUndoEnabled( false );
					mToolbar.setRedoEnabled( false );
					break;
			}

		}
	};
	
	/**
	 * Override the internal setResult in order to have the close status
	 * @param resultCode
	 * @param data
	 */
	final void onSetResult( int resultCode, Intent data ){
		pResultCode = resultCode;
		setResult( resultCode, data );
	}

	@Override
	public void onCreate( Bundle savedInstanceState ) {
		super.onCreate( savedInstanceState );
		requestWindowFeature( Window.FEATURE_NO_TITLE );
		setContentView( R.layout.feather_main );

		Constants.init( getBaseContext() );

		// first check the validity of the incoming intent
		mOriginalUri = handleIntent( getIntent() );

		if( mOriginalUri == null ) {
			onSetResult( RESULT_CANCELED, null );
			finish();
			return;
		}

		// register the toolbar listeners
		mToolbar.setOnToolbarClickListener( this );
		mImageView.setDoubleTapEnabled( false );

		// initialize the workspace
		initWorkspace();

		// initiate the filter manager
		mFilterManager = new FilterManager( this, mUIHandler, mApiKey, mApiSecret );
		mFilterManager.setOnToolListener( this );

		// download the requested image
		loadImage( mOriginalUri );

		// initialize filters
		loadFilters();

		Logger.error( this, "MAX MEMORY: " + mFilterManager.getApplicationMaxMemory() );
		Tracker.recordTag( "feather: opened" );
		
		// register native library
		try {
			PackageInfo info = getPackageManager().getPackageInfo( getPackageName(), 0);
			NativeFilter.init( info.applicationInfo.sourceDir );
			
			
			// /data/app/com.aviary.android.test2-1.apk
		} catch ( NameNotFoundException e ) {
			e.printStackTrace();
		}
	}

	@Override
	protected Dialog onCreateDialog( int id ) {

		Dialog dialog = null;

		switch( id ) {
			case ALERT_CONFIRM_EXIT:
				dialog = new AlertDialog.Builder( this ).setTitle( R.string.confirm_quit_title )
						.setMessage( R.string.confirm_quit_message )
						.setPositiveButton( R.string.yes_leave, new DialogInterface.OnClickListener() {

							@Override
							public void onClick( DialogInterface dialog, int which ) {
								dialog.dismiss();
								onBackPressed( true );
							}
						} ).setNegativeButton( R.string.keep_editing, new DialogInterface.OnClickListener() {

							@Override
							public void onClick( DialogInterface dialog, int which ) {
								dialog.dismiss();
							}
						} ).create();
				break;

			case ALERT_DOWNLOAD_ERROR:
				dialog = new AlertDialog.Builder( this ).setTitle( android.R.string.dialog_alert_title )
						.setMessage( R.string.error_download_image_message ).create();
				break;

			case ALERT_REVERT_IMAGE:
				dialog = new AlertDialog.Builder( this ).setTitle( R.string.revert_dialog_title )
						.setMessage( R.string.revert_dialog_message )
						.setPositiveButton( android.R.string.yes, new DialogInterface.OnClickListener() {

							@Override
							public void onClick( DialogInterface dialog, int which ) {
								dialog.dismiss();
								onRevert();
							}
						} ).setNegativeButton( android.R.string.no, new DialogInterface.OnClickListener() {

							@Override
							public void onClick( DialogInterface dialog, int which ) {
								dialog.dismiss();
							}
						} ).create();
				break;
		}

		return dialog;
	}

	private void onRevert() {
		Tracker.recordTag("feather: reset image");
		loadImage( mOriginalUri );
	}

	@Override
	public void onConfigurationChanged( Configuration newConfig ) {
		Logger.info( this, "onConfigurationChanged: " + newConfig );
		super.onConfigurationChanged( newConfig );
	}

	@Override
	public boolean onCreateOptionsMenu( Menu menu ) {
		Logger.info( this, "onCreateOptionsMenu" );
		MenuInflater inflater = getMenuInflater();
		inflater.inflate( R.menu.menu, menu );
		return true;
	}

	@Override
	public boolean onPrepareOptionsMenu( Menu menu ) {
		Logger.info( this, "onPrepareOptionsMenu" );

		if( mFilterManager.getEnabled() && mFilterManager.isClosed() ) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean onOptionsItemSelected( MenuItem item ) {
		switch( item.getItemId() ) {
			case R.id.edit_reset:
				showDialog( ALERT_REVERT_IMAGE );
				return true;
			default:
				return super.onOptionsItemSelected( item );
		}
	}

	private void loadImage( Uri data ) {
		Logger.info( this, "loadImage: " + data );
		DownloadImageAsyncTask task = new DownloadImageAsyncTask( data );
		task.setOnLoadListener( this );
		task.setOnImageSizeListener( this );
		task.execute( getBaseContext() );
	}

	private void initWorkspace() {
		mWorkspace.setIndicator( (WorkspaceIndicator) findViewById( R.id.workspace_indicator ) );
		mWorkspace.setOnPageChangeListener( new OnPageChangeListener() {

			@Override
			public void onPageChanged( int pageNum, int totalPages ) {
				Logger.log( this, "onPageChanged: " + pageNum + " of " + totalPages );
				mArrowLeft.setEnabled( pageNum > 0 );
				mArrowRight.setEnabled( (pageNum + 1) < totalPages );
			}
		} );

		mWorkspace.setOnEggClickListener( this );

		mWorkspace.setOnLayoutChangeListener( new OnLayoutChangeListener() {

			@Override
			public void onLayoutChanged( boolean changed, int l, int t, int r, int b ) {
				if( changed ){
					getOptionsSlider().getContent().setMinimumHeight( mBottomBar.getHeight() - (getOptionsSlider().getContent().getPaddingBottom()+getOptionsSlider().getContent().getPaddingTop()) );
					//getOptionsSlider().getContent().setMinimumHeight( mBottomBar.getHeight() );
					//getOptionsSlider().getContent().setHeight( mBottomBar.getHeight() );
					//getOptionsSlider().getContent().setMinimumHeight( b - t );
				}
			}
		} );

		mArrowRight.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if( (mWorkspace.getCurrentScreen() + 1) < mWorkspace.getTotalScreens() ) {
					mWorkspace.scrollRight();
				}
			}
		} );

		mArrowLeft.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if( mWorkspace.getCurrentScreen() > 0 ) {
					mWorkspace.scrollLeft();
				}
			}
		} );
	}
	
	

	@Override
	protected void onDestroy() {
		if( pResultCode != RESULT_OK )
			Tracker.recordTag( "feather: cancelled" );
		
		super.onDestroy();
		mToolbar.setOnToolbarClickListener( null );
		mWorkspace.setOnEggClickListener( null );

		if( mFilterManager != null ) {
			mFilterManager.dispose();
		}
		mFilterManager = null;
	}

	@Override
	public void onContentChanged() {
		super.onContentChanged();
		mToolbar = (ToolbarView) findViewById( R.id.toolbar );
		mBottomBar = findViewById( R.id.bottombar );
		mWorkspace = (WorkspaceView) findViewById( R.id.workspace );
		mImageView = (ImageViewTouch) findViewById( R.id.image );
		mDrawingViewContainer = (ViewGroup) findViewById( R.id.drawing_view_container );
		mInlineProgressLoader = findViewById( R.id.image_loading_view );
		mSlidingDrawer = (FilterOptionsSlider) findViewById( R.id.options_panel );
		mArrowLeft = findViewById( R.id.arrow_left );
		mArrowRight = findViewById( R.id.arrow_right );
		mGreenCheckmark = findViewById( R.id.checkmark );
	}

	@Override
	public void onBackPressed() {
		if( !mFilterManager.onBackPressed() ) {
			if( mFilterManager.getBitmapIsChanged() ) {
				
				if( mHideExitAlertConfirmation ){
					super.onBackPressed();
				} else {
					showDialog( ALERT_CONFIRM_EXIT );
				}
				
			} else {
				super.onBackPressed();
			}
		}
	}

	protected void onBackPressed( boolean force ) {
		if( force )
			super.onBackPressed();
		else
			onBackPressed();
	}

	private Uri handleIntent( Intent intent ) {
		if( intent != null && intent.getData() != null ) {
			Uri data = intent.getData();

			Bundle extras = intent.getExtras();
			if( extras != null ) {
				mSaveUri = (Uri) extras.getParcelable( Constants.EXTRA_OUTPUT );
				mApiKey = extras.getString( Constants.API_KEY );
				mApiSecret = extras.getString( Constants.API_SECRET );

				if( mSaveUri != null ) {
					String outputFormatString = extras.getString( Constants.EXTRA_OUTPUT_FORMAT );
					if( outputFormatString != null ) {
						mOutputFormat = Bitmap.CompressFormat.valueOf( outputFormatString );
					}
				}
				
				if( extras.containsKey( Constants.EXTRA_TOOLS_LIST )){
					mToolList = Arrays.asList( extras.getStringArray( Constants.EXTRA_TOOLS_LIST ) );
				}
				
				if( extras.containsKey( Constants.EXTRA_HIDE_EXIT_UNSAVE_CONFIRMATION )){
					mHideExitAlertConfirmation = extras.getBoolean( Constants.EXTRA_HIDE_EXIT_UNSAVE_CONFIRMATION );
				}
			}
			return data;
		}
		return null;
	}

	private void loadFilters() {
		// load all icons

		EffectLoaderService service = (EffectLoaderService) mFilterManager.getService( EffectContext.EFFECT_LOADER );
		EffectEntry[] entries = service.getEffects();
		boolean has_stickers = service.hasStickers();
		LayoutInflater inflater = (LayoutInflater) getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		WorkspaceCellLayout workspace = null;

		int index = 0;

		for( int i = 0; i < entries.length; i++ ) {

			FilterLoaderFactory.Filters entry_name = entries[i].name;
			
			if( mToolList != null && mToolList.size() > 0 ){
				if( !mToolList.contains( entry_name.name() ) )
					continue;
			}
			
			if( !has_stickers ) {
				if( entry_name == FilterLoaderFactory.Filters.STICKERS ) {
					continue;
				}
			}

			final int k = index % 4;

			if( k == 0 ) {
				workspace = (WorkspaceCellLayout) inflater.inflate( R.layout.feather_workspace_screen, mWorkspace, false );
			}

			EggView egg = workspace.getEggAt( k );
			egg.setIcon( entries[i].iconResourceId );
			egg.setLabel( entries[i].labelResourceId );
			egg.setTag( entries[i] );
			egg.setVisibility( View.VISIBLE );
			egg.setType( entries[i].type );
			egg.invalidate();

			if( k == 0 )
				mWorkspace.addView( workspace );

			index++;
		}

		mArrowLeft.setEnabled( mWorkspace.getCurrentScreen() > 0 );
		mArrowRight.setEnabled( mWorkspace.getTotalScreens() > 1 );
	}

	/**
	 * Returns the application main toolbar
	 * which contains the save/undo/redo buttons
	 * 
	 * @see ToolbarView
	 * @return
	 */
	public ToolbarView getToolbar() {
		return mToolbar;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.BaseFeatherActivity#getOptionsSlider()
	 */
	public FilterOptionsSlider getOptionsSlider() {
		return mSlidingDrawer;
	}

	/**
	 * Returns the application workspace view
	 * which contains the scrolling tools icons
	 * 
	 * @see WorkspaceView
	 * @return
	 */
	public WorkspaceView getWorkspace() {
		return mWorkspace;
	}
	
	/**
	 * Return the bottombar view container
	 * @return
	 */
	public View getBottomBar(){
		return mBottomBar;
	}

	/**
	 * Return the main image view
	 * 
	 * @return
	 */
	public ImageViewTouch getMainImage() {
		return mImageView;
	}

	public ViewGroup getDrawingImageContainer() {
		return mDrawingViewContainer;
	}

	// ---------------------
	// Toolbar events
	// ---------------------

	@Override
	public void onUndoClick() {
		mFilterManager.onUndo();

		mSlidingDrawer.open();
	}

	@Override
	public void onRedoClick() {
		mFilterManager.onRedo();
		mSlidingDrawer.close();
	}

	@Override
	public void onSaveClick() {
		mFilterManager.onSave();

		if( mFilterManager != null ) {
			Bitmap bitmap = mFilterManager.getBitmap();
			if( bitmap != null ) {
				performSave( bitmap );
			}
		}
	}

	@Override
	public void onApplyClick() {
		mFilterManager.onApply();
	}

	
	@Override
	public void onCancelClick() {
		mFilterManager.onCancel();
	}
	
	// --------------------------------
	// DownloadImageAsyncTask listener
	// --------------------------------

	@Override
	public void onDownloadComplete( Bitmap result ) {
		Logger.info( this, "onDownloadComplete: " + result.getWidth() + "x" + result.getHeight() );
		mImageView.setImageBitmapReset( result, true );

		Animation animation = AnimationUtils.loadAnimation( this, android.R.anim.fade_in );
		mImageView.startAnimation( animation );
		mImageView.setVisibility( View.VISIBLE );

		mInlineProgressLoader.setVisibility( View.GONE );

		if( mFilterManager != null ) {
			if( mFilterManager.getEnabled() ) {
				mFilterManager.onReplaceImage( result );
			} else {
				mFilterManager.onActivate( result );
			}
		}
	}

	@Override
	public void onDownloadError( String error ) {
		Logger.error( this, "onDownloadError: " + error );
		mInlineProgressLoader.setVisibility( View.GONE );
		showDialog( ALERT_DOWNLOAD_ERROR );
	}

	@Override
	public void onDownloadStart() {
		Logger.info( this, "onDownloadStart" );
		mImageView.setVisibility( View.INVISIBLE );
		mInlineProgressLoader.setVisibility( View.VISIBLE );
	}

	@Override
	public void onClick( EffectEntry tag ) {
		mFilterManager.activateEffect( tag );
	}

	private boolean mSaving;

	private void performSave( final Bitmap bitmap ) {
		if( mSaving )
			return;
		mSaving = true;

		Logger.info( this, "performdSave" );
		Tracker.recordTag("feather: saved");

		// disable the filter manager...
		mFilterManager.setEnabled( false );

		// Release bitmap memory
		mImageView.clear();
		Bundle myExtras = getIntent().getExtras();

		// if request intent has "return-data" then the result bitmap
		// will be encoded into the result itent
		if( myExtras != null && myExtras.getBoolean( Constants.EXTRA_RETURN_DATA ) ) {
			Logger.log( this, "returning inline image" );

			Bundle extras = new Bundle();
			extras.putParcelable( "data", bitmap );
			onSetResult( RESULT_OK, new Intent().setData( mSaveUri ).setAction( "inline-data" ).putExtras( extras ) );
			finish();

		} else {
			ThreadUtils.startBackgroundJob( this, null, "Saving...", new Runnable() {

				@Override
				public void run() {
					doSave( bitmap );
					bitmap.recycle();
				}
			}, mHandler );
		}
	}

	private void doSave( Bitmap bitmap ) {
		Logger.info( this, "doSave" );

		Bundle myExtras = getIntent().getExtras();

		// result extras
		Bundle extras = new Bundle();

		// if the request intent has EXTRA_OUTPUT declared
		// then save the image into the output uri and return it
		if( mSaveUri != null ) {
			Logger.log( this, "saving image into output: " + mSaveUri );
			OutputStream outputStream = null;
			String scheme = mSaveUri.getScheme();
			try {
				if( scheme == null ) {
					outputStream = new FileOutputStream( mSaveUri.getPath() );
				} else {
					outputStream = getContentResolver().openOutputStream( mSaveUri );
				}
				if( outputStream != null ) {
					int quality = 75;
					if( myExtras != null && myExtras.containsKey( Constants.EXTRA_OUTPUT_QUALITY ) )
						quality = myExtras.getInt( Constants.EXTRA_OUTPUT_QUALITY );
					bitmap.compress( mOutputFormat, quality, outputStream );
				}
			} catch( IOException ex ) {
				Logger.error( this, "Cannot open file: " + mSaveUri + ", " + ex );
			} finally {
				IOUtils.closeSilently( outputStream );
			}
			onSetResult( RESULT_OK, new Intent().setData( mSaveUri ).putExtras( extras ) );
		} else {
			// no output uri declared, save the image in a new path
			// and return it

			String url = Media.insertImage( getContentResolver(), bitmap, "title", "modified with Aviary Feather�" );
			Uri newUri = Uri.parse( url );
			onSetResult( RESULT_OK, new Intent().setData( newUri ).putExtras( extras ) );
		}

		final Bitmap b = bitmap;
		mHandler.post( new Runnable() {

			@Override
			public void run() {
				mImageView.clear();
				b.recycle();
			}
		} );

		finish();
	}

	@Override
	public void onToolCompleted() {

		mGreenCheckmark.setVisibility( View.VISIBLE );
		Animation animation = AnimationUtils.loadAnimation( getBaseContext(), android.R.anim.fade_out );
		animation.setDuration( 500 );
		animation.setStartOffset( 500 );
		animation.setAnimationListener( mGreencheckmarkAnimationListener );
		mGreenCheckmark.startAnimation( animation );
	}

	private AnimationListener mGreencheckmarkAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationStart( Animation animation ) {
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {
		}

		@Override
		public void onAnimationEnd( Animation animation ) {
			mGreenCheckmark.setVisibility( View.GONE );
		}
	};

	String getApiKey() {
		return mApiKey;
	}

	String getApiSecret() {
		return mApiSecret;
	}

	Handler getUIHandler() {
		return mUIHandler;
	}
	
	@Override
	public void onStart(){
		super.onStart();
	}
	
	@Override
	public void onStop(){
		super.onStop();
	}

	@Override
	public void onImageSize( String originalSize, String scaledSize, String bucket ) {
		Logger.info( this, "onImageSize: " + originalSize + ", " + scaledSize + ", " + bucket );
		HashMap<String, String> attributes = new HashMap<String, String>();
		attributes.put( "originalSize", originalSize );
		attributes.put( "newSize", scaledSize );
		attributes.put( "bucketSize", bucket );
		Tracker.recordTag( "image: scaled", attributes );
	}
}