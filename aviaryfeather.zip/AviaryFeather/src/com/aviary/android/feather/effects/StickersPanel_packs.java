package com.aviary.android.feather.effects;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import com.aviary.android.feather.R;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager.Thumb;
import com.aviary.android.feather.library.graphics.drawable.FeatherDrawable;
import com.aviary.android.feather.library.graphics.drawable.StickerDrawable;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.MatrixUtils;
import com.aviary.android.feather.plugins.PluginManager;
import com.aviary.android.feather.services.BackgroundService;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.DrawableHighlightView;
import com.aviary.android.feather.widget.DrawableHighlightView.OnDeleteClickListener;
import com.aviary.android.feather.widget.EggView;
import com.aviary.android.feather.widget.EggView.EGG_TYPE;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay;
import com.aviary.android.feather.widget.WorkspaceAdapterView;
import com.aviary.android.feather.widget.WorkspaceAdapterView.OnPageChangeListener;
import com.aviary.android.feather.widget.WorkspaceCellLayout;

public class StickersPanel_packs extends AbstractContentPanel {

	private static enum Status {
		Null, Sticker,
	}

	private WorkspaceAdapterView mWorkspace;
	private View mApplyStateView, mStickersView;
	private Button mAddAnother, mClearAll;
	private AssetsAsyncDownloadManager mDownloadManager;
	private Canvas mCanvas;
	private int mStickerMinSize;
	private int mStickerPadding = 0;
	private View mLoadingTextView;
	private int outlineColorNormal, outlineColorPressed;

	private Status mStatus = Status.Null;
	private ArrayList<String> stickerNames;

	private final Handler mHandler = new Handler() {

		@Override
		public void handleMessage( Message msg ) {

			switch ( msg.what ) {
				case AssetsAsyncDownloadManager.THUMBNAIL_LOADED:
					Thumb thumb = (Thumb) msg.obj;
					if ( thumb.image != null ) thumb.image.setImageBitmap( thumb.bitmap );

					hideLoadingText();

					if ( mWorkspace.getVisibility() != View.VISIBLE ){ 
						mWorkspace.setVisibility( View.VISIBLE );
						mWorkspace.requestLayout();
					}

					break;
			}
		}
	};
	
	private void hideLoadingText(){
		if ( mLoadingTextView.getVisibility() == View.VISIBLE ) mLoadingTextView.setVisibility( View.GONE );
	}
	
	@SuppressWarnings("unused")
	private void showLoadingText(){
		if ( mLoadingTextView.getVisibility() == View.GONE ) mLoadingTextView.setVisibility( View.VISIBLE );
	}

	public StickersPanel_packs( EffectContext context ) {
		super( context );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mImageView = (ImageViewDrawableOverlay) getContentView().findViewById( R.id.overlay );
		mImageView.setDoubleTapEnabled( false );
		mLoadingTextView = getOptionView().findViewById( R.id.loading_text );

		mDownloadManager = new AssetsAsyncDownloadManager( this.getContext().getBaseContext(), mHandler );

		createAndConfigurePreview();
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );

		initWorkspace();
	}

	@Override
	public void onActivate() {
		super.onActivate();
		mImageView.requestLayout();

		stickerNames = new ArrayList<String>();

		ConfigService config = null;
		try {
			config = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mStickerMinSize = config.getInteger( R.integer.sticker_minsize );
		mStickerPadding = config.getInteger( R.integer.sticker_padding );
		outlineColorNormal = config.getColor( R.color.sticker_outline_normal );
		outlineColorPressed = config.getColor( R.color.sticker_outline_pressed );

		contentReady();
		//loadStickers();
		loadPacks();
	}

	private void createAndConfigurePreview() {

		if ( mPreview != null && !mPreview.isRecycled() ) {
			mPreview.recycle();
			mPreview = null;
		}

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mCanvas = new Canvas( mPreview );
	}

	@Override
	public void onDestroy() {
		mDownloadManager.clearCache();
		mDownloadManager.shutDownNow();
		mCanvas = null;
		super.onDestroy();
	}

	@Override
	protected void onGenerateResult() {
		onApplyCurrent();
		super.onGenerateResult();
	}

	private void initWorkspace() {
		//mWorkspace = (WorkspaceAdapterView) mOptionView.findViewById( R.id.stickers_workspace );
		//mWorkspace.setIndicator( (WorkspaceIndicator) mOptionView.findViewById( R.id.stickers_page_indicator ) );
		mWorkspace.setOnPageChangeListener( new OnPageChangeListener() {

			@Override
			public void onPageChanged( int pageNum, int totalPages ) {}
		} );

		mApplyStateView = mOptionView.findViewById( R.id.apply_state_layout );
		mStickersView = mOptionView.findViewById( R.id.stickers_bottombar );
		mAddAnother = (Button) mOptionView.findViewById( R.id.add_another );
		mClearAll = (Button) mOptionView.findViewById( R.id.clear_all );

		mAddAnother.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				onApplyCurrent();
			}
		} );

		mClearAll.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				onClearAll();
			}
		} );
	}
	
	private void loadPacks()
	{
		mHandler.post( new Runnable() {
			
			@Override
			public void run() {
				BackgroundService task = null;
				try {
					task = getContext().getService( BackgroundService.class );
				} catch ( IllegalAccessException e ) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				PluginManager manager = (PluginManager) task.getInternalTask( PluginManager.class );
				List<ApplicationInfo> result = manager.listAssetsPlugins( "stickers" );
				PackageManager pm = getContext().getBaseContext().getPackageManager();
				
				List<StickerPackEntry> entries = new ArrayList<StickerPackEntry>();
				for( ApplicationInfo info : result )
				{
					CharSequence label = info.loadLabel( pm );
					entries.add( new StickerPackEntry( (String) label, info ) );
				}
				
				if( isActive() ){
					StickersPackAdapter adapter = new StickersPackAdapter( getContext().getBaseContext(), R.layout.feather_workspace_screen, -1, entries );
					mWorkspace.setAdapter( adapter );
				}
			}
		} );
	}

	@SuppressWarnings("unused")
	private void loadStickers() {

		mHandler.post( new Runnable() {

			@Override
			public void run() {

				List<StickerEntry> entries = new ArrayList<StickerEntry>();
				String[] list = null;
				Resources res = getContext().getBaseContext().getResources();
				
				try {
					list = getContext().getBaseContext().getAssets().list( "stickers" );
				} catch ( IOException e ) {
					e.printStackTrace();
				}

				if ( list != null ) {
					for ( String file : list ) {
						entries.add( new StickerEntry( file, res ) );
					}
					

					if ( entries.size() > 0 ) {
						StickersAdapter adapter = new StickersAdapter( getContext().getBaseContext(), R.layout.feather_workspace_screen, -1, entries );
						mWorkspace.setAdapter( adapter );
					}
				}

			}
		} );
	}

	private void onApplyCurrent() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getHighlightCount() < 1 ) return;

		final DrawableHighlightView hv = ( (ImageViewDrawableOverlay) mImageView ).getHighlightViewAt( 0 );

		if ( hv != null ) {

			RectF cropRect = hv.getCropRectF();
			Rect rect = new Rect( (int) cropRect.left, (int) cropRect.top, (int) cropRect.right, (int) cropRect.bottom );

			Matrix rotateMatrix = hv.getCropRotationMatrix();
			Matrix matrix = new Matrix( mImageView.getImageMatrix() );
			if ( !matrix.invert( matrix ) ) {
				Log.e( "stickers", "unale to invert matrix" );
			}

			int saveCount = mCanvas.save( Canvas.MATRIX_SAVE_FLAG );
			mCanvas.concat( rotateMatrix );
			hv.getContent().setBounds( rect );
			hv.getContent().draw( mCanvas );
			mCanvas.restoreToCount( saveCount );
			mImageView.invalidate();
		}
		onClearCurrent( true );
		onPreviewChanged( mPreview, false );
	}

	private void onClearCurrent( boolean isApplying ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		if ( image.getHighlightCount() > 0 ) {
			final DrawableHighlightView hv = image.getHighlightViewAt( 0 );
			onClearCurrent( hv, isApplying );
		}
	}

	private void onClearCurrent( DrawableHighlightView hv, boolean isApplying ) {
		if( !isApplying )
			if ( stickerNames.size() > 0 ) stickerNames.remove( stickerNames.size() - 1 );

		hv.setOnDeleteClickListener( null );
		( (ImageViewDrawableOverlay) mImageView ).removeHightlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).invalidate();
		setStatus( Status.Null );
	}

	private void onAskClearCurrent() {

		android.content.DialogInterface.OnClickListener yesListener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick( DialogInterface dialog, int which ) {
				if ( which == DialogInterface.BUTTON_POSITIVE ) {
					onClearCurrent( false );
				}
				dialog.dismiss();
			}
		};

		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.sticker_delete_title )
				.setMessage( R.string.sticker_delete_message ).setPositiveButton( R.string.yes_remove, yesListener )
				.setNegativeButton( android.R.string.no, yesListener ).show();
	}
	
	@SuppressWarnings("unused")
	private AnimationListener mAnimationListener = new AnimationListener() {
		
		@Override
		public void onAnimationStart( Animation animation ) {
			mLogger.log( "onAnimationStart" );
		}
		
		@Override
		public void onAnimationRepeat( Animation animation ) {
		}
		
		@Override
		public void onAnimationEnd( Animation animation ) {
			mLogger.log( "onAnimationEnd" );
		}
	};

	private void onClearAll() {
		onClearCurrent( false );
		onPreviewChanged( null, false );

		stickerNames = new ArrayList<String>();

		mImageView.setImageBitmapReset( null, false );
		createAndConfigurePreview();
		mImageView.setImageBitmapReset( mPreview, false );
	}

	private void addSticker( Resources resource, String drawable ) {
		mWorkspace.setEnabled( false );
		
		//Animation fadeAnimation = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_out );
		//fadeAnimation.setAnimationListener( mAnimationListener );
		//mWorkspace.startAnimation( fadeAnimation );
		
		final boolean rotateAndResize = true;
		InputStream stream = null;
		try {
			stream = resource.getAssets().open( drawable );
		} catch ( IOException e ) {
			e.printStackTrace();
		}

		if ( stream != null ) {
			StickerDrawable d = new StickerDrawable( resource, stream );
			d.setAntiAlias( true );

			stickerNames.add( drawable );

			addSticker( d, rotateAndResize );

			try {
				stream.close();
			} catch ( IOException e ) {}
		}
	}

	private void addSticker( FeatherDrawable drawable, boolean rotateAndResize ) {
		setIsChanged( true );

		DrawableHighlightView hv = new DrawableHighlightView( mImageView, drawable );
		hv.setMinSize( mStickerMinSize );
		hv.setOnDeleteClickListener( new OnDeleteClickListener() {

			@Override
			public void onDeleteClick() {
				onAskClearCurrent();
			}
		} );

		Matrix mImageMatrix = mImageView.getImageViewMatrix();

		final int width = mImageView.getWidth();
		final int height = mImageView.getHeight();

		// width/height of the sticker
		final int cropWidth = drawable.getIntrinsicWidth();
		final int cropHeight = drawable.getIntrinsicHeight();

		int x = ( width - cropWidth ) / 2;
		int y = ( height - cropHeight ) / 2;

		Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		float[] pts = new float[] { x, y, x + cropWidth, y + cropHeight };
		MatrixUtils.mapPoints( matrix, pts );

		RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );
		Rect imageRect = new Rect( 0, 0, width, height );

		hv.setRotateAndScale( rotateAndResize );
		hv.setup( mImageMatrix, imageRect, cropRect, false );
		hv.drawOutlineFill( true );
		hv.drawOutlineStroke( false );
		hv.setPadding( mStickerPadding );

		hv.getOutlineFillPaint().setXfermode( new PorterDuffXfermode( android.graphics.PorterDuff.Mode.SRC_ATOP ) );
		hv.setOutlineFillColor( outlineColorNormal );
		hv.setOutlineFillColorPressed( outlineColorPressed );

		( (ImageViewDrawableOverlay) mImageView ).addHighlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).setSelectedHighlightView( hv );
		setStatus( Status.Sticker );
	}

	void setStatus( Status status ) {
		if ( status != mStatus ) {
			mStatus = status;

			Animation fade_in = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_in );
			Animation fade_out = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_out );

			if ( status == Status.Null ) {
				mStickersView.startAnimation( fade_in );
				mApplyStateView.startAnimation( fade_out );
			} else {
				mStickersView.startAnimation( fade_out );
				mApplyStateView.startAnimation( fade_in );
			}

			fade_in.setAnimationListener( mInAnimationListener );
			fade_out.setAnimationListener( mOutAnimationListener );
		}
	}

	AnimationListener mInAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationEnd( Animation animation ) {}

		@Override
		public void onAnimationRepeat( Animation animation ) {}

		@Override
		public void onAnimationStart( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mStickersView.setVisibility( View.VISIBLE );
			} else {
				mApplyStateView.setVisibility( View.VISIBLE );
			}
		}
	};

	AnimationListener mOutAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationEnd( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mApplyStateView.setVisibility( View.INVISIBLE );
			} else {
				mStickersView.setVisibility( View.INVISIBLE );
			}
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {}

		@Override
		public void onAnimationStart( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mStickersView.setVisibility( View.VISIBLE );
			} else {
				mApplyStateView.setVisibility( View.VISIBLE );
			}
		}
	};

	@Override
	public Bitmap render() {
		return null;
	}

	class StickersAdapter extends ArrayAdapter<StickerEntry> {

		private LayoutInflater mLayoutInflater;
		private int mResourceId;
		private LinearLayout.LayoutParams mLayoutParams;

		public StickersAdapter( Context context, int resource, int textViewResourceId, List<StickerEntry> objects ) {
			super( context, resource, textViewResourceId, objects );
			mResourceId = resource;
			mLayoutInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		}

		@Override
		public int getCount() {
			return (int) Math.ceil( (double) super.getCount() / 4.0 );
		}

		int getTotalCount() {
			return super.getCount();
		}

		@Override
		public StickerEntry getItem( int position ) {
			return super.getItem( position );
		}

		@Override
		public long getItemId( int position ) {
			return super.getItemId( position );
		}

		@Override
		public int getItemViewType( int position ) {
			return super.getItemViewType( position );
		}

		@Override
		public int getViewTypeCount() {
			return super.getViewTypeCount();
		}

		class WorkspaceViewHolder {
			public View view;
			public ImageView image1, image2, image3, image4;
		};

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {
			mLogger.log( "getView", position );
			View view = null;
			WorkspaceViewHolder holder = null;

			if ( convertView != null ) {
				view = convertView;
				holder = (WorkspaceViewHolder) convertView.getTag();
			} else {
				view = mLayoutInflater.inflate( mResourceId, parent, false );
				holder = new WorkspaceViewHolder();
				holder.view = view.findViewById( R.id.option1 );
				holder.image1 = (ImageView) view.findViewById( R.id.option1 ).findViewById( R.id.thumb_option );
				holder.image2 = (ImageView) view.findViewById( R.id.option2 ).findViewById( R.id.thumb_option );
				holder.image3 = (ImageView) view.findViewById( R.id.option3 ).findViewById( R.id.thumb_option );
				holder.image4 = (ImageView) view.findViewById( R.id.option4 ).findViewById( R.id.thumb_option );
				
				
				if( mLayoutParams == null )
				{
					int w = getOptionView().getMeasuredWidth();
					int h = getOptionView().getMeasuredHeight();
					
					int margin = ((LayoutParams)holder.view.getLayoutParams()).leftMargin * 2;
					int destWidth = ( w/4 ) - ( margin );
					int destHeight = h - 20;
					int finalSize = Math.min( destWidth, destHeight );
					
					mLayoutParams = new LinearLayout.LayoutParams( finalSize, finalSize, 1 );
				}
				
				view.findViewById( R.id.option1 ).setLayoutParams( mLayoutParams );
				view.findViewById( R.id.option2 ).setLayoutParams( mLayoutParams );
				view.findViewById( R.id.option3 ).setLayoutParams( mLayoutParams );
				view.findViewById( R.id.option4 ).setLayoutParams( mLayoutParams );
				
				
				view.setTag( holder );
			}

			int curPos = position * 4;

			if ( mDownloadManager.getThumbSize() < 1 ) {
				mLogger.log( "thumb size", holder.view.getLayoutParams().height );
				mDownloadManager.setThumbSize( holder.view.getLayoutParams().height );
			}

			// TODO: display a default white bitmap
			// and download the asset thumbnail using a queued thread
			loadStickerForImage( curPos, holder.image1 );
			loadStickerForImage( curPos + 1, holder.image2 );
			loadStickerForImage( curPos + 2, holder.image3 );
			loadStickerForImage( curPos + 3, holder.image4 );

			return view;
		}

		private void loadStickerForImage( int position, ImageView view ) {

			if ( position < getTotalCount() ) {
				
				StickerEntry entry = getItem( position );

				final String sticker = "stickers/" + entry.name;
				final Resources resource = entry.resource;
				
				mDownloadManager.loadAsset( entry.resource, sticker, view );
				view.setVisibility( View.VISIBLE );
				view.setOnClickListener( new OnClickListener() {

					@Override
					public void onClick( View v ) {
						addSticker( resource, sticker );
					}
				} );
			} else {
				view.setVisibility( View.INVISIBLE );
			}
		}
	}
	

	class StickersPackAdapter extends ArrayAdapter<StickerPackEntry> {

		private LayoutInflater mLayoutInflater;
		private int mResourceId;
		@SuppressWarnings("unused")
		private LinearLayout.LayoutParams mLayoutParams;
		private PackageManager mPackageManager;

		public StickersPackAdapter( Context context, int resource, int textViewResourceId, List<StickerPackEntry> objects ) {
			super( context, resource, textViewResourceId, objects );
			mResourceId = resource;
			mLayoutInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
			mPackageManager = context.getPackageManager();
		}

		@Override
		public int getCount() {
			return (int) Math.ceil( (double) super.getCount() / 4.0 );
		}

		int getTotalCount() {
			return super.getCount();
		}

		@Override
		public StickerPackEntry getItem( int position ) {
			return super.getItem( position );
		}

		@Override
		public long getItemId( int position ) {
			return super.getItemId( position );
		}

		@Override
		public int getItemViewType( int position ) {
			return super.getItemViewType( position );
		}

		@Override
		public int getViewTypeCount() {
			return super.getViewTypeCount();
		}

		class WorkspaceViewHolder {
			public EggView image1, image2, image3, image4;
		};

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {
			WorkspaceCellLayout view = null;
			WorkspaceViewHolder holder = null;

			if ( convertView != null ) {
				view = (WorkspaceCellLayout) convertView;
				holder = (WorkspaceViewHolder) convertView.getTag();
			} else {
				view = (WorkspaceCellLayout) mLayoutInflater.inflate( mResourceId, parent, false );
				holder = new WorkspaceViewHolder();
				holder.image1 = (EggView) view.getChildAt( 0 );
				holder.image2 = (EggView) view.getChildAt( 1 );
				holder.image3 = (EggView) view.getChildAt( 2 );
				holder.image4 = (EggView) view.getChildAt( 3 );
				
				mDownloadManager.setThumbSize( 72 );
				
				view.setTag( holder );
			}

			final int curPos = position * 4;
			loadEgg( curPos, holder.image1 );
			loadEgg( curPos + 1, holder.image2 );
			loadEgg( curPos + 2, holder.image3 );
			loadEgg( curPos + 3, holder.image4 );

			return view;
		}

		private void loadEgg( int position, final EggView egg ) {
			if ( position < getTotalCount() ) {
				StickerPackEntry entry = getItem( position );
				egg.setLabel( entry.name );
				egg.setIcon( R.drawable.icon );
				egg.setTag( entry );
				egg.setVisibility( View.VISIBLE );
				egg.setType( EGG_TYPE.DEFAULT );
				
				//egg.setIcon( ((BitmapDrawable)entry.info.loadIcon( mPackageManager )).getBitmap() );
				mDownloadManager.loadAssetIcon( entry.info, mPackageManager, egg.getIcon() );
				
				egg.setOnClickListener( new OnClickListener() {

					@Override
					public void onClick( View v ) {
						//if ( mWorkspace.isEnabled() ) mFilterManager.activateEffect( (EffectEntry) egg.getTag() );
					}
				} );
			} else {
				egg.setVisibility( View.INVISIBLE );
			}
			
			if ( mLoadingTextView.getVisibility() == View.VISIBLE ) mLoadingTextView.setVisibility( View.GONE );

			if ( mWorkspace.getVisibility() != View.VISIBLE ){ 
				mWorkspace.setVisibility( View.VISIBLE );
				mWorkspace.requestLayout();
			}
		}		
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_stickers_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_stickers_panel, null );
	}

	@Override
	protected void onComplete( Bitmap bitmap ) {
		mTrackingAttributes.put("stickersCount", Integer.toString( stickerNames.size() ) );
		mTrackingAttributes.put( "stickersName", getStickersNames() );
		super.onComplete( bitmap );
	}

	String getStickersNames() {
		StringBuilder sb = new StringBuilder();
		for ( String s : stickerNames ) {
			sb.append( s );
			sb.append( "," );
		}
		return sb.toString();
	}

	
	class StickerEntry
	{
		public String name;
		public Resources resource;
		
		StickerEntry( String name, Resources resource )
		{
			this.name = name;
			this.resource = resource;
		}
	}
	
	class StickerPackEntry
	{
		public String name;
		public ApplicationInfo info;
		
		
		public StickerPackEntry( String name, ApplicationInfo info ) {
			this.name = name;
			this.info = info;
		}
	}
	
}
