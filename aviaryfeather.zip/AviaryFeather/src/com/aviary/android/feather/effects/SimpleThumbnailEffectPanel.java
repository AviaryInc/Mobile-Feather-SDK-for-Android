/**
 * 
 */
package com.aviary.android.feather.effects;

import org.json.JSONException;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.IThumbnailIndexFilter;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.services.FilterService;

/**
 * @author Alessandro Crugnola
 * 
 */
public class SimpleThumbnailEffectPanel extends ThumbnailsEffectOptionPanel {

	protected String mResourcesBaseName;
	protected Filters mFilterType;

	public SimpleThumbnailEffectPanel( EffectContext context, Filters type, String resourcesBaseName ) {
		super( context );

		mResourcesBaseName = resourcesBaseName;
		mFilterType = type;
	}

	@Override
	protected IFilter createFilter() {
		FilterService service = null;
		try {
			service = getContext().getService( FilterService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return service.load( mFilterType );
	}

	@Override
	protected Bitmap getThumbnail( int index, Bitmap input, int width, int height, int backgroundColor ) {
		return ( (IThumbnailIndexFilter) mFilter ).getThumbnail( index, 4, input, width, height, backgroundColor );
	}

	@Override
	protected void onOptionClick( int index ) {
		try {
			applyFilter( index );
		} catch ( JSONException e ) {
			e.printStackTrace();
		}
	}

	private void applyFilter( int value ) throws JSONException {
		Bitmap bitmap = ( (IThumbnailIndexFilter) mFilter ).execute( mBitmap, value, getTotalOptions() );
		onPreviewChanged( bitmap );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	protected int getDefaultThumbnailResourceId( int index ) {
		return getContext().getBaseContext().getResources()
				.getIdentifier( mResourcesBaseName + "_thumb_" + index, "drawable", getContext().getBaseContext().getPackageName() );
	}

	@Override
	protected int getTotalOptions() {
		return 4;
	}

	@Override
	protected ThumbnailMode getThumbnailGenerationMode() {
		return super.getThumbnailGenerationMode();
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_four_options_panel, null );
	}
}
