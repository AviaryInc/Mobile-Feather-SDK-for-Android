package com.aviary.android.feather.effects;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;

import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.effects.AbstractEffectPanel.OptionPanel;


abstract class AbstractOptionPanel extends AbstractEffectPanel implements OptionPanel {

	protected View mOptionView;
	
	public AbstractOptionPanel( EffectContext context ) {
		super( context );
	}

	@Override
	public final View getOptionView( LayoutInflater inflater ) {
		mOptionView = generateOptionView( inflater );
		return mOptionView;
	}
	
	public final View getOptionView() {
		return mOptionView;
	}
	
	@Override
	protected void onDispose() {
		mOptionView = null;
		super.onDispose();
	}

	@Override
	public Bitmap render() {
		return null;
	}
	
	protected abstract View generateOptionView( LayoutInflater inflater );

}
