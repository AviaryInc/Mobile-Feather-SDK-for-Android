package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.graphics.drawable.EditableDrawable;
import com.aviary.android.feather.library.graphics.drawable.MemeTextDrawable;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.MatrixUtils;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.DrawableHighlightView;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay.OnDrawableEventListener;

public class MemePanel extends AbstractContentPanel implements OnEditorActionListener, OnClickListener, OnDrawableEventListener {

	Button editTopButton, editBottomButton;
	EditText editTopText, editBottomText;
	InputMethodManager mInputManager;
	Canvas mCanvas;
	DrawableHighlightView topHv, bottomHv;
	Typeface mTypeface;
	String fontName;

	public MemePanel( EffectContext context ) {
		super( context );
		
		ConfigService config = null;
		try {
			config = context.getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fontName = config.getString( R.string.meme_default_font );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		editTopButton = (Button) getOptionView().findViewById( R.id.text_button_1 );
		editBottomButton = (Button) getOptionView().findViewById( R.id.text_button_2 );
		editTopText = (EditText) getContentView().findViewById( R.id.invisible_text_1 );
		editBottomText = (EditText) getContentView().findViewById( R.id.invisible_text_2 );

		mImageView = (ImageViewTouch) getContentView().findViewById( R.id.overlay );
		mImageView.setDoubleTapEnabled( false );
		mImageView.setScaleEnabled( false );
		mImageView.setScrollEnabled( false );

		createAndConfigurePreview();
		mImageView.setImageBitmapReset( mPreview, true, null );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		createTypeFace();

		( (ImageViewDrawableOverlay) mImageView ).setOnDrawableEventListener( this );
		mInputManager = (InputMethodManager) getContext().getBaseContext().getSystemService( Context.INPUT_METHOD_SERVICE );
		editTopButton.setOnClickListener( this );
		editBottomButton.setOnClickListener( this );

		final Matrix mImageMatrix = mImageView.getImageViewMatrix();
		float[] matrixValues = getMatrixValues( mImageMatrix );
		final int height = (int) ( mBitmap.getHeight() * matrixValues[Matrix.MSCALE_Y] );

		FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) editTopText.getLayoutParams();
		p.topMargin = (int) matrixValues[Matrix.MTRANS_Y];
		editTopText.setLayoutParams( p );

		p = (FrameLayout.LayoutParams) editBottomText.getLayoutParams();
		p.bottomMargin = ( ( mImageView.getHeight() - height ) / 2 );
		editBottomText.setLayoutParams( p );

		editTopText.setVisibility( View.VISIBLE );
		editBottomText.setVisibility( View.VISIBLE );

		onAddTopText();
		onAddBottomText();
		contentReady();
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		endEditView( topHv );
		endEditView( bottomHv );

		( (ImageViewDrawableOverlay) mImageView ).setOnDrawableEventListener( null );
		editTopButton.setOnClickListener( null );
		editBottomButton.setOnClickListener( null );

		if ( mInputManager.isActive( editTopText ) )
			mInputManager.hideSoftInputFromWindow( editTopText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS );

		if ( mInputManager.isActive( editBottomText ) )
			mInputManager.hideSoftInputFromWindow( editBottomText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS );

	}

	@Override
	public void onDestroy() {
		mCanvas = null;
		mInputManager = null;
		super.onDestroy();
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_meme_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_meme_panel, null );
	}

	@Override
	protected void onGenerateResult() {
		flattenText( topHv );
		flattenText( bottomHv );
		super.onGenerateResult();
	}

	@Override
	public boolean onEditorAction( TextView v, int actionId, KeyEvent event ) {
		if ( v != null ) {
			if ( actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_UNSPECIFIED ) {
				final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
				if ( image.getSelectedHighlightView() != null ) {
					DrawableHighlightView d = image.getSelectedHighlightView();
					if ( d.getContent() instanceof EditableDrawable ) {
						endEditView( d );
					}
				}
			}
		}

		return false;
	}

	private void flattenText( final DrawableHighlightView hv ) {

		if ( hv != null ) {
			hv.setHidden( true );

			final int width = (int) ( mBitmap.getWidth() );
			final int height = (int) ( mBitmap.getHeight() );

			final RectF cropRect = hv.getCropRectF();
			final Rect rect = new Rect( (int) cropRect.left, (int) cropRect.top, (int) cropRect.right, (int) cropRect.bottom );
			final MemeTextDrawable editable = (MemeTextDrawable) hv.getContent();

			final int saveCount = mCanvas.save( Canvas.MATRIX_SAVE_FLAG );

			editable.setContentSize( width, height );
			editable.setBounds( rect.left, rect.top, rect.right, rect.bottom );
			editable.draw( mCanvas );
			mCanvas.restoreToCount( saveCount );
			mImageView.invalidate();
		}

		onPreviewChanged( mPreview, false );
	}

	private void createAndConfigurePreview() {

		if ( ( mPreview != null ) && !mPreview.isRecycled() ) {
			mPreview.recycle();
			mPreview = null;
		}

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mCanvas = new Canvas( mPreview );
	}

	@Override
	public void onClick( View v ) {
		if ( v == editTopButton ) {
			onTopClick( topHv );
		} else if ( v == editBottomButton ) {
			onTopClick( bottomHv );
		}
	}

	public void onTopClick( final DrawableHighlightView view ) {
		if ( view != null ) if ( view.getContent() instanceof EditableDrawable ) {
			beginEditView( view );
		}
	}

	public static float[] getMatrixValues( Matrix m ) {
		float[] values = new float[9];
		m.getValues( values );
		return values;
	}

	private void onAddTopText() {
		final Matrix mImageMatrix = mImageView.getImageViewMatrix();
		float[] matrixValues = getMatrixValues( mImageMatrix );
		final int width = (int) ( mBitmap.getWidth() * matrixValues[Matrix.MSCALE_X] );
		final int height = (int) ( mBitmap.getHeight() * matrixValues[Matrix.MSCALE_Y] );

		final MemeTextDrawable text = new MemeTextDrawable( "", 75, mTypeface );
		text.setTextColor( Color.WHITE );
		text.setTextStrokeColor( Color.BLACK );
		text.setContentSize( width, height );

		topHv = new DrawableHighlightView( mImageView, text );
		topHv.setAlignModeV( DrawableHighlightView.AlignModeV.Top );

		final int cropHeight = text.getIntrinsicHeight();
		final int x = (int) getMatrixValues( mImageMatrix )[Matrix.MTRANS_X];
		final int y = (int) getMatrixValues( mImageMatrix )[Matrix.MTRANS_Y];

		final Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		final float[] pts = new float[] { x, y, x + width, y + cropHeight };

		MatrixUtils.mapPoints( matrix, pts );
		final RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );
		addEditable( topHv, mImageMatrix, cropRect );
	}

	private void onAddBottomText() {

		final Matrix mImageMatrix = mImageView.getImageViewMatrix();
		float[] matrixValues = getMatrixValues( mImageMatrix );
		final int width = (int) ( mBitmap.getWidth() * matrixValues[Matrix.MSCALE_X] );
		final int height = (int) ( mBitmap.getHeight() * matrixValues[Matrix.MSCALE_Y] );

		final MemeTextDrawable text = new MemeTextDrawable( "", 75, mTypeface );
		text.setTextColor( Color.WHITE );
		text.setTextStrokeColor( Color.BLACK );
		text.setContentSize( width, height );

		bottomHv = new DrawableHighlightView( mImageView, text );
		bottomHv.setAlignModeV( DrawableHighlightView.AlignModeV.Bottom );

		final int cropHeight = text.getIntrinsicHeight();
		final int x = (int) getMatrixValues( mImageMatrix )[Matrix.MTRANS_X];
		final int y = (int) getMatrixValues( mImageMatrix )[Matrix.MTRANS_Y];

		final Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		final float[] pts = new float[] { x, y + height - cropHeight - ( height / 30 ), x + width, y + height - ( height / 30 ) };

		MatrixUtils.mapPoints( matrix, pts );
		final RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );

		addEditable( bottomHv, mImageMatrix, cropRect );
	}

	private void addEditable( DrawableHighlightView hv, Matrix imageMatrix, RectF cropRect ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		hv.setRotateAndScale( true );
		hv.showAnchors( false );
		hv.drawOutlineFill( false );
		hv.drawOutlineStroke( false );
		hv.setup( imageMatrix, null, cropRect, false );
		hv.getOutlineFillPaint().setXfermode( new PorterDuffXfermode( android.graphics.PorterDuff.Mode.SRC_ATOP ) );
		hv.setMinSize( 70 );
		hv.setOutlineFillColor( Color.TRANSPARENT );
		hv.setOutlineFillColorPressed( Color.TRANSPARENT );
		image.addHighlightView( hv );
	}

	abstract class MyTextWatcher implements TextWatcher {

		public DrawableHighlightView view;
	}

	private final MyTextWatcher mEditTextWatcher = new MyTextWatcher() {

		@Override
		public void afterTextChanged( final Editable s ) {}

		@Override
		public void beforeTextChanged( final CharSequence s, final int start, final int count, final int after ) {}

		@Override
		public void onTextChanged( final CharSequence s, final int start, final int before, final int count ) {
			if ( ( view != null ) && ( view.getContent() instanceof EditableDrawable ) ) {
				final EditableDrawable editable = (EditableDrawable) view.getContent();

				if ( !editable.isEditing() ) return;

				editable.setText( s.toString() );
				view.forceUpdate();
				setIsChanged( true );
			}
		}
	};

	@Override
	public void onFocusChange( DrawableHighlightView newFocus, DrawableHighlightView oldFocus ) {
		if ( newFocus == oldFocus ) return;

		if ( oldFocus != null ) {
			if ( oldFocus.getContent() instanceof EditableDrawable ) {
				endEditView( oldFocus );
			}
		}
	}

	private void endEditView( DrawableHighlightView hv ) {
		EditableDrawable text = (EditableDrawable) hv.getContent();
		if ( text.isEditing() ) {
			text.endEdit();
			endEditText( hv );
		}
	}

	private void beginEditView( DrawableHighlightView hv ) {
		final EditableDrawable text = (EditableDrawable) hv.getContent();
		if ( !text.isEditing() ) {
			text.beginEdit();
			beginEditText( hv );
		}
	}

	@Override
	public void onDown( DrawableHighlightView view ) {

	}

	@Override
	public void onMove( DrawableHighlightView view ) {}

	@Override
	public void onClick( DrawableHighlightView view ) {
		if ( view != null ) {
			if ( view.getContent() instanceof EditableDrawable ) {
				beginEditView( view );
			}
		}

	}

	private void beginEditText( final DrawableHighlightView view ) {

		EditText editText = null;

		if ( view == topHv ) {
			editText = editTopText;
		} else if ( view == bottomHv ) {
			editText = editBottomText;
		}

		if ( editText != null ) {
			mEditTextWatcher.view = null;
			editText.removeTextChangedListener( mEditTextWatcher );

			final EditableDrawable editable = (EditableDrawable) view.getContent();
			final String oldText = (String) editable.getText();
			editText.setText( oldText );
			editText.setSelection( editText.length() );
			editText.setImeOptions( EditorInfo.IME_ACTION_DONE );
			editText.requestFocusFromTouch();
			mInputManager.showSoftInput( editText, InputMethodManager.SHOW_IMPLICIT );

			mEditTextWatcher.view = view;
			editText.setOnEditorActionListener( this );
			editText.addTextChangedListener( mEditTextWatcher );

			( (ImageViewDrawableOverlay) mImageView ).setSelectedHighlightView( view );
			( (EditableDrawable) view.getContent() ).setText( ( (EditableDrawable) view.getContent() ).getText() );
			view.forceUpdate();
		}
	}

	private void endEditText( final DrawableHighlightView view ) {

		mEditTextWatcher.view = null;
		EditText editText = null;

		if ( view == topHv )
			editText = editTopText;
		else if ( view == bottomHv ) editText = editBottomText;

		if ( editText != null ) {
			editTopText.removeTextChangedListener( mEditTextWatcher );

			if ( mInputManager.isActive( editText ) ) {
				mInputManager.hideSoftInputFromWindow( editText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS );
			}
		}
	}

	private void createTypeFace() {
		try {
			mTypeface = Typeface.createFromAsset( getContext().getBaseContext().getAssets(), fontName );
		} catch ( Exception e ) {
			mTypeface = Typeface.DEFAULT;
		}
	}
}
