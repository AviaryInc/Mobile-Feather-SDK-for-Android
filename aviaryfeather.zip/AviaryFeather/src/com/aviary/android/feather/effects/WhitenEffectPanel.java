package com.aviary.android.feather.effects;

import android.widget.Toast;

import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;

public class WhitenEffectPanel extends RedeyePanel {

	public WhitenEffectPanel( EffectContext context ) {
		super( context );
	}

	@Override
	protected IFilter createFilter() {
		final FilterService service = (FilterService) getContext().getService( EffectContext.FILTER_SERVICE );
		return service.load( Filters.WHITEN );
	}

	@Override
	protected void displayToolTip() {
		Toast toast = Toast.makeText( getContext().getBaseContext(),
				"Select the brush size and then tap on the image to apply whiten", Toast.LENGTH_LONG );
		toast.show();
	}
}
