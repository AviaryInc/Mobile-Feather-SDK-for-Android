package com.aviary.android.feather.effects;

import java.io.IOException;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.FilterLoaderFactory;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.NativeRangeFilter;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.EffectContextService;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.services.FilterService;
import com.aviary.android.feather.widget.EggView.EGG_TYPE;

public class EffectLoaderService extends EffectContextService {
	
	public static final String NAME = "effect-loader";

	public EffectLoaderService( EffectContext context ) {
		super( context );
	}

	public AbstractEffectPanel load( EffectEntry entry ) {

		AbstractEffectPanel panel = null;
		final EffectContext context = getContext();
		ConfigService config = null;
		try {
			config = context.getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}
		FilterService filterService = null;
		try {
			filterService = context.getService( FilterService.class );
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}
		IFilter filter;

		switch ( entry.name ) {
			case ROTATE:
				panel = new SimpleThumbnailEffectPanel( context, Filters.ROTATE, "rotate" );
				break;

			case FLIP:
				panel = new SimpleThumbnailEffectPanel( context, Filters.FLIP, "flip" );
				break;

			case BRIGHTNESS:
				panel = new SimpleThumbnailEffectPanel( context, Filters.BRIGHTNESS, "brightness" );
				break;

			case SATURATION:
				panel = new SimpleThumbnailEffectPanel( context, Filters.SATURATION, "saturation" );
				break;

			case CONTRAST:
				panel = new SimpleThumbnailEffectPanel( context, Filters.CONTRAST, "contrast" );
				break;

			case COLORS:
				panel = new ColorPanel( context );
				break;

			case SHARPEN:
				filter = filterService.load( Filters.SHARPEN );
				int sharpen_max_value = config.getInteger( R.integer.sharpen_maxValue );
				panel = new NativeEffectRangePanel( context, (NativeRangeFilter) filter, R.string.sharpen_none,
						R.string.sharpen_max, sharpen_max_value );
				break;

			case BLUR:
				filter = filterService.load( Filters.BLUR );
				int blur_max_value = config.getInteger( R.integer.blur_maxValue );
				panel = new NativeEffectRangePanel( context, (NativeRangeFilter) filter, R.string.blur_none, R.string.blur_max,
						blur_max_value );
				break;

			case EFFECTS:
				panel = new NativeEffectsPanel( context );
				break;

			case CROP:
				panel = new CropPanel( context );
				break;

			case RED_EYE:
				panel = new PixelBrushPanel( context, Filters.RED_EYE, R.string.tooltip_redeye );
				break;

			case WHITEN:
				panel = new PixelBrushPanel( context, Filters.WHITEN, R.string.tooltip_whiten );
				break;

			case BLEMISH:
				panel = new PixelBrushPanel( context, Filters.BLEMISH, R.string.tooltip_blemish );
				break;
				
			case DRAWING:
				panel = new DrawingPanel( context );
				break;

			case STICKERS:
				panel = new StickersPanel( context );
				break;

			case TEXT:
				panel = new TextPanel( context );
				break;
				
			case MEME:
				panel = new MemePanel( context );
				break;

			default:
				Logger logger = LoggerFactory.getLogger( "EffectLoaderService", LoggerType.ConsoleLoggerType );
				logger.error( "Effect with " + entry.name + " could not be found" );
				break;
		}
		return panel;
	}

	static final EffectEntry[] mEntries;
	static final NativeEffectEntry[] mNativeEffectEntries;

	static {
		if ( android.os.Build.VERSION.SDK_INT > 7 ) {
			mEntries = new EffectEntry[] {
				new EffectEntry( FilterLoaderFactory.Filters.EFFECTS, R.drawable.icon_flash, R.string.effects, EGG_TYPE.GOLDEN_EGG ),
				new EffectEntry( FilterLoaderFactory.Filters.CROP, R.drawable.icon_crop, R.string.crop ),
				new EffectEntry( FilterLoaderFactory.Filters.ROTATE, R.drawable.icon_rotate, R.string.rotate ),
				new EffectEntry( FilterLoaderFactory.Filters.FLIP, R.drawable.icon_flip, R.string.flip ),
				new EffectEntry( FilterLoaderFactory.Filters.BRIGHTNESS, R.drawable.icon_brightness, R.string.brightness ),
				new EffectEntry( FilterLoaderFactory.Filters.CONTRAST, R.drawable.icon_contrast, R.string.contrast ),
				new EffectEntry( FilterLoaderFactory.Filters.SATURATION, R.drawable.icon_saturation, R.string.saturation ),
				new EffectEntry( FilterLoaderFactory.Filters.COLORS, R.drawable.icon_color, R.string.colors ),
				new EffectEntry( FilterLoaderFactory.Filters.RED_EYE, R.drawable.icon_redeye, R.string.red_eye ),
				new EffectEntry( FilterLoaderFactory.Filters.STICKERS, R.drawable.icon_stickers, R.string.stickers ),
				new EffectEntry( FilterLoaderFactory.Filters.DRAWING, R.drawable.icon_drawing, R.string.draw ),
				new EffectEntry( FilterLoaderFactory.Filters.TEXT, R.drawable.icon_text, R.string.text ),
				new EffectEntry( FilterLoaderFactory.Filters.MEME, R.drawable.icon_meme, R.string.meme ),
				new EffectEntry( FilterLoaderFactory.Filters.WHITEN, R.drawable.icon_whiten, R.string.whiten ),
				new EffectEntry( FilterLoaderFactory.Filters.BLEMISH, R.drawable.icon_blemish, R.string.blemish ),
				new EffectEntry( FilterLoaderFactory.Filters.SHARPEN, R.drawable.icon_sharpen, R.string.sharpen ),
				new EffectEntry( FilterLoaderFactory.Filters.BLUR, R.drawable.icon_blur, R.string.blur ),
			};
		} else {
			mEntries = new EffectEntry[] {
				new EffectEntry( FilterLoaderFactory.Filters.CROP, R.drawable.icon_crop, R.string.crop ),
				new EffectEntry( FilterLoaderFactory.Filters.ROTATE, R.drawable.icon_rotate, R.string.rotate ),
				new EffectEntry( FilterLoaderFactory.Filters.FLIP, R.drawable.icon_flip, R.string.flip ),
				new EffectEntry( FilterLoaderFactory.Filters.BRIGHTNESS, R.drawable.icon_brightness, R.string.brightness ),
				new EffectEntry( FilterLoaderFactory.Filters.CONTRAST, R.drawable.icon_contrast, R.string.contrast ),
				new EffectEntry( FilterLoaderFactory.Filters.SATURATION, R.drawable.icon_saturation, R.string.saturation ),
				new EffectEntry( FilterLoaderFactory.Filters.COLORS, R.drawable.icon_color, R.string.colors ),
				new EffectEntry( FilterLoaderFactory.Filters.RED_EYE, R.drawable.icon_redeye, R.string.red_eye ),
				new EffectEntry( FilterLoaderFactory.Filters.STICKERS, R.drawable.icon_stickers, R.string.stickers ),
				new EffectEntry( FilterLoaderFactory.Filters.DRAWING, R.drawable.icon_drawing, R.string.draw ),
				new EffectEntry( FilterLoaderFactory.Filters.TEXT, R.drawable.icon_text, R.string.text ),
				new EffectEntry( FilterLoaderFactory.Filters.MEME, R.drawable.icon_meme, R.string.meme ),
				new EffectEntry( FilterLoaderFactory.Filters.WHITEN, R.drawable.icon_whiten, R.string.whiten ),
				new EffectEntry( FilterLoaderFactory.Filters.BLEMISH, R.drawable.icon_blemish, R.string.blemish ),
			};
		}
		
		mNativeEffectEntries = new NativeEffectEntry[]{
			new NativeEffectEntry( "undefined", R.drawable.original_thumb, R.string.original ),
			new NativeEffectEntry( "alwayssunny", R.drawable.always_sunny_thumb, R.string.always_sunny ),
			new NativeEffectEntry( "enhance", R.drawable.enhance_thumb, R.string.enhance ),
			new NativeEffectEntry( "cinematic", R.drawable.cinema_thumb, R.string.cinematic ),
			new NativeEffectEntry( "codered", R.drawable.code_red_thumb, R.string.code_red ),
			new NativeEffectEntry( "daydream", R.drawable.daydream_thumb, R.string.day_dream ),
			new NativeEffectEntry( "heatwave", R.drawable.heatwave_thumb, R.string.heatwave ),
			new NativeEffectEntry( "indiglow", R.drawable.indiglow_thumb, R.string.indiglow ),
			new NativeEffectEntry( "invert", R.drawable.invert_thumb, R.string.invert ),
			new NativeEffectEntry( "simplify", R.drawable.module_simplify_thumb, R.string.simplify ),
			new NativeEffectEntry( "vintage", R.drawable.module_vintage_thumb, R.string.vintage ),
		};
	}

	public EffectEntry[] getEffects() {
		return mEntries;
	}
	
	public NativeEffectEntry[] getNativeEffects(){
		return mNativeEffectEntries;
	}

	public boolean hasStickers() {
		try {
			String[] list = null;
			list = getContext().getBaseContext().getAssets().list( "stickers" );
			return list.length > 0;
		} catch ( IOException e ) {}

		return false;
	}
	
	public static final class NativeEffectEntry {
		public int labelResourceId;
		public int iconResourceId;
		public EGG_TYPE type;
		public String name;
		
		
		NativeEffectEntry( String effectId, int iconId, int labelId ) {
			name = effectId;
			iconResourceId = iconId;
			labelResourceId = labelId;
		}
	}

	public static final class EffectEntry {

		public int labelResourceId;
		public int iconResourceId;
		public EGG_TYPE type;
		public FilterLoaderFactory.Filters name;

		public EffectEntry( FilterLoaderFactory.Filters effectId, int iconId, int labelId, EGG_TYPE eggType ) {
			name = effectId;
			iconResourceId = iconId;
			labelResourceId = labelId;
			type = eggType;
		}

		public EffectEntry( FilterLoaderFactory.Filters effectId, int iconId, int labelId ) {
			this( effectId, iconId, labelId, EGG_TYPE.DEFAULT );
		}
	}

	@Override
	public void dispose() {}
}
