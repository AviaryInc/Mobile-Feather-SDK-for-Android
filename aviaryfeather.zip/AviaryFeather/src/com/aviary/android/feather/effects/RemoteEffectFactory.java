package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.IDisposable;
import java.io.IOException;
import android.graphics.Bitmap;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.effects.remote.IEffectRenderer;
import com.aviary.android.feather.effects.remote.RemoteEffectRenderer;


public class RemoteEffectFactory implements IDisposable {

	protected EffectContext mContext;
	protected Mode mMode;
	protected IEffectRenderer mRenderer;
	
	public static enum Mode {
		Local, Remote
	};
	
	public RemoteEffectFactory( EffectContext context ) {
		mContext = context;
		mMode = Mode.Remote;
		mRenderer = new RemoteEffectRenderer( context );
	}
	
	public boolean upload( Bitmap bitmap ){
		return mRenderer.upload( bitmap );
	}
	
	public Bitmap render( Bitmap bitmap, String filterId ) throws IOException{
		return mRenderer.render( bitmap, filterId );
	}
	
	public boolean getImageUploaded(){
		return mRenderer.getImageUploaded();
	}

	@Override
	public void dispose() {
		mRenderer.dispose();
		mRenderer = null;
		mContext = null;
	}
}
