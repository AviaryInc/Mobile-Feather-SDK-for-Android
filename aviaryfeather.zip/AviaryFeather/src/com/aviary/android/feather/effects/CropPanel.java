package com.aviary.android.feather.effects;

import org.json.JSONException;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.TextView;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.NativeFilterProxy;
import com.aviary.android.feather.library.moa.Action;
import com.aviary.android.feather.library.moa.MoaPointParameter;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.CropImageView;
import com.aviary.android.feather.widget.HighlightView;

public class CropPanel extends AbstractContentPanel {

	private CheckBox mToggleButton;
	private TextView mText;

	public CropPanel( EffectContext context ) {
		super( context );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mToggleButton = (CheckBox) getOptionView().findViewById( R.id.option1 );
		mText = (TextView) getOptionView().findViewById( R.id.text1 );
		mImageView = (CropImageView) getContentView().findViewById( R.id.crop_image_view );
		
		mImageView.setDoubleTapEnabled( false );
		
		ConfigService config = null;
		try {
			config = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		final boolean aspectToggle = config.getBoolean( R.bool.aspectRatio_selected );
		mToggleButton.setChecked( aspectToggle );

		mToggleButton.setOnCheckedChangeListener( new OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged( CompoundButton buttonView, boolean isChecked ) {
				if( !mSaving && isActive() )
					onToggleAspectRatio( isChecked );
			}
		} );
		
		mText.setOnClickListener( new OnClickListener() {
			
			@Override
			public void onClick( View v ) {
				mToggleButton.setChecked( !mToggleButton.isChecked() );
			}
		} );
	}

	@Override
	public void onActivate() {
		super.onActivate();
		createCropView();
		setIsChanged( true );
		contentReady();
	}

	@Override
	public void onDestroy() {
		((CropImageView) mImageView).setHighlightView( null );
		mImageView.clear();
		super.onDestroy();
	}

	@Override
	public Bitmap render() {
		return null;
	}
	
	@Override
	public void onDeactivate() {
		super.onDeactivate();
		((CropImageView) mImageView).setHighlightView( null );
		mImageView.clear();
	}

	private void onToggleAspectRatio( boolean value ) {
		
		HighlightView hv =  ((CropImageView) mImageView).getHighlightView();
		if( hv != null ){
			hv.setMaintainAspectRatio( value );
			RectF rect = hv.getCropRectF();
			float ratio = rect.width() / rect.height();
			hv.setAspectRatio( ratio );
		}
		
		//createCropView();
		//mImageView.invalidate();
	}

	private void updateAspectRatio( int mAspectX, int mAspectY, HighlightView hv ) {
		int width = mBitmap.getWidth();
		int height = mBitmap.getHeight();
		Rect imageRect = new Rect( 0, 0, width, height );
		int cropWidth = Math.min( width, height ) * 4 / 5;
		int cropHeight = cropWidth;

		if( mAspectX != 0 && mAspectY != 0 ) {
			if( mAspectX > mAspectY ) {
				cropHeight = cropWidth * mAspectY / mAspectX;
			} else {
				cropWidth = cropHeight * mAspectX / mAspectY;
			}
		}
		int x = (width - cropWidth) / 2;
		int y = (height - cropHeight) / 2;
		RectF cropRect = new RectF( x, y, x + cropWidth, y + cropHeight );
		Matrix mImageMatrix = mImageView.getImageMatrix();
		hv.setup( mImageMatrix, imageRect, cropRect, mAspectX != 0 && mAspectY != 0 );
		hv.setFocus( true );
	}

	private void createCropView() {
		if( ((CropImageView) mImageView).getHighlightView() != null ) {
			((CropImageView) mImageView).setHighlightView( null );
		}

		mImageView.setImageBitmapReset( mBitmap, true );

		HighlightView hv = new HighlightView( mImageView );

		int mAspectX = 0;
		int mAspectY = 0;

		if( mToggleButton.isChecked() ) {
			mAspectX = mBitmap.getWidth();
			mAspectY = mBitmap.getHeight();
		}
		updateAspectRatio( mAspectX, mAspectY, hv );
		((CropImageView) mImageView).setHighlightView( hv );
	}

	@Override
	protected void onGenerateResult() {

		Rect crop_rect = ((CropImageView) mImageView).getHighlightView().getCropRect();
		GenerateResultTask task = new GenerateResultTask( crop_rect );
		task.execute( mBitmap );
	}

	@SuppressWarnings("unused")
	private Bitmap generateBitmap( Bitmap bitmap, Rect cropRect ) {
		Bitmap croppedImage;

		int width = cropRect.width();
		int height = cropRect.height();

		croppedImage = Bitmap.createBitmap( width, height, Bitmap.Config.RGB_565 );
		Canvas canvas = new Canvas( croppedImage );
		Rect dstRect = new Rect( 0, 0, width, height );
		canvas.drawBitmap( mBitmap, cropRect, dstRect, null );
		return croppedImage;
	}

	class GenerateResultTask extends AsyncTask<Bitmap, Void, Bitmap> {

		ProgressDialog mProgress = new ProgressDialog( getContext().getBaseContext() );
		Rect mCropRect;

		public GenerateResultTask( Rect rect ) {
			mCropRect = rect;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			mProgress.setTitle( getContext().getBaseContext().getString( R.string.effet_loading_title ) );
			mProgress.setMessage( getContext().getBaseContext().getString( R.string.effect_loading_message ) );
			mProgress.setIndeterminate( true );
			mProgress.show();
		}

		@Override
		protected Bitmap doInBackground( Bitmap... arg0 ) {
			
			Action action = new Action( "crop" );
			action.setValue( "upperleftpoint", new MoaPointParameter( mCropRect.left, mCropRect.top ) );
			action.setValue( "size", new MoaPointParameter( mCropRect.width(), mCropRect.height() ) );
			
			try {
				return NativeFilterProxy.executeAction( action, arg0[0] );
			} catch ( JSONException e ) {
				e.printStackTrace();
			}
			
			return arg0[0];
			//return generateBitmap( arg0[0], mCropRect );
		}

		@Override
		protected void onPostExecute( Bitmap result ) {
			super.onPostExecute( result );

			if( mProgress.isShowing() )
				mProgress.dismiss();

			onComplete( result );
			
			((CropImageView) mImageView).setHighlightView( null );
		}
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_crop_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_crop_panel, null );
	}

}
