package com.aviary.android.feather.effects;

import java.io.IOException;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.AsyncTask.Status;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.TextView;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.log.Logger;

public class RemoteEffectPanel extends ThumbnailsEffectOptionPanel {

	private class RenderTask extends AsyncTask<Bitmap, Void, Bitmap> implements OnCancelListener {

		String mError;
		String mFilterId;
		ProgressDialog mProgress = new ProgressDialog( getContext().getBaseContext() );

		public RenderTask( final String filterid ) {
			mFilterId = filterid;
		}

		@Override
		protected Bitmap doInBackground( final Bitmap... params ) {

			if ( !getContext().isConnectedOrConnecting() ) {
				mError = getContext().getBaseContext().getString( R.string.connection_not_available );
				return null;
			}

			final Bitmap bitmap = params[0];

			while ( true ) {
				if ( isCancelled() ) return null;
				if ( mFactory.getImageUploaded() ) break;
				if ( mBackgroundTask.getStatus() == Status.FINISHED ) break;
			}

			if ( !mFactory.getImageUploaded() ) {
				final boolean uploaded = mFactory.upload( bitmap );
				if ( !uploaded ) {
					mError = "Sorry, we encountered problems while uploading your image";
					return null;
				}
			}

			if ( !mFactory.getImageUploaded() || isCancelled() ) return null;

			Bitmap result = null;
			try {
				result = mFactory.render( bitmap, mFilterId );
			} catch ( final IOException e ) {
				mError = e.getMessage();
			}

			if ( isCancelled() ) return null;

			return result;
		}

		@Override
		public void onCancel( final DialogInterface dialog ) {
			cancel( true );
			mBackgroundTask.cancel( true );
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
			setCurrentSelected( -1 );
		}

		@Override
		protected void onPostExecute( final Bitmap result ) {
			super.onPostExecute( result );

			if ( mProgress.isShowing() ) mProgress.dismiss();
			if ( isCancelled() ) return;
			if ( result != null )
				onPreviewChanged( result );
			else {
				onGenericError( mError );
				Logger.error( this, mError );
			}
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			mProgress.setTitle( getContext().getBaseContext().getString( R.string.effet_loading_title ) );
			mProgress.setMessage( getContext().getBaseContext().getString( R.string.effect_loading_message ) );
			mProgress.setIndeterminate( true );
			mProgress.setCancelable( true );
			mProgress.setOnCancelListener( this );
			mProgress.show();
		}
	}

	private class UploadTask extends AsyncTask<Bitmap, Void, Boolean> {

		@Override
		protected Boolean doInBackground( final Bitmap... params ) {
			final Bitmap bitmap = params[0];

			if ( isCancelled() ) return null;

			return mFactory.upload( bitmap );
		}

		@Override
		protected void onCancelled() {
			Logger.warning( this, "onCancelled" );
			super.onCancelled();
		}

		@Override
		protected void onPostExecute( final Boolean result ) {
			super.onPostExecute( result );

		}
	}

	static int[] filter_thumbs = new int[] {
		R.drawable.icon_retro, R.drawable.icon_first_camera, R.drawable.icon_instant, R.drawable.icon_toy_camera };

	static int[] filter_labels = new int[] { R.string.retro, R.string.first_camera, R.string.instant, R.string.toy_camera };
	static String[] filter_ids = new String[] { "21", "14", "12", "13" };
	private UploadTask mBackgroundTask;
	private RemoteEffectFactory mFactory;

	public RemoteEffectPanel( final EffectContext context ) {
		super( context );
	}

	@Override
	protected IFilter createFilter() {
		return null;
	}

	@Override
	protected View generateOptionView( final LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_effects_panel, null );
	}

	@Override
	protected int getDefaultThumbnailResourceId( final int index ) {
		return RemoteEffectPanel.filter_thumbs[index];
	}

	protected int getDefaultThumbnailStringId( final int index ) {
		return RemoteEffectPanel.filter_labels[index];
	}

	protected TextView getOptionTextView( final int index ) {
		return (TextView) getOptionView( index ).findViewById( R.id.thumb_text );
	}

	@Override
	protected int getParentId( final View backgroundView ) {
		View parent = (View) backgroundView.getParent();
		if ( parent == null ) return -1;

		parent = (View) parent.getParent();
		if ( parent == null ) return -1;

		return parent.getId();
	}

	@Override
	protected Bitmap getThumbnail( final int index, final Bitmap input, final int width, final int height, final int backgroundColor ) {
		return null;
	}

	@Override
	protected ThumbnailMode getThumbnailGenerationMode() {
		return ThumbnailMode.NONE;
	}

	@Override
	protected int getTotalOptions() {
		return 4;
	}

	@Override
	public void onCreate( final Bitmap bitmap ) {
		super.onCreate( bitmap );
		mFactory = new RemoteEffectFactory( getContext() );
		mBackgroundTask = new UploadTask();
		mBackgroundTask.execute( bitmap );
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		if ( ( mBackgroundTask != null ) && ( mBackgroundTask.getStatus() != Status.FINISHED ) ) mBackgroundTask.cancel( true );
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		mFactory.dispose();
		mFactory = null;
	}

	@Override
	protected void onGenerateThumbnails( final Bitmap bitmap ) {
		super.onGenerateThumbnails( bitmap );

		for ( int i = 0; i < getTotalOptions(); i++ )
			getOptionTextView( i ).setText( RemoteEffectPanel.filter_labels[i] );
	}

	@Override
	protected void onOptionClick( final int index ) {
		final String filterId = RemoteEffectPanel.filter_ids[index];

		if ( filterId != null ) {
			final RenderTask task = new RenderTask( filterId );
			task.execute( mBitmap );
		}
	}

	@Override
	public Bitmap render() {
		return null;
	}
}
