package com.aviary.android.feather.effects.remote;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import com.aviary.android.feather.CacheManagerService;
import com.aviary.android.feather.Constants;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.RemoteFXService;
import com.aviary.android.feather.library.utils.IOUtils;
import com.aviary.android.feather.library.utils.ImageLoader;
import com.aviary.image.sdk.AviaryImage;
import com.aviary.image.sdk.RenderResponse;
import com.aviary.image.sdk.Response;
import com.aviary.image.sdk.Response.STATUS;
import com.aviary.image.sdk.Ticket;
import com.aviary.image.sdk.TicketFactory;
import com.aviary.image.sdk.UploadResponse;

public class RemoteEffectRenderer implements IEffectRenderer {

	private EffectContext mContext;
	private AviaryImage mCurrentImage;

	public RemoteEffectRenderer( EffectContext context ) {
		mContext = context;
	}

	@Override
	public boolean upload( Bitmap bitmap ) {

		if ( mCurrentImage != null ) {
			return true;
		}

		try {
			UploadResponse uploadResult = uploadImage( bitmap );
			if ( uploadResult != null ) {
				mCurrentImage = uploadResult.getImage();
				return true;
			}
		} catch ( Exception e ) {
			e.printStackTrace();
			return false;
		}

		return false;
	}

	@Override
	public boolean getImageUploaded() {
		return mCurrentImage != null;
	}

	@Override
	public Bitmap render( Bitmap bitmap, String filterId ) throws IOException {

		RemoteFilter filter = new RemoteFilter( filterId );

		if ( mCurrentImage == null ) {
			throw new IOException( "Sorry, there were problems rendering the image" );
		}

		RemoteFXService service = (RemoteFXService) mContext.getService( EffectContext.REMOTE_FX_SERVICE );

		int[] ids = filter.getParamIds();
		String[] values = filter.getParamValues();

		Ticket ticket = TicketFactory.create( filterId, mCurrentImage, ids, values );
		Response<RenderResponse> renderResult = service.render( ticket );

		if ( renderResult.getStatus() == STATUS.OK ) {
			Bitmap bitmap_result;
			bitmap_result = downloadImage( renderResult.getData() );
			if ( bitmap_result == null ) throw new IOException( "Sorry, there were problems downloading the image" );
			return bitmap_result;
		} else {
			throw new IOException( renderResult.getErrorMessage() );
		}
	}

	private Bitmap downloadImage( RenderResponse result ) throws IOException {

		Bitmap bitmap_result = ImageLoader.loadFromUri( mContext.getBaseContext(), Uri.parse( result.getImage().getStringUrl() ),
				Constants.getManagedMaxImageSize(), Constants.getManagedMaxImageSize(), null );
		return bitmap_result;
	}

	private UploadResponse uploadImage( Bitmap bitmap ) throws java.lang.Exception {

		RemoteFXService aviaryFxService = (RemoteFXService) mContext.getService( EffectContext.REMOTE_FX_SERVICE );

		Response<UploadResponse> uploadResult = null;
		FileOutputStream stream = null;
		File file = null;
		boolean shouldUploadBitmap = false;

		try {
			CacheManagerService cache = (CacheManagerService) mContext.getService( EffectContext.CACHE_SERVICE );
			file = cache.createTempFile( "remote", ".jpg" );
			stream = new FileOutputStream( file );
		} catch ( FileNotFoundException e ) {
			e.printStackTrace();
		}

		if ( stream != null ) {
			if ( bitmap.compress( CompressFormat.JPEG, 80, stream ) ) {
				try {
					uploadResult = aviaryFxService.upload( file.getAbsolutePath(), CompressFormat.JPEG );
				} catch ( FileNotFoundException e ) {
					shouldUploadBitmap = true;
				}
			}
			IOUtils.closeSilently( stream );
		} else {
			shouldUploadBitmap = true;
		}

		if ( shouldUploadBitmap ) {
			uploadResult = aviaryFxService.upload( bitmap, CompressFormat.JPEG, 80 );
		} else {}

		if ( uploadResult.getStatus() != STATUS.OK ) {
			throw new Exception( uploadResult.getErrorMessage() );
		}

		return uploadResult.getData();
	}

	class RemoteFilter {

		private String mFilterId;
		private int[] ids;
		private String[] values;

		public RemoteFilter( String filterid ) {
			mFilterId = filterid;
			generateParams();
		}

		private void generateParams() {
			if ( mFilterId.equals( "12" ) ) {
				
				// Instant
				
				ids = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
				values = new String[] {
					"0", "0xFFFFFFFF", "0.5", "0.5", "0", "1", "1", "1", "25", "25", "25", "250,250", "1", "0", "40", "1", "50", "1234",
					"8" };
				
			} else if ( mFilterId.equals( "21" ) ) {
				
				// Retro
				
				ids = new int[] {
					0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
					31, 32, 33 };
				values = new String[] {
					"0.02096658766292189", "0xFEFBF7", "0.039", "1755471334", "74.20863738311655", "0.61", "0.5463432524228337",
					"-734037463", "0.4426155314647163", "2.3285741892942635", "3", "4.503307795967745", "1373371288",
					"0.09838033667727847", "12.332506521216711", "0", "0", "-1177564320", "7", "0", "1521427415", "19", "0", "60136597",
					"0", "-829272973", "2", "0", "-4", "-6", "-0.5915167130510128", "-0.8803304154147232", "0.7992915887849619",
					"0.8351187742164168", };
				
			} else if ( mFilterId.equals( "14" ) ) {

				// First Camera
				
				ids = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17 };
				values = new String[] {
					"1", "128", "16", "0.652", "0", "0.358", "3.1", "3", "2", "0", "1", "0", "52", "1", "2920577764", "1", "0", "10", };

			} else if ( mFilterId.equals( "13" ) ) {
				
				// Toy camera
				
				ids = new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
				values = new String[] {
					"1", "1", "128", "16", "0.2", "0", "0.2", "2", "3", "2", "1", "25", "25", "25", "0.25", "1", "2", "1.5", "1", };

			} else {
				ids = new int[] {};
				values = new String[] {};
			}
		}

		public String[] getParamValues() {
			return values;
		}

		public int[] getParamIds() {
			return ids;
		}
	}

	@Override
	public void dispose() {
		mCurrentImage = null;
	};
}
