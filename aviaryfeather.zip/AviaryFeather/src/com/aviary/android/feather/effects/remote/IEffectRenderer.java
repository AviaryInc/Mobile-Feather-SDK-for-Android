package com.aviary.android.feather.effects.remote;

import java.io.IOException;
import android.graphics.Bitmap;


public interface IEffectRenderer {

	boolean upload( Bitmap bitmap );
	boolean getImageUploaded();
	Bitmap render( Bitmap bitmap, String filterId ) throws IOException;
	void dispose();

}
