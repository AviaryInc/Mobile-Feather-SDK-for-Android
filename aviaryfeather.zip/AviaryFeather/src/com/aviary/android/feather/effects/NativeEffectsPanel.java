package com.aviary.android.feather.effects;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.EffectLoaderService.NativeEffectEntry;
import com.aviary.android.feather.effects.NativeEffectsPanel.NativeEffectsAdapter.WorkspaceViewHolder;
import com.aviary.android.feather.library.filters.FilterLoaderFactory;
import com.aviary.android.feather.library.filters.NativeFilter;
import com.aviary.android.feather.library.filters.NativeFilterProxy;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.widget.WorkspaceAdapterView;
import com.aviary.android.feather.widget.WorkspaceAdapterView.OnLayoutListener;
import com.aviary.android.feather.widget.WorkspaceAdapterView.OnPageChangeListener;
import com.aviary.android.feather.widget.WorkspaceIndicator;


public class NativeEffectsPanel extends AbstractOptionPanel implements OnLayoutListener, OnPageChangeListener {
	
	private WorkspaceAdapterView mWorkspace;

	public NativeEffectsPanel( EffectContext context ) {
		super( context );
	}
	
	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );
		initWorkspace();
		loadEffects();
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_native_effects_panel, null );
	}
	
	@Override
	public void onActivate() {
		super.onActivate();
		
		setSelected( 0 );
	}

	void initWorkspace(){
		mWorkspace = (WorkspaceAdapterView) mOptionView.findViewById( R.id.effects_workspace );
		mWorkspace.setIndicator( (WorkspaceIndicator) mOptionView.findViewById( R.id.effects_page_indicator ) );
		mWorkspace.setOnLayoutListener( this );
		mWorkspace.setOnPageChangeListener( this );
	}

	void loadEffects(){
		EffectLoaderService service=  null;
		try {
			service = getContext().getService( EffectLoaderService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		NativeEffectEntry[] filters = service.getNativeEffects();
		
		NativeEffectsAdapter adapter = new NativeEffectsAdapter( getContext().getBaseContext(), R.layout.feather_native_effects_single_screen, -1, filters );
		mWorkspace.setAdapter( adapter );
	}
	
	void renderEffect( String tag ){
		final RenderTask task = new RenderTask( tag );
		task.execute( mBitmap );
	}
	
	private class RenderTask extends AsyncTask<Bitmap, Void, Bitmap> implements OnCancelListener {

		String mError;
		String mEffect;
		ProgressDialog mProgress = new ProgressDialog( getContext().getBaseContext() );

		public RenderTask( final String tag ) {
			mEffect = tag;
		}

		@Override
		protected Bitmap doInBackground( final Bitmap... params ) {

			final Bitmap bitmap = params[0];
			NativeFilter filter = FilterLoaderFactory.get( mEffect );
			
			Bitmap mOutput = null;
			long t1 = System.currentTimeMillis();
			try {
				mOutput = NativeFilterProxy.executeAction( filter.getType(), bitmap );
				
			} catch( Exception exception ){
				mLogger.error( exception.getMessage() );
				exception.printStackTrace();
				return null;
			}
			
			long t2 = System.currentTimeMillis();
			mTrackingAttributes.put( "renderTime", Long.toString( t2-t1 ) );
			return mOutput;
			
		}

		@Override
		protected void onPostExecute( final Bitmap result ) {
			super.onPostExecute( result );

			if ( mProgress.isShowing() ) mProgress.dismiss();
			if ( isCancelled() ) return;
			if ( result != null )
				onPreviewChanged( result );
			else {
				onGenericError( mError );
				mLogger.error( mError );
			}
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			mProgress.setTitle( getContext().getBaseContext().getString( R.string.effet_loading_title ) );
			mProgress.setMessage( getContext().getBaseContext().getString( R.string.effect_loading_message ) );
			mProgress.setIndeterminate( true );
			mProgress.setCancelable( false );
			mProgress.setOnCancelListener( this );
			mProgress.show();
		}

		@Override
		public void onCancel( DialogInterface dialog ) {
			mLogger.warning( "onCancel" );
		}
	}
	
	class NativeEffectsAdapter extends ArrayAdapter<NativeEffectEntry> {

		private LayoutInflater mLayoutInflater;
		private int mResourceId;

		public NativeEffectsAdapter( Context context, int resource, int textViewResourceId, NativeEffectEntry[] objects ) {
			super( context, resource, textViewResourceId, objects );
			mResourceId = resource;
			mLayoutInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		}

		@Override
		public int getCount() {
			return (int) Math.ceil( (double) super.getCount() / 4.0 );
		}

		int getTotalCount() {
			return super.getCount();
		}

		@Override
		public NativeEffectEntry getItem( int position ) {
			return super.getItem( position );
		}

		@Override
		public long getItemId( int position ) {
			return super.getItemId( position );
		}

		@Override
		public int getItemViewType( int position ) {
			return super.getItemViewType( position );
		}

		@Override
		public int getViewTypeCount() {
			return super.getViewTypeCount();
		}

		class WorkspaceViewHolder {
			public View option1, option2, option3, option4;
			public ImageView image1, image2, image3, image4;
			public TextView text1, text2, text3, text4;
		};

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {
			View view = null;
			WorkspaceViewHolder holder = null;

			if ( convertView != null ) {
				view = convertView;
				holder = (WorkspaceViewHolder) convertView.getTag();
			} else {
				view = mLayoutInflater.inflate( mResourceId, parent, false );
				holder = new WorkspaceViewHolder();
				holder.option1 = view.findViewById( R.id.option1 );
				holder.option2 = view.findViewById( R.id.option2 );
				holder.option3 = view.findViewById( R.id.option3 );
				holder.option4 = view.findViewById( R.id.option4 );
				holder.image1 = (ImageView) holder.option1.findViewById( R.id.thumb_option );
				holder.image2 = (ImageView) holder.option2.findViewById( R.id.thumb_option );
				holder.image3 = (ImageView) holder.option3.findViewById( R.id.thumb_option );
				holder.image4 = (ImageView) holder.option4.findViewById( R.id.thumb_option );
				
				holder.text1 = (TextView) holder.option1.findViewById( R.id.thumb_text );
				holder.text2 = (TextView) holder.option2.findViewById( R.id.thumb_text );
				holder.text3 = (TextView) holder.option3.findViewById( R.id.thumb_text );
				holder.text4 = (TextView) holder.option4.findViewById( R.id.thumb_text );
				
				view.setTag( holder );
			}

			int curPos = position * 4;

			holder.option1.setTag( curPos );
			holder.option2.setTag( curPos + 1 );
			holder.option3.setTag( curPos + 2 );
			holder.option4.setTag( curPos + 3 );
			
			loadEffectForImage( curPos, holder.option1, holder.image1, holder.text1 );
			loadEffectForImage( curPos + 1, holder.option2, holder.image2, holder.text2 );
			loadEffectForImage( curPos + 2, holder.option3, holder.image3, holder.text3 );
			loadEffectForImage( curPos + 3, holder.option4, holder.image4, holder.text4 );
			
			return view;
		}

		private void loadEffectForImage( final int position, final View optionView, ImageView view, TextView textView ) {
			if ( position < getTotalCount() ) {
				final NativeEffectEntry item = getItem( position );
				
				if( position != mSelectedIndex )
					optionView.setSelected( false );
				
				if( position == mSelectedIndex ){
					setSelected( optionView );
				}
				
				optionView.setVisibility( View.VISIBLE );
				textView.setText( item.labelResourceId );
				view.setImageResource( item.iconResourceId );
				view.setOnClickListener( new OnClickListener() {

					@Override
					public void onClick( View v ) {
						mSelectedIndex = position;
						setSelected( optionView );
						renderEffect( item.name );
					}
				} );
			} else {
				optionView.setVisibility( View.INVISIBLE );
			}
		}
	}
	
	private View mSelectedView;
	private int mSelectedIndex = -1;
	
	protected void setSelected( View view ) {
		
		if( mSelectedView != null ){
			mSelectedView.setSelected( false );
		}
		mSelectedView = null;
		
		if( view != null ){
			mSelectedView = view;
			mSelectedView.setSelected( true );
		}
		mWorkspace.requestLayout();
	}
	
	void setSelected( int position ){
		mSelectedIndex = position;
		int screen = mWorkspace.getCurrentScreen();
		View child = mWorkspace.getScreenAt( screen );
		Object tag = child.getTag();
		if( tag != null && tag instanceof WorkspaceViewHolder ){
			WorkspaceViewHolder holder = (WorkspaceViewHolder) tag;
			if( holder.option1.getTag() != null && holder.option1.getTag().equals( position ) ){
				setSelected( holder.option1 );
			}
		}
		mWorkspace.forceLayout();
	}

	@Override
	public void onLayout( boolean changed, int left, int top, int right, int bottom ) {
	}

	@Override
	public void onPageChanged( int pageNum, int totalPages ) {
	}
}
