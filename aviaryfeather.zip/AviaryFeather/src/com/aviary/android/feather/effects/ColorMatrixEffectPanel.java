package com.aviary.android.feather.effects;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;

import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.ILevelFilter;
import com.aviary.android.feather.library.utils.BitmapUtils;

public class ColorMatrixEffectPanel extends ThumbnailsEffectOptionPanel {

	public static enum LEVEL {
		BRIGHTNESS, SATURATION, CONTRAST
	};

	protected ColorMatrixColorFilter mCurrent;
	protected LEVEL mFilterType;

	public ColorMatrixEffectPanel( EffectContext context, LEVEL filterType ) {
		super( context );
		mFilterType = filterType;
	}

	@Override
	protected IFilter createFilter() {
		
		final FilterService service = (FilterService) getContext().getService( EffectContext.FILTER_SERVICE );
		
		switch( mFilterType ) {
			case BRIGHTNESS:
				return service.load( Filters.BRIGHTNESS );

			case SATURATION:
				return service.load( Filters.SATURATION );

			case CONTRAST:
				return service.load( Filters.CONTRAST );

		}
		return null;
	}

	@Override
	protected Bitmap getThumbnail( int index, Bitmap input, int width, int height, int backgroundColor ) {
		return BitmapUtils.createThumbnail( input, width, height, getFilter( index ), backgroundColor );
	}

	@Override
	protected void onOptionClick( int index ) {
		mCurrent = getFilter( index );

		Bitmap bitmap = Bitmap.createBitmap( mBitmap.getWidth(), mBitmap.getHeight(), Bitmap.Config.RGB_565 );
		Canvas canvas = new Canvas( bitmap );
		Paint paint = new Paint( Paint.ANTI_ALIAS_FLAG );
		paint.setColorFilter( mCurrent );
		canvas.drawBitmap( mBitmap, 0, 0, paint );
		onPreviewChanged( bitmap );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	protected ColorMatrixColorFilter getFilter( int index ) {
		float value = ((ILevelFilter)mFilter).getAmount( index, getTotalOptions() );
		return ((ILevelFilter) mFilter).apply( value );
	}

	@Override
	protected int getDefaultThumbnailResourceId( int index ) {
		
		if( mFilterType == LEVEL.BRIGHTNESS ){
			switch( index ) {
				case 0:
					return R.drawable.brightness_thumb_0;
				case 1:
					return R.drawable.brightness_thumb_1;
				case 2:
					return R.drawable.brightness_thumb_2;
				case 3:
					return R.drawable.brightness_thumb_3;
			}
		} else if( mFilterType == LEVEL.CONTRAST ){
			switch( index ) {
				case 0:
					return R.drawable.contrast_thumb_0;
				case 1:
					return R.drawable.contrast_thumb_1;
				case 2:
					return R.drawable.contrast_thumb_2;
				case 3:
					return R.drawable.contrast_thumb_3;
			}
		} else if( mFilterType == LEVEL.SATURATION ){
			switch( index ) {
				case 0:
					return R.drawable.saturation_thumb_0;
				case 1:
					return R.drawable.saturation_thumb_1;
				case 2:
					return R.drawable.saturation_thumb_2;
				case 3:
					return R.drawable.saturation_thumb_3;
			}			
		}
		
		return 0;
	}

	@Override
	protected int getTotalOptions() {
		return 4;
	}

	@Override
	protected ThumbnailMode getThumbnailGenerationMode() {
		return super.getThumbnailGenerationMode();
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_four_options_panel, null );
	}
}
