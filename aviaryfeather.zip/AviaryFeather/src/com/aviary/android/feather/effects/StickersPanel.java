package com.aviary.android.feather.effects;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import com.aviary.android.feather.R;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager.Thumb;
import com.aviary.android.feather.library.graphics.drawable.FeatherDrawable;
import com.aviary.android.feather.library.graphics.drawable.StickerDrawable;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.MatrixUtils;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.DrawableHighlightView;
import com.aviary.android.feather.widget.DrawableHighlightView.OnDeleteClickListener;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay;
import com.aviary.android.feather.widget.wp.CellLayout;
import com.aviary.android.feather.widget.wp.CellLayout.CellInfo;
import com.aviary.android.feather.widget.wp.Workspace;
import com.aviary.android.feather.widget.wp.WorkspaceIndicator;

public class StickersPanel extends AbstractContentPanel {

	private static enum Status {
		Null, Sticker,
	}

	private Workspace mWorkspace;
	private WorkspaceIndicator mWorkspaceIndicator;
	private View mApplyStateView, mStickersView;
	private Button mAddAnother, mClearAll;
	private AssetsAsyncDownloadManager mDownloadManager;
	private Canvas mCanvas;
	private int mStickerMinSize;
	private int mStickerPadding = 0;
	private View mLoadingTextView;
	private int outlineColorNormal, outlineColorPressed;
	private int mScreenRows = 1;
	private int mScreenCols, mItemsPerPage;

	private Status mStatus = Status.Null;
	private ArrayList<String> stickerNames;

	private boolean mStickersLoaded;
	private boolean mConfigurationChanged;

	private final Handler mHandler = new Handler() {

		@Override
		public void handleMessage( Message msg ) {

			switch ( msg.what ) {
				case AssetsAsyncDownloadManager.THUMBNAIL_LOADED:

					//mLogger.debug( "THUMBNAIL_LOADED", mStickersLoaded, mConfigurationChanged );

					Thumb thumb = (Thumb) msg.obj;

					if ( thumb.image != null ) {
						thumb.image.setImageBitmap( thumb.bitmap );
					}

					if ( !mStickersLoaded ) {

						if ( mLoadingTextView.getVisibility() == View.VISIBLE ) {
							mLoadingTextView.setVisibility( View.GONE );
							mWorkspace.setVisibility( View.VISIBLE );
						}

						if ( mWorkspace.getVisibility() != View.VISIBLE ) {
							mWorkspace.setVisibility( View.VISIBLE );
							mWorkspace.requestLayout();
						}
						mStickersLoaded = true;
					}

					if ( mStickersLoaded ) {
						if ( mConfigurationChanged ) {

							mStickersLoaded = false;
							mConfigurationChanged = false;
							mDownloadManager.clearCache();
							mWorkspace.setAdapter( null );
							initWorkspace();
							loadStickers();
						}
					}

					break;
			}
		}
	};

	public StickersPanel( EffectContext context ) {
		super( context );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mStickersLoaded = false;
		mConfigurationChanged = false;

		mImageView = (ImageViewDrawableOverlay) getContentView().findViewById( R.id.overlay );
		mImageView.setDoubleTapEnabled( false );
		mLoadingTextView = getOptionView().findViewById( R.id.loading_text );

		mDownloadManager = new AssetsAsyncDownloadManager( this.getContext().getBaseContext(), mHandler );

		createAndConfigurePreview();
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
		
		initWorkspace();
	}

	@Override
	public void onConfigurationChanged( Configuration newConfig ) {
		super.onConfigurationChanged( newConfig );
		mLogger.info( "onConfigurationChanged" );
		mConfigurationChanged = true;
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();
	}

	@Override
	public void onActivate() {
		super.onActivate();
		mImageView.requestLayout();

		stickerNames = new ArrayList<String>();

		ConfigService config = null;
		try {
			config = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}

		mStickerMinSize = config.getInteger( R.integer.sticker_minsize );
		mStickerPadding = config.getInteger( R.integer.sticker_padding );
		outlineColorNormal = config.getColor( R.color.sticker_outline_normal );
		outlineColorPressed = config.getColor( R.color.sticker_outline_pressed );

		contentReady();
		loadStickers();
	}

	private void createAndConfigurePreview() {

		if ( mPreview != null && !mPreview.isRecycled() ) {
			mPreview.recycle();
			mPreview = null;
		}

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mCanvas = new Canvas( mPreview );
	}

	@Override
	public void onDestroy() {
		mDownloadManager.clearCache();
		mDownloadManager.shutDownNow();
		mCanvas = null;
		super.onDestroy();
	}

	@Override
	protected void onGenerateResult() {
		onApplyCurrent();
		super.onGenerateResult();
	}

	private void initWorkspace() {
		mLogger.info( "initWorkspace" );

		mWorkspaceIndicator = (com.aviary.android.feather.widget.wp.WorkspaceIndicator) mOptionView
				.findViewById( R.id.workspace_indicator );
		mWorkspace = (Workspace) mOptionView.findViewById( R.id.workspace );
		mWorkspace.setHapticFeedbackEnabled( false );
		mWorkspace.setIndicator( mWorkspaceIndicator );
		
		ConfigService config = null;
		try {
			config = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			e.printStackTrace();
		}
		if( config != null )
		{
			mScreenRows = config.getInteger( R.integer.config_portraitRows );
			mScreenCols = config.getInteger( R.integer.config_portraitCells );
			mItemsPerPage = mScreenCols * mScreenRows;
		}
		
		DisplayMetrics metrics = getContext().getBaseContext().getResources().getDisplayMetrics();
		mScreenCols = ( metrics.widthPixels / 100 );
		mItemsPerPage = mScreenRows * mScreenCols;		

		mApplyStateView = mOptionView.findViewById( R.id.apply_state_layout );
		mStickersView = mOptionView.findViewById( R.id.stickers_bottombar );
		mAddAnother = (Button) mOptionView.findViewById( R.id.add_another );
		mClearAll = (Button) mOptionView.findViewById( R.id.clear_all );

		mAddAnother.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				onApplyCurrent();
			}
		} );

		mClearAll.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				onClearAll();
			}
		} );

		mLoadingTextView.setVisibility( View.VISIBLE );
		mWorkspace.setVisibility( View.INVISIBLE );
	}

	private void loadStickers() {

		mLogger.info( "loadStickers" );

		mHandler.post( new Runnable() {

			@Override
			public void run() {

				String[] list = null;
				try {
					list = getContext().getBaseContext().getAssets().list( "stickers" );
				} catch ( IOException e ) {
					e.printStackTrace();
				}

				if ( list != null && list.length > 0 ) {

					mLogger.debug( "loaded stickers!", list.length );
					StickersAdapter adapter = new StickersAdapter( getContext().getBaseContext(), R.layout.feather_workspace_screen,
							R.layout.feather_sticker_thumb, list );
					mWorkspace.setAdapter( adapter );
				}

			}
		} );
	}

	private void onApplyCurrent() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getHighlightCount() < 1 ) return;

		final DrawableHighlightView hv = ( (ImageViewDrawableOverlay) mImageView ).getHighlightViewAt( 0 );

		if ( hv != null ) {

			RectF cropRect = hv.getCropRectF();
			Rect rect = new Rect( (int) cropRect.left, (int) cropRect.top, (int) cropRect.right, (int) cropRect.bottom );

			Matrix rotateMatrix = hv.getCropRotationMatrix();
			Matrix matrix = new Matrix( mImageView.getImageMatrix() );
			if ( !matrix.invert( matrix ) ) {
				Log.e( "stickers", "unale to invert matrix" );
			}

			int saveCount = mCanvas.save( Canvas.MATRIX_SAVE_FLAG );
			mCanvas.concat( rotateMatrix );
			hv.getContent().setBounds( rect );
			hv.getContent().draw( mCanvas );
			mCanvas.restoreToCount( saveCount );
			mImageView.invalidate();
		}
		onClearCurrent( true );
		onPreviewChanged( mPreview, false );
	}

	private void onClearCurrent( boolean isApplying ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		if ( image.getHighlightCount() > 0 ) {
			final DrawableHighlightView hv = image.getHighlightViewAt( 0 );
			onClearCurrent( hv, isApplying );
		}
	}

	private void onClearCurrent( DrawableHighlightView hv, boolean isApplying ) {
		if ( !isApplying ) if ( stickerNames.size() > 0 ) stickerNames.remove( stickerNames.size() - 1 );

		hv.setOnDeleteClickListener( null );
		( (ImageViewDrawableOverlay) mImageView ).removeHightlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).invalidate();
		setStatus( Status.Null );
	}

	private void onAskClearCurrent() {

		android.content.DialogInterface.OnClickListener yesListener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick( DialogInterface dialog, int which ) {
				if ( which == DialogInterface.BUTTON_POSITIVE ) {
					onClearCurrent( false );
				}
				dialog.dismiss();
			}
		};

		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.sticker_delete_title )
				.setMessage( R.string.sticker_delete_message ).setPositiveButton( R.string.yes_remove, yesListener )
				.setNegativeButton( android.R.string.no, yesListener ).show();
	}

	private void onClearAll() {
		onClearCurrent( false );
		onPreviewChanged( null, false );

		stickerNames = new ArrayList<String>();

		mImageView.setImageBitmapReset( null, false );
		createAndConfigurePreview();
		mImageView.setImageBitmapReset( mPreview, false );
	}

	private void addSticker( String drawable ) {
		final boolean rotateAndResize = true;
		InputStream stream = null;
		try {
			stream = getContext().getBaseContext().getAssets().open( drawable );
		} catch ( IOException e ) {
			e.printStackTrace();
		}

		if ( stream != null ) {
			StickerDrawable d = new StickerDrawable( getContext().getBaseContext().getResources(), stream );
			d.setAntiAlias( true );

			stickerNames.add( drawable );

			addSticker( d, rotateAndResize );

			try {
				stream.close();
			} catch ( IOException e ) {}
		}
	}

	private void addSticker( FeatherDrawable drawable, boolean rotateAndResize ) {
		setIsChanged( true );

		DrawableHighlightView hv = new DrawableHighlightView( mImageView, drawable );
		hv.setMinSize( mStickerMinSize );
		hv.setOnDeleteClickListener( new OnDeleteClickListener() {

			@Override
			public void onDeleteClick() {
				onAskClearCurrent();
			}
		} );

		Matrix mImageMatrix = mImageView.getImageViewMatrix();

		final int width = mImageView.getWidth();
		final int height = mImageView.getHeight();

		// width/height of the sticker
		final int cropWidth = drawable.getIntrinsicWidth();
		final int cropHeight = drawable.getIntrinsicHeight();

		int x = ( width - cropWidth ) / 2;
		int y = ( height - cropHeight ) / 2;

		Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		float[] pts = new float[] { x, y, x + cropWidth, y + cropHeight };
		MatrixUtils.mapPoints( matrix, pts );

		RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );
		Rect imageRect = new Rect( 0, 0, width, height );

		hv.setRotateAndScale( rotateAndResize );
		hv.setup( mImageMatrix, imageRect, cropRect, false );
		hv.drawOutlineFill( true );
		hv.drawOutlineStroke( false );
		hv.setPadding( mStickerPadding );

		hv.getOutlineFillPaint().setXfermode( new PorterDuffXfermode( android.graphics.PorterDuff.Mode.SRC_ATOP ) );
		hv.setOutlineFillColor( outlineColorNormal );
		hv.setOutlineFillColorPressed( outlineColorPressed );

		( (ImageViewDrawableOverlay) mImageView ).addHighlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).setSelectedHighlightView( hv );
		setStatus( Status.Sticker );
	}

	void setStatus( Status status ) {
		if ( status != mStatus ) {
			mStatus = status;

			Animation fade_in = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_in );
			Animation fade_out = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_out );

			if ( status == Status.Null ) {
				mStickersView.startAnimation( fade_in );
				mApplyStateView.startAnimation( fade_out );
			} else {
				mStickersView.startAnimation( fade_out );
				mApplyStateView.startAnimation( fade_in );
			}

			fade_in.setAnimationListener( mInAnimationListener );
			fade_out.setAnimationListener( mOutAnimationListener );
		}
	}

	AnimationListener mInAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationEnd( Animation animation ) {}

		@Override
		public void onAnimationRepeat( Animation animation ) {}

		@Override
		public void onAnimationStart( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mStickersView.setVisibility( View.VISIBLE );
			} else {
				mApplyStateView.setVisibility( View.VISIBLE );
			}
		}
	};

	AnimationListener mOutAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationEnd( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mApplyStateView.setVisibility( View.INVISIBLE );
			} else {
				mStickersView.setVisibility( View.INVISIBLE );
			}
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {}

		@Override
		public void onAnimationStart( Animation animation ) {
			if ( mStatus == Status.Null ) {
				mStickersView.setVisibility( View.VISIBLE );
			} else {
				mApplyStateView.setVisibility( View.VISIBLE );
			}
		}
	};

	@Override
	public Bitmap render() {
		return null;
	}

	class StickersAdapter extends ArrayAdapter<String> {

		private LayoutInflater mLayoutInflater;
		private int mResourceId;
		private int mStickerResourceId;
		private int mFinalSize;

		public StickersAdapter( Context context, int resource, int textViewResourceId, String[] objects ) {
			super( context, resource, textViewResourceId, objects );
			mResourceId = resource;
			mStickerResourceId = textViewResourceId;
			mLayoutInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
			mFinalSize = -1;
		}

		@Override
		public int getCount() {
			return (int) Math.ceil( (double) super.getCount() / mItemsPerPage );
		}

		public int getRealCount() {
			return super.getCount();
		}

		@Override
		public String getItem( int position ) {
			return super.getItem( position );
		}

		@Override
		public long getItemId( int position ) {
			return super.getItemId( position );
		}

		@Override
		public int getItemViewType( int position ) {
			return super.getItemViewType( position );
		}

		@Override
		public int getViewTypeCount() {
			return super.getViewTypeCount();
		}

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			if ( mFinalSize == -1 ) {
				int w = getOptionView().getWidth();
				int h = getOptionView().getHeight();
				int destWidth = ( w / mScreenCols );
				int destHeight = h - 20;
				mFinalSize = Math.min( destWidth, destHeight );
				mDownloadManager.setThumbSize( mFinalSize );
				mLogger.info( "thumb size: " + mFinalSize );
			}

			if ( convertView == null ) {
				convertView = mLayoutInflater.inflate( mResourceId, mWorkspace, false );
				( (CellLayout) convertView ).setNumCols( mScreenCols );
			}

			CellLayout cell = (CellLayout) convertView;
			int index = position * mItemsPerPage;
			int realCount = getRealCount();

			for ( int i = 0; i < mItemsPerPage; i++ ) {
				View view;
				CellInfo cellInfo = cell.findVacantCell( 1, 1 );

				if ( cellInfo == null ) {
					view = cell.getChildAt( i );
				} else {
					view = mLayoutInflater.inflate( mStickerResourceId, parent, false );
					CellLayout.LayoutParams lp = new CellLayout.LayoutParams( cellInfo.cellX, cellInfo.cellY, cellInfo.spanH,
							cellInfo.spanV );
					cell.addView( view, -1, lp );
				}

				if ( ( index + i ) < realCount ) {
					view.setTag( index + i );
					ImageView imageView = (ImageView) view.findViewById( R.id.thumb_option );
					loadStickerForImage( index + i, imageView );
					view.setVisibility( View.VISIBLE );
				} else {
					view.setVisibility( View.INVISIBLE );
				}
			}

			convertView.requestLayout();
			return convertView;
		}

		private void loadStickerForImage( int position, ImageView view ) {
			final String sticker = "stickers/" + getItem( position );

			mDownloadManager.loadAsset( getContext().getResources(), sticker, view );
			view.setOnClickListener( new OnClickListener() {

				@Override
				public void onClick( View v ) {
					addSticker( sticker );
				}
			} );
		}
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_stickers_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_stickers_panel, null );
	}

	@Override
	protected void onComplete( Bitmap bitmap ) {
		mTrackingAttributes.put( "stickersCount", Integer.toString( stickerNames.size() ) );
		mTrackingAttributes.put( "stickersName", getStickersNames() );
		super.onComplete( bitmap );
	}

	String getStickersNames() {
		StringBuilder sb = new StringBuilder();
		for ( String s : stickerNames ) {
			sb.append( s );
			sb.append( "," );
		}
		return sb.toString();
	}
}
