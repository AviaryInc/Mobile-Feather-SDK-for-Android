package com.aviary.android.feather.effects;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.aviary.android.feather.Constants;
import com.aviary.android.feather.R;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager;
import com.aviary.android.feather.async_tasks.AssetsAsyncDownloadManager.Thumb;
import com.aviary.android.feather.graphics.RepeatableHorizontalDrawable;
import com.aviary.android.feather.graphics.StickerBitmapDrawable;
import com.aviary.android.feather.library.content.FeatherIntent;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.graphics.drawable.FeatherDrawable;
import com.aviary.android.feather.library.graphics.drawable.StickerDrawable;
import com.aviary.android.feather.library.plugins.PluginManager;
import com.aviary.android.feather.library.plugins.PluginManager.UpdateType;
import com.aviary.android.feather.library.services.ConfigService;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.PluginService;
import com.aviary.android.feather.library.services.PluginService.OnUpdateListener;
import com.aviary.android.feather.library.tracking.Tracker;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.IOUtils;
import com.aviary.android.feather.library.utils.MatrixUtils;
import com.aviary.android.feather.library.utils.ResourceManager;
import com.aviary.android.feather.utils.UIUtils;
import com.aviary.android.feather.widget.DrawableHighlightView;
import com.aviary.android.feather.widget.DrawableHighlightView.OnDeleteClickListener;
import com.aviary.android.feather.widget.HorizontialFixedListView;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay;
import com.aviary.android.feather.widget.wp.CellLayout;
import com.aviary.android.feather.widget.wp.CellLayout.CellInfo;
import com.aviary.android.feather.widget.wp.Workspace;
import com.aviary.android.feather.widget.wp.WorkspaceIndicator;

public class StickersPanel extends AbstractContentPanel implements OnUpdateListener {

	private static enum Status {

		Null, // home
		Packs, // pack display
		Stickers, // stickers
		Sticker, // single sticker
	}

	/** The default get more icon. */
	private Drawable mFolderIcon, mGetMoreIcon;

	private int mStickerHvEllipse, mStickerHvStrokeWidth, mStickerHvStrokeColor, mStickerHvStrokeColorDown, mStickerHvMinSize;
	private int mStickerHvPadding, mStickerHvColor, mStickerHvColorDown;

	private Workspace mWorkspace;
	private WorkspaceIndicator mWorkspaceIndicator;
	private HorizontialFixedListView mHList;
	private ViewFlipper mViewFlipper;
	private int mStickerMinSize;
	private Canvas mCanvas;
	private AssetsAsyncDownloadManager mDownloadManager;
	private PluginService mPluginService;
	private int mWorkspaceCols;
	private int mWorkspaceRows;
	private int mWorkspaceItemsPerPage;
	private List<String> mUsedStickers;
	private List<String> mUsedStickersPacks;
	private static HashSet<String> mRegisteredPackages = new HashSet<String>();
	private ResourceManager mResourceManager;
	private ConfigService mConfig;
	private Status mStatus = Status.Null;
	private Status mPrevStatus = Status.Null;

	/**
	 * Instantiates a new stickers panel.
	 * 
	 * @param context
	 *           the context
	 */
	public StickersPanel( EffectContext context ) {
		super( context );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onCreate(android.graphics.Bitmap)
	 */
	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mUsedStickers = new ArrayList<String>();
		mUsedStickersPacks = new ArrayList<String>();

		mConfig = getContext().getService( ConfigService.class );
		mDownloadManager = new AssetsAsyncDownloadManager( this.getContext().getBaseContext(), mHandler );

		mImageView = (ImageViewDrawableOverlay) mDrawingPanel.findViewById( R.id.overlay );
		mImageView.setDoubleTapEnabled( false );
		( (ImageViewDrawableOverlay) mImageView ).setForceSingleSelection( false );

		mWorkspaceIndicator = (WorkspaceIndicator) mOptionView.findViewById( R.id.workspace_indicator );

		mHList = (HorizontialFixedListView) mOptionView.findViewById( R.id.gallery );

		mWorkspace = (Workspace) mOptionView.findViewById( R.id.workspace );
		mWorkspace.setHapticFeedbackEnabled( false );
		mWorkspace.setIndicator( mWorkspaceIndicator );
		// mWorkspace.setVisibility( View.INVISIBLE );

		mViewFlipper = (ViewFlipper) mOptionView.findViewById( R.id.flipper );

		mResourceManager = null;
		mPrevStatus = mStatus = Status.Null;

		mPluginService = getContext().getService( PluginService.class );

		mStickerHvEllipse = mConfig.getInteger( R.integer.feather_sticker_highlight_ellipse );
		mStickerHvStrokeWidth = mConfig.getInteger( R.integer.feather_sticker_highlight_stroke_width );
		mStickerHvStrokeColor = mConfig.getColor( R.color.feather_sticker_highlight_stroke );
		mStickerHvStrokeColorDown = mConfig.getColor( R.color.feather_sticker_highlight_stroke_down );
		mStickerHvMinSize = mConfig.getInteger( R.integer.feather_sticker_highlight_minsize );
		mStickerHvPadding = mConfig.getInteger( R.integer.feather_sticker_highlight_padding );
		mStickerHvColor = mConfig.getColor( R.color.feather_sticker_highlight_outline );
		mStickerHvColorDown = mConfig.getColor( R.color.feather_sticker_highlight_outline_down );
	}

	/**
	 * Screen configuration has changed.
	 * 
	 * @param newConfig
	 *           the new config
	 */

	@Override
	public void onConfigurationChanged( Configuration newConfig ) {
		super.onConfigurationChanged( newConfig );

		// we need to reload the current adapter...
		initWorkspace();
		mDownloadManager.clearCache();

		if ( mStatus == Status.Null || mStatus == Status.Packs ) {
			loadPacks();
		} else {
			loadStickers();
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onDeactivate()
	 */
	@Override
	public void onDeactivate() {
		super.onDeactivate();
		mPluginService.removeOnUpdateListener( this );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onActivate()
	 */
	@Override
	public void onActivate() {
		super.onActivate();
		// getting the packs installed

		// initialize the workspace
		initWorkspace();

		// initialize the content bitmap
		createAndConfigurePreview();

		mImageView.setImageBitmap( mPreview, true, getContext().getCurrentImageViewMatrix(), Constants.IMAGE_VIEW_MAX_ZOOM );
		mPluginService.registerOnUpdateListener( this );

		setStatus( Status.Packs );

		// Animation animation = new AlphaAnimation( 0.0f, 1.0f );
		Animation animation = new TranslateAnimation( TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF, 0,
				TranslateAnimation.RELATIVE_TO_SELF, 1, TranslateAnimation.RELATIVE_TO_SELF, 0 );

		animation.setDuration( 300 );
		animation.setStartOffset( 0 );
		animation.setInterpolator( AnimationUtils.loadInterpolator( getContext().getBaseContext(),
				android.R.anim.decelerate_interpolator ) );
		animation.setFillEnabled( true );
		animation.setAnimationListener( new AnimationListener() {

			@Override
			public void onAnimationStart( Animation animation ) {}

			@Override
			public void onAnimationRepeat( Animation animation ) {}

			@Override
			public void onAnimationEnd( Animation animation ) {
				getContentView().setVisibility( View.VISIBLE );
				contentReady();
			}
		} );

		mWorkspace.startAnimation( animation );
		mWorkspace.setVisibility( View.VISIBLE );
	}

	/**
	 * Send user to the default android market, if available, to find more 'stickers'.
	 */
	public void findMoreThemes() {
		Intent intent = new Intent( Intent.ACTION_VIEW );
		intent.setData( Uri.parse( "market://search?q=" + FeatherIntent.PLUGIN_BASE_PACKAGE + "*" ) );
		try {
			Tracker.recordTag( Filters.STICKERS.name().toLowerCase() + ": get_more_stickers" );
			getContext().getBaseContext().startActivity( intent );
		} catch ( ActivityNotFoundException e ) {
			e.printStackTrace();
		}
	}

	/**
	 * Initialize the preview bitmap and canvas.
	 */
	private void createAndConfigurePreview() {

		if ( mPreview != null && !mPreview.isRecycled() ) {
			mPreview.recycle();
			mPreview = null;
		}

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mCanvas = new Canvas( mPreview );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onDestroy()
	 */
	@Override
	public void onDestroy() {
		if ( mDownloadManager != null ) {
			mDownloadManager.clearCache();
			mDownloadManager.shutDownNow();
		}

		if ( mResourceManager != null ) {
			mResourceManager = null;
		}

		mCanvas = null;
		super.onDestroy();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onGenerateResult()
	 */
	@Override
	protected void onGenerateResult() {
		onApplyCurrent( false );
		super.onGenerateResult();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onBackPressed()
	 */
	@Override
	public boolean onBackPressed() {
		if ( backHandled() ) return true;
		return false;
	}

	/**
	 * Manager asked to cancel this panel Before leave ask user if he really want to leave and lose all stickers.
	 * 
	 * @return true, if successful
	 */
	@Override
	public boolean onCancel() {
		if ( stickersOnScreen() ) {
			askToLeaveWithoutApply();
			return true;
		}

		return false;
	}

	/**
	 * Set the current pack as active and display its content.
	 * 
	 * @param info
	 *           the new current pack
	 */
	private void setCurrentPack( ApplicationInfo info ) {

		if ( info == null ) {
			findMoreThemes();
			return;
		}

		try {
			mResourceManager = new ResourceManager( getContext().getBaseContext(), info );
		} catch ( NameNotFoundException e ) {
			onGenericError( "The selected pack does not exist!" );
			e.printStackTrace();
			return;
		}

		/**
		 * send the event only once
		 */
		if ( !mRegisteredPackages.contains( info.packageName ) ) {
			mRegisteredPackages.add( info.packageName );
			HashMap<String, String> map = new HashMap<String, String>();
			map.put( "packagename", info.packageName );
			Tracker.recordTag( Filters.STICKERS.name().toLowerCase() + ": run package", map );
		}

		setStatus( Status.Stickers );
	}

	/**
	 * Return an array of installed packages.
	 * 
	 * @return the installed packs
	 */
	private ApplicationInfo[] getInstalledPacks() {
		return mPluginService.getInstalledStickers();
	}

	/**
	 * Load all the available stickers packs.
	 */
	private void loadPacks() {
		updateInstalledPacks();
		if ( mViewFlipper.getDisplayedChild() != 0 ) {
			mViewFlipper.setDisplayedChild( 0 );
		}
	}

	/**
	 * Reload the installed packs and reload the workspace adapter.
	 */
	private void updateInstalledPacks() {
		ApplicationInfo packs[] = getInstalledPacks();
		StickersPacksAdapter adapter = new StickersPacksAdapter( getContext().getBaseContext(), R.layout.feather_workspace_screen,
				R.layout.feather_sticker_pack, packs );
		mWorkspace.setAdapter( adapter );
		mWorkspaceIndicator.setVisibility( mWorkspace.getTotalPages() > 1 ? View.VISIBLE : View.INVISIBLE );
		mDownloadManager.clearCache();
	}

	/**
	 * Load all the available stickers for the selected pack.
	 */
	private void loadStickers() {
		String[] list = mResourceManager.listAssets( PluginService.STICKERS );
		String[] listcopy = new String[list.length + 2];

		System.arraycopy( list, 0, listcopy, 1, list.length );

		mViewFlipper.setDisplayedChild( 1 );

		if ( list != null ) {
			getOptionView().post( new LoadStickersRunner( listcopy ) );
		}
	}

	/**
	 * The Class LoadStickersRunner.
	 */
	private class LoadStickersRunner implements Runnable {

		/** The mlist. */
		String[] mlist;

		/**
		 * Instantiates a new load stickers runner.
		 * 
		 * @param list
		 *           the list
		 */
		LoadStickersRunner( String[] list ) {
			mlist = list;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see java.lang.Runnable#run()
		 */
		@Override
		public void run() {

			if ( mHList.getHeight() == 0 ) {
				mOptionView.post( this );
				return;
			}

			StickersAdapter adapter = new StickersAdapter( getContext().getBaseContext(), R.layout.feather_sticker_thumb, mlist );
			mHList.setAdapter( adapter );
			mHList.setOnItemClickListener( new OnItemClickListener() {

				@Override
				public void onItemClick( AdapterView<?> parent, View view, int position, long id ) {
					final String sticker = "stickers/" + parent.getAdapter().getItem( position );
					addSticker( sticker );
				}
			} );
			mlist = null;
		}
	}

	/**
	 * Inits the workspace.
	 */
	private void initWorkspace() {

		ConfigService config = getContext().getService( ConfigService.class );
		if ( config != null ) {
			mWorkspaceRows = Math.max( config.getInteger( R.integer.feather_config_portraitRows ), 1 );
		} else {
			mWorkspaceRows = 1;
		}

		mFolderIcon = getContext().getBaseContext().getResources().getDrawable( R.drawable.feather_sticker_pack_background );
		mGetMoreIcon = getContext().getBaseContext().getResources().getDrawable( R.drawable.feather_sticker_pack_background_more );
		mWorkspaceCols = UIUtils.getScreenOptimalColumns( mFolderIcon.getIntrinsicWidth() + 30 );
		mWorkspaceItemsPerPage = mWorkspaceRows * mWorkspaceCols;
	}

	/**
	 * Flatten the current sticker within the preview bitmap no more changes will be possible on this sticker.
	 * 
	 * @param updateStatus
	 *           the update status
	 */
	private void onApplyCurrent( boolean updateStatus ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getHighlightCount() < 1 ) return;

		final DrawableHighlightView hv = ( (ImageViewDrawableOverlay) mImageView ).getHighlightViewAt( 0 );

		if ( hv != null ) {

			RectF cropRect = hv.getCropRectF();
			Rect rect = new Rect( (int) cropRect.left, (int) cropRect.top, (int) cropRect.right, (int) cropRect.bottom );

			Matrix rotateMatrix = hv.getCropRotationMatrix();
			Matrix matrix = new Matrix( mImageView.getImageMatrix() );
			if ( !matrix.invert( matrix ) ) {}

			int saveCount = mCanvas.save( Canvas.MATRIX_SAVE_FLAG );
			mCanvas.concat( rotateMatrix );

			( (StickerDrawable) hv.getContent() ).setDropShadow( false );
			hv.getContent().setBounds( rect );
			hv.getContent().draw( mCanvas );
			mCanvas.restoreToCount( saveCount );
			mImageView.invalidate();
		}
		onClearCurrent( true, updateStatus );
		onPreviewChanged( mPreview, false );
	}

	/**
	 * Remove the current sticker.
	 * 
	 * @param isApplying
	 *           if true is passed it means we're currently in the "applying" status
	 * @param updateStatus
	 *           if true will update the internal status
	 */
	private void onClearCurrent( boolean isApplying, boolean updateStatus ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		if ( image.getHighlightCount() > 0 ) {
			final DrawableHighlightView hv = image.getHighlightViewAt( 0 );
			onClearCurrent( hv, isApplying, updateStatus );
		}
	}

	/**
	 * removes the current active sticker.
	 * 
	 * @param hv
	 *           the hv
	 * @param isApplying
	 *           if panel is in the onGenerateResult state 
	 * @param updateStatus
	 *           update the panel status
	 */
	private void onClearCurrent( DrawableHighlightView hv, boolean isApplying, boolean updateStatus ) {

		if ( !isApplying ) {

			FeatherDrawable content = hv.getContent();
			String name;
			String packagename;
			if ( content instanceof StickerDrawable ) {
				name = ( (StickerDrawable) content ).getName();
				packagename = ( (StickerDrawable) content ).getPackageName();

				if ( mUsedStickers.size() > 0 ) mUsedStickers.remove( name );
				if ( mUsedStickersPacks.size() > 0 ) mUsedStickersPacks.remove( packagename );
			} else {

				if ( mUsedStickers.size() > 0 ) mUsedStickers.remove( mUsedStickers.size() - 1 );
				if ( mUsedStickersPacks.size() > 0 ) mUsedStickersPacks.remove( mUsedStickersPacks.size() - 1 );
			}
		}

		hv.setOnDeleteClickListener( null );
		( (ImageViewDrawableOverlay) mImageView ).removeHightlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).invalidate();

		if ( updateStatus ) setStatus( Status.Stickers );
	}

	/**
	 * If the current sticker is selected then apply it otherwise ask to remove.
	 * 
	 * @param updateStatus
	 *           the update status
	 */
	@SuppressWarnings("unused")
	private void onApplyOrClearCurrent( boolean updateStatus ) {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		if ( image.getHighlightCount() > 0 ) {
			final DrawableHighlightView hv = image.getHighlightViewAt( 0 );
			if ( !hv.getSelected() ) {
				onApplyCurrent( updateStatus );
				return;
			}
		}
		onAskApplyCurrent( updateStatus );
	}

	/**
	 * Ask the user if he wants to apply the current sticker on the bitmap.
	 * 
	 * @param updateStatus
	 *           the update status
	 */
	private void onAskApplyCurrent( final boolean updateStatus ) {

		android.content.DialogInterface.OnClickListener yesListener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick( DialogInterface dialog, int which ) {
				if ( which == DialogInterface.BUTTON_POSITIVE ) {
					onApplyCurrent( updateStatus );
				} else if ( which == DialogInterface.BUTTON_NEGATIVE ) {
					onClearCurrent( false, updateStatus );
				}
				dialog.dismiss();
			}
		};

		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.sticker_delete_title )
				.setMessage( R.string.sticker_apply_message ).setPositiveButton( R.string.yes, yesListener )
				.setNegativeButton( R.string.no, yesListener ).show();
	}

	/**
	 * Ask user if he really wants to remove the current sticker.
	 */
	@SuppressWarnings("unused")
	private void onAskClearCurrent() {

		mLogger.info( "askClearCurrent" );

		android.content.DialogInterface.OnClickListener yesListener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick( DialogInterface dialog, int which ) {
				if ( which == DialogInterface.BUTTON_POSITIVE ) {
					onClearCurrent( false, true );
				}
				dialog.dismiss();
			}
		};

		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.sticker_delete_title )
				.setMessage( R.string.sticker_delete_message ).setPositiveButton( R.string.yes_remove, yesListener )
				.setNegativeButton( R.string.no, yesListener ).show();
	}

	/**
	 * Add a new sticker to the canvas.
	 * 
	 * @param drawable
	 *           the drawable
	 */
	private void addSticker( String drawable ) {

		onApplyCurrent( false );

		mLogger.info( "addSticker: " + drawable );
		final boolean rotateAndResize = true;
		InputStream stream = null;

		try {
			stream = mResourceManager.openAsset( drawable );
		} catch ( IOException e ) {
			e.printStackTrace();
		}

		if ( stream != null ) {
			StickerDrawable d = new StickerDrawable( mResourceManager.getResources(), stream, mResourceManager.getPackageName(),
					drawable );
			d.setAntiAlias( true );

			mUsedStickers.add( drawable );
			mUsedStickersPacks.add( mResourceManager.getPackageName() );

			addSticker( d, rotateAndResize );

			IOUtils.closeSilently( stream );
		}
	}

	/**
	 * Adds the sticker.
	 * 
	 * @param drawable
	 *           the drawable
	 * @param rotateAndResize
	 *           the rotate and resize
	 */
	private void addSticker( FeatherDrawable drawable, boolean rotateAndResize ) {
		setIsChanged( true );

		DrawableHighlightView hv = new DrawableHighlightView( mImageView, drawable );
		hv.setMinSize( mStickerMinSize );
		hv.setOnDeleteClickListener( new OnDeleteClickListener() {

			@Override
			public void onDeleteClick() {
				onClearCurrent( false, true );
			}
		} );

		Matrix mImageMatrix = mImageView.getImageViewMatrix();

		final int width = mImageView.getWidth();
		final int height = mImageView.getHeight();

		// width/height of the sticker
		final int cropWidth = drawable.getIntrinsicWidth();
		final int cropHeight = drawable.getIntrinsicHeight();

		int x = ( width - cropWidth ) / 2;
		int y = ( height - cropHeight ) / 2;

		Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		float[] pts = new float[] { x, y, x + cropWidth, y + cropHeight };
		MatrixUtils.mapPoints( matrix, pts );

		RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );
		Rect imageRect = new Rect( 0, 0, width, height );

		hv.setRotateAndScale( rotateAndResize );
		hv.setup( mImageMatrix, imageRect, cropRect, false );

		hv.drawOutlineFill( true );
		hv.drawOutlineStroke( true );
		hv.setPadding( mStickerHvPadding );
		hv.setOutlineStrokeColor( mStickerHvStrokeColor );
		hv.setOutlineStrokeColorPressed( mStickerHvStrokeColorDown );
		hv.setOutlineEllipse( mStickerHvEllipse );
		hv.setMinSize( mStickerHvMinSize );

		Paint stroke = hv.getOutlineStrokePaint();
		stroke.setStrokeWidth( mStickerHvStrokeWidth );

		hv.getOutlineFillPaint().setXfermode( new PorterDuffXfermode( android.graphics.PorterDuff.Mode.SRC_ATOP ) );
		hv.setOutlineFillColor( mStickerHvColor );
		hv.setOutlineFillColorPressed( mStickerHvColorDown );

		( (ImageViewDrawableOverlay) mImageView ).addHighlightView( hv );
		( (ImageViewDrawableOverlay) mImageView ).setSelectedHighlightView( hv );

		setStatus( Status.Sticker );
	}

	/**
	 * The Class StickersPacksAdapter.
	 */
	class StickersPacksAdapter extends ArrayAdapter<ApplicationInfo> {

		/** The cell id. */
		int screenId, cellId;

		/** The m layout inflater. */
		LayoutInflater mLayoutInflater;

		/** The m current date. */
		long mCurrentDate;

		/** The m in first layout. */
		boolean mInFirstLayout = true;

		/** The m get more label. */
		String mGetMoreLabel;

		/**
		 * Instantiates a new stickers packs adapter.
		 * 
		 * @param context
		 *           the context
		 * @param resource
		 *           the resource
		 * @param textViewResourceId
		 *           the text view resource id
		 * @param objects
		 *           the objects
		 */
		public StickersPacksAdapter( Context context, int resource, int textViewResourceId, ApplicationInfo objects[] ) {
			super( context, resource, textViewResourceId, objects );
			screenId = resource;
			cellId = textViewResourceId;
			mLayoutInflater = UIUtils.getLayoutInflater();
			mCurrentDate = System.currentTimeMillis();
			mGetMoreLabel = context.getString( R.string.get_more );
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getCount()
		 */
		@Override
		public int getCount() {
			return (int) Math.ceil( (double) ( super.getCount() + 1 ) / mWorkspaceItemsPerPage );
		}

		/**
		 * Gets the real count.
		 * 
		 * @return the real count
		 */
		public int getRealCount() {
			return super.getCount() + 1;
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getItem(int)
		 */
		@Override
		public ApplicationInfo getItem( int position ) {
			if ( position < super.getCount() ) {
				return super.getItem( position );
			} else {
				return null;
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getItemId(int)
		 */
		@Override
		public long getItemId( int position ) {
			if ( position < super.getCount() ) {
				return super.getItemId( position );
			} else {
				return -1;
			}
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getView(int, android.view.View, android.view.ViewGroup)
		 */
		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			CellLayout view;

			if ( convertView == null ) {
				view = (CellLayout) mLayoutInflater.inflate( screenId, mWorkspace, false );
				view.setNumCols( mWorkspaceCols );
			} else {
				view = (CellLayout) convertView;
			}

			int index = position * mWorkspaceItemsPerPage;
			int count = getRealCount();

			for ( int i = 0; i < mWorkspaceItemsPerPage; i++ ) {
				View itemView = null;
				CellInfo cellInfo = view.findVacantCell( 1, 1 );
				if ( cellInfo == null ) {
					itemView = view.getChildAt( i );
				} else {
					itemView = mLayoutInflater.inflate( cellId, parent, false );
					CellLayout.LayoutParams lp = new CellLayout.LayoutParams( cellInfo.cellX, cellInfo.cellY, cellInfo.spanH,
							cellInfo.spanV );
					view.addView( itemView, -1, lp );
				}

				if ( ( index + i ) < count ) {

					final ApplicationInfo appInfo = getItem( index + i );
					CharSequence label;
					Drawable icon;

					if ( appInfo == null ) {
						label = mGetMoreLabel;
						icon = mGetMoreIcon;
					} else {
						label = mPluginService.loadStickerPackLabel( appInfo );
						Drawable app_icon = mPluginService.loadStickerPackIcon( appInfo );
						// long modified_date = mPluginService.getInstalledDate( appInfo ); // use this for sorting?
						icon = UIUtils.drawFolderIcon( mFolderIcon, app_icon, null );
					}

					ImageView image = (ImageView) itemView.findViewById( R.id.image );
					TextView text = (TextView) itemView.findViewById( R.id.text );

					image.setImageDrawable( icon );
					text.setText( label );
					itemView.setTag( appInfo );
					itemView.setOnClickListener( new OnClickListener() {

						@Override
						public void onClick( View v ) {
							setCurrentPack( appInfo );
						}
					} );
					itemView.setVisibility( View.VISIBLE );
				} else {
					itemView.setVisibility( View.INVISIBLE );
				}
			}

			mInFirstLayout = false;

			view.setSelected( false );
			return view;
		}
	}

	class StickersAdapter extends ArrayAdapter<String> {
		private LayoutInflater mLayoutInflater;
		private int mStickerResourceId;
		private int mFinalSize;
		private int mContainerHeight;

		/**
		 * Instantiates a new stickers adapter.
		 * 
		 * @param context
		 *           the context
		 * @param textViewResourceId
		 *           the text view resource id
		 * @param objects
		 *           the objects
		 */
		public StickersAdapter( Context context, int textViewResourceId, String[] objects ) {
			super( context, textViewResourceId, objects );

			mLogger.info( "StickersAdapter. size: " + objects.length );

			mStickerResourceId = textViewResourceId;
			mLayoutInflater = UIUtils.getLayoutInflater();
			mContainerHeight = mHList.getHeight() - ( mHList.getPaddingBottom() + mHList.getPaddingTop() );
			mFinalSize = (int) ( (float) mContainerHeight * ( 4.0 / 5.0 ) );

			mLogger.log( "gallery height: " + mContainerHeight );
			mLogger.log( "final size: " + mFinalSize );

			mDownloadManager.setThumbSize( mFinalSize - 10 );
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getCount()
		 */
		@Override
		public int getCount() {
			return super.getCount();
		}

		/*
		 * (non-Javadoc)
		 * 
		 * @see android.widget.ArrayAdapter#getView(int, android.view.View, android.view.ViewGroup)
		 */
		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			// mLogger.info( "getView: " + position + ", " + getCount() );

			View retval = mLayoutInflater.inflate( mStickerResourceId, null );
			ImageView image = (ImageView) retval.findViewById( R.id.image );
			ImageView background = (ImageView) retval.findViewById( R.id.background );

			retval.setLayoutParams( new LinearLayout.LayoutParams( mContainerHeight, LayoutParams.MATCH_PARENT ) );

			if ( position == 0 ) {
				image.setVisibility( View.INVISIBLE );
				background.setImageResource( R.drawable.feather_sticker_paper_left_edge );
			} else if ( position >= getCount() - 1 ) {
				background.setImageResource( R.drawable.feather_sticker_paper_center_1 );
			} else {
				if ( position % 2 == 0 ) {
					background.setImageResource( R.drawable.feather_sticker_paper_center_1 );
				} else {
					background.setImageResource( R.drawable.feather_sticker_paper_center_2 );
				}
				loadStickerForImage( position, image );
			}
			return retval;
		}

		/**
		 * Load sticker for image.
		 * 
		 * @param position
		 *           the position
		 * @param view
		 *           the view
		 */
		private void loadStickerForImage( int position, ImageView view ) {
			final String sticker = "stickers/" + getItem( position );
			mDownloadManager.loadAsset( mResourceManager.getResources(), sticker, null, view );
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractContentPanel#generateContentView(android.view.LayoutInflater)
	 */
	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_stickers_content, null );
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractOptionPanel#generateOptionView(android.view.LayoutInflater,
	 * android.view.ViewGroup)
	 */
	@Override
	protected ViewGroup generateOptionView( LayoutInflater inflater, ViewGroup parent ) {
		ViewGroup view = (ViewGroup) inflater.inflate( R.layout.feather_stickers_panel, parent, false );
		view.findViewById( R.id.flipper ).setBackgroundDrawable(
				new RepeatableHorizontalDrawable( getContext().getBaseContext().getResources(),
						R.drawable.feather_sticker_tile_background ) );

		return view;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.effects.AbstractEffectPanel#onComplete(android.graphics.Bitmap)
	 */
	@Override
	protected void onComplete( Bitmap bitmap ) {
		mTrackingAttributes.put( "stickerCount", Integer.toString( mUsedStickers.size() ) );
		mTrackingAttributes.put( "stickerNames", getUsedStickersNames().toString() );
		mTrackingAttributes.put( "packNames", getUsedPacksNames().toString() );
		super.onComplete( bitmap );
	}

	/**
	 * Gets the used stickers names.
	 * 
	 * @return the used stickers names
	 */
	StringBuilder getUsedStickersNames() {
		StringBuilder sb = new StringBuilder();
		for ( String s : mUsedStickers ) {
			sb.append( s );
			sb.append( "," );
		}

		mLogger.log( "used stickers: " + sb.toString() );

		return sb;
	}

	/**
	 * Gets the used packs names.
	 * 
	 * @return the used packs names
	 */
	StringBuilder getUsedPacksNames() {

		SortedSet<String> map = new TreeSet<String>();

		StringBuilder sb = new StringBuilder();
		for ( String s : mUsedStickersPacks ) {
			map.add( s );
		}

		for ( String s : map ) {
			sb.append( s );
			sb.append( "," );
		}

		mLogger.log( "packs: " + sb.toString() );
		return sb;
	}

	/** The m update dialog. */
	private AlertDialog mUpdateDialog;

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.aviary.android.feather.library.services.PluginService.OnUpdateListener#onUpdate(android.os.Bundle)
	 */
	@Override
	public void onUpdate( Bundle delta ) {

		mLogger.info( "onUpdate: " + delta );

		if ( isActive() ) {

			if ( !validDelta( delta ) ) {
				mLogger.log( "Suppress the alert, no stickers in the delta bundle" );
				return;
			}

			if ( mUpdateDialog != null && mUpdateDialog.isShowing() ) {
				mLogger.log( "dialog is already there, skip new alerts" );
				return;
			}

			// update the available packs...
			AlertDialog dialog = null;

			switch ( mStatus ) {

				case Null:
				case Packs:

					dialog = new AlertDialog.Builder( getContext().getBaseContext() ).setMessage( R.string.sticker_pack_updated_1 )
							.setPositiveButton( R.string.ok, new DialogInterface.OnClickListener() {

								@Override
								public void onClick( DialogInterface dialog, int which ) {
									loadPacks();
								}
							} ).create();

					break;

				case Stickers:

					dialog = new AlertDialog.Builder( getContext().getBaseContext() ).setMessage( R.string.sticker_pack_updated_2 )
							.setPositiveButton( R.string.ok, new DialogInterface.OnClickListener() {

								@Override
								public void onClick( DialogInterface dialog, int which ) {
									updateInstalledPacks();
									setStatus( Status.Packs );
								}
							} ).create();

					break;

				case Sticker:

					dialog = new AlertDialog.Builder( getContext().getBaseContext() ).setMessage( R.string.sticker_pack_updated_3 )
							.setPositiveButton( R.string.yes, new DialogInterface.OnClickListener() {

								@Override
								public void onClick( DialogInterface dialog, int which ) {
									onApplyCurrent( false );
									updateInstalledPacks();
									setStatus( Status.Packs );
								}
							} ).setNegativeButton( R.string.no, new DialogInterface.OnClickListener() {

								@Override
								public void onClick( DialogInterface dialog, int which ) {
									onClearCurrent( false, false );
									updateInstalledPacks();
									setStatus( Status.Packs );
								}
							} ).create();

					break;
			}

			if ( dialog != null ) {
				mUpdateDialog = dialog;
				mUpdateDialog.setCancelable( false );
				mUpdateDialog.show();
			}
		}
	}

	/**
	 * bundle contains a list of all updates applications. if one meets the criteria ( is a filter apk ) then return true
	 * 
	 * @param bundle
	 *           the bundle
	 * @return true if bundle contains a valid filter package
	 */
	private boolean validDelta( Bundle bundle ) {
		if ( null != bundle ) {
			if ( bundle.containsKey( "delta" ) ) {
				try {
					@SuppressWarnings("unchecked")
					ArrayList<PluginManager.UpdateType> updates = (ArrayList<PluginManager.UpdateType>) bundle.getSerializable( "delta" );
					if ( null != updates ) {
						for ( UpdateType update : updates ) {
							if ( ( update.type & FeatherIntent.APP_TYPE_STICKER ) == FeatherIntent.APP_TYPE_STICKER ) {
								return true;
							}
						}
						return false;
					}
				} catch ( ClassCastException e ) {
					return true;
				}
			}
		}
		return true;
	}

	/** The m handler. */
	private final Handler mHandler = new Handler() {

		@Override
		public void handleMessage( Message msg ) {

			switch ( msg.what ) {
				case AssetsAsyncDownloadManager.THUMBNAIL_LOADED:
					Thumb thumb = (Thumb) msg.obj;

					if ( thumb.image != null ) {
						thumb.image.setImageDrawable( new StickerBitmapDrawable( thumb.bitmap, 10 ) );
					}
					break;
			}
		}
	};

	//
	// STATUS
	//

	/** The is animating. */
	boolean isAnimating = false;

	/**
	 * Back Button is pressed. Handle the event if we're not in the top folder list, otherwise always handle it
	 * 
	 * @return true if the event has been handled
	 */
	boolean backHandled() {

		mLogger.error( "onBackPressed: " + mStatus + " ( is_animating? " + isAnimating + " )" );

		if ( isAnimating ) return true;

		// this is the only exception.
		// If there's an active and selected sticker
		// then just deselect it and move on...
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getHighlightCount() > 0 ) {
			// there's at least one sticker active
			final DrawableHighlightView hv = image.getHighlightViewAt( 0 );
			if ( hv.getSelected() ) {
				hv.setSelected( false );
				return true;
			}
		}

		switch ( mStatus ) {
			case Null:
			case Packs:
				// we're in the root folder, so we dont need
				// to handle the back button anymore ( exit the current panel )

				if ( stickersOnScreen() ) {
					askToLeaveWithoutApply();
					return true;
				}

				return false;

			case Stickers:
				// if we wont allow more stickers or if there is only
				// one pack installed then we wanna exit the current panel
				setStatus( Status.Packs );
				return true;

			case Sticker:
				// special case... let's see how to handle it
				// if there are stickers but none selected
				// or there are no stickers
				setStatus( Status.Packs );
				return true;
		}

		return false;
	}

	/**
	 * Ask to leave without apply.
	 */
	void askToLeaveWithoutApply() {
		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.attention )
				.setMessage( R.string.tool_leave_question ).setPositiveButton( R.string.yes, new DialogInterface.OnClickListener() {

					@Override
					public void onClick( DialogInterface dialog, int which ) {
						getContext().cancel();
					}
				} ).setNegativeButton( R.string.no, null ).show();
	}

	/**
	 * Sets the status.
	 * 
	 * @param status
	 *           the new status
	 */
	void setStatus( Status status ) {

		mLogger.error( "setStatus: " + mStatus + " >> " + status + " ( is animating? " + isAnimating + " )" );

		if ( status != mStatus ) {

			mPrevStatus = mStatus;
			mStatus = status;

			switch ( mStatus ) {

				case Null:
					// we never want to go to this status!
					break;

				case Packs: {
					// move to the packs list view
					if ( mPrevStatus == Status.Null ) {
						loadPacks();
					} else if ( mPrevStatus == Status.Stickers || mPrevStatus == Status.Sticker ) {
						mViewFlipper.setDisplayedChild( 0 );
					}
				}
					break;

				case Stickers: {
					if ( mPrevStatus == Status.Null || mPrevStatus == Status.Packs ) {
						loadStickers();
					}

				}
					break;

				case Sticker:
					// do nothing here...
					break;
			}
		}
	}

	/**
	 * Stickers on screen.
	 * 
	 * @return true, if successful
	 */
	private boolean stickersOnScreen() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		mLogger.info( "stickers on screen?", mStatus, image.getHighlightCount() );
		return image.getHighlightCount() > 0 || mStatus == Status.Sticker;
	}
}
