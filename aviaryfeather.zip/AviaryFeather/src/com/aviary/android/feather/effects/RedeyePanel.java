package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Toast;

import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.AbstractEffectPanel.ContentPanel;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.IPixelsBrushFilter;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.widget.ImageViewTouchBrush;
import com.aviary.android.feather.widget.ImageViewTouchBrush.OnSingleTapConfirmedListener;

public class RedeyePanel extends ThumbnailsEffectOptionPanel implements OnSingleTapConfirmedListener, ContentPanel {

	protected OnContentReadyListener mContentReadyListener;
	protected View mDrawingPanel;
	protected ImageViewTouchBrush mImageView;
	protected int defaultOption = 3;
	protected int mBrushSize;
	protected Handler mHandler = new Handler();

	public RedeyePanel( EffectContext context ) {
		super( context );
	}

	protected int getBrusSize( int index ) {
		return 30 + (index * 30);
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mBrushSize = getBrusSize( defaultOption );

		mImageView = (ImageViewTouchBrush) getContentView().findViewById( R.id.image );
		mImageView.setTapRadius( (float) mBrushSize / 3f );

		// TODO: check outofmemory exception first
		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
	}

	@Override
	public void onActivate() {
		super.onActivate();
		mImageView.setOnSingleTapConfirmedListener( this );
		setCurrentSelected( defaultOption );

		contentReady();
		displayToolTip();
	}

	@Override
	protected void onDispose() {
		mContentReadyListener = null;
		super.onDispose();
	}

	protected void contentReady() {
		if( mContentReadyListener != null && isActive() )
			mContentReadyListener.onReady( this );
	}

	protected void displayToolTip() {
		Toast toast = Toast.makeText( getContext().getBaseContext(), "Select the brush size and then tap on an eye to remove redeye",
				Toast.LENGTH_SHORT );
		toast.show();
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();
		mImageView.setOnSingleTapConfirmedListener( null );
	}

	@Override
	public void onDestroy() {
		mImageView.clear();
		super.onDestroy();
	}

	public static float[] getMatrixValues( Matrix m ) {
		float[] values = new float[9];
		m.getValues( values );
		return values;
	}

	private void onApplyFilter( float x, float y ) {
		Logger.info( this, "onApplyFilter: " + x + ", " + y );
		Logger.log( this, "bitmap size: " + mPreview.getWidth() + ", " + mPreview.getHeight() );

		int brushWidth = Math.max( (int) (mBrushSize / mImageView.getScale()), 2 );
		int brushHeight = Math.max( (int) (mBrushSize / mImageView.getScale()), 2 );

		Matrix m1 = new Matrix( mImageView.getImageMatrix() );
		Matrix m2 = new Matrix();
		float[] v11 = getMatrixValues( m1 );
		m1.invert( m1 );
		float[] v22 = getMatrixValues( m1 );

		m2.postTranslate( -v11[Matrix.MTRANS_X], -v11[Matrix.MTRANS_Y] );
		m2.postScale( v22[Matrix.MSCALE_X], v22[Matrix.MSCALE_Y] );

		float[] pts2 = new float[] { x, y };
		m2.mapPoints( pts2 );

		float new_x = pts2[0];
		float new_y = pts2[1];

		int srcX = (int) new_x - (brushWidth / 2);
		int srcY = (int) new_y - (brushHeight / 2);

		// this is the rect we want to extract from the bitmap
		final Rect rect = new Rect( srcX, srcY, srcX + brushWidth, srcY + brushHeight );
		Rect original_rect = new Rect( rect );

		// now check the bounds
		if( rect.right <= 0 || rect.bottom <= 0 || rect.left >= mPreview.getWidth() || rect.top >= mPreview.getHeight() ) {
			Logger.error( this, "rect is outside the bitmap bounds" );
		}

		int center_x = rect.centerX();
		int center_y = rect.centerY();

		// now stretch the rect is necessary
		if( rect.left < 0 ) {
			rect.left = 0;
		}

		if( rect.top < 0 ) {
			rect.top = 0;
		}

		if( rect.bottom > mPreview.getHeight() ) {
			rect.bottom = mPreview.getHeight();
		}

		if( rect.right > mPreview.getWidth() ) {
			rect.right = mPreview.getWidth();
		}

		if( rect.width() <= 0 || rect.height() <= 0 ) {
			Logger.error( this, "rect is negative" );
			return;
		}

		final int[] pixels = new int[rect.width() * rect.height()];
		mPreview.getPixels( pixels, 0, rect.width(), rect.left, rect.top, rect.width(), rect.height() );

		int left = rect.left - center_x;
		int top = rect.top - center_y;
		int right = rect.right - center_x;
		int bottom = rect.bottom - center_y;

		((IPixelsBrushFilter) mFilter).drawPixels( new Rect( left, top, right, bottom ), original_rect, pixels );

		mHandler.post( new Runnable() {

			@Override
			public void run() {
				Paint paint = new Paint( Paint.ANTI_ALIAS_FLAG );
				Canvas canvas = new Canvas( mPreview );
				canvas.drawBitmap( pixels, 0, rect.width(), rect.left, rect.top, rect.width(), rect.height(), true, paint );
				mImageView.postInvalidate();
				setIsChanged( true );
			}
		} );
	}

	@SuppressWarnings("unused")
	private String printRect( Rect rect ) {
		return "( left=" + rect.left + ", top=" + rect.top + ", width=" + rect.width() + ", height=" + rect.height() + ")";
	}

	@Override
	protected IFilter createFilter() {
		FilterService service = (FilterService) getContext().getService( EffectContext.FILTER_SERVICE );
		return service.load( Filters.RED_EYE );
	}

	@Override
	protected Bitmap getThumbnail( int index, Bitmap input, int width, int height, int backgroundColor ) {
		return null;
	}

	@Override
	protected int getDefaultThumbnailResourceId( int index ) {
		switch( index ) {
			case 0:
				return R.drawable.redeye_thumb_0;
			case 1:
				return R.drawable.redeye_thumb_1;
			case 2:
				return R.drawable.redeye_thumb_2;
			case 3:
				return R.drawable.redeye_thumb_3;
		}
		return 0;
	}

	@Override
	protected void onOptionClick( int index ) {
		mBrushSize = getBrusSize( index );
		mImageView.setTapRadius( (float) mBrushSize / 3f );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	protected int getTotalOptions() {
		return 4;
	}

	@Override
	protected ThumbnailMode getThumbnailGenerationMode() {
		return ThumbnailMode.NONE;
	}

	@Override
	public void onSingleTap( final float x, final float y ) {
		mHandler.postDelayed( new Runnable() {

			@Override
			public void run() {
				onApplyFilter( x, y );
			}
		}, 200 );
	}

	@Override
	public final View getContentView( LayoutInflater inflater ) {
		mDrawingPanel = generateContentView( inflater );
		return mDrawingPanel;
	}

	@Override
	public final View getContentView() {
		return mDrawingPanel;
	}

	private View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_redeye_content, null );
	}

	@Override
	public final void setOnReadyListener( OnContentReadyListener listener ) {
		mContentReadyListener = listener;
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_four_options_panel, null );
	}

	@Override
	public ImageViewTouch getImageView() {
		return mImageView;
	}

}
