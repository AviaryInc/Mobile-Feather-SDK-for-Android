package com.aviary.android.feather.effects;

import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.os.AsyncTask;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.aviary.android.feather.Constants;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.log.Logger;

public abstract class ThumbnailsEffectOptionPanel extends AbstractOptionPanel implements OnClickListener {

	static enum ThumbnailMode {
		NONE, PREVIEW, ASYNC_PREVIEW,
	};

	protected View mThumbSelected;
	private int nThumbs;
	private ThumbnailMode mThumbMode;

	protected static final int[] optionIds = new int[] { R.id.option1, R.id.option2, R.id.option3, R.id.option4 };

	public ThumbnailsEffectOptionPanel( EffectContext context ) {
		super( context );
		nThumbs = getTotalOptions();
		mThumbMode = getThumbnailGenerationMode();
	}

	protected abstract int getTotalOptions();

	protected abstract IFilter createFilter();

	/**
	 * Default mode for thumbnail generation
	 * 
	 * @return
	 */
	protected ThumbnailMode getThumbnailGenerationMode() {
		if( getContext().getApplicationMaxMemory() < Constants.MIN_MEMORY_FOR_THUMBS ) {
			return ThumbnailMode.NONE;
		} else {
			return ThumbnailMode.PREVIEW;
		}
	}

	/**
	 * Ask to generate the preview thumbnail with the pre applied
	 * effect index
	 * 
	 * @param index
	 * @param input
	 * @param width
	 * @param height
	 * @param backgroundColor
	 * @return
	 */
	protected abstract Bitmap getThumbnail( int index, Bitmap input, int width, int height, int backgroundColor );

	/**
	 * Ask for the default resource of the option index
	 * 
	 * @param index
	 * @return
	 */
	protected abstract int getDefaultThumbnailResourceId( int index );

	/**
	 * Called method when a thumbnail is clicked
	 * 
	 * @param index
	 *           0..getTotalOptions()
	 * @see getTotalOptions()
	 */
	protected abstract void onOptionClick( int index );

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );
		mFilter = createFilter();

		// generate thumbnails
		onGenerateThumbnails( bitmap );
	}

	protected void onGenerateThumbnails( final Bitmap bitmap ) {

		// generate only the default thumbnails
		// using the panel defined resources
		if( mThumbMode == ThumbnailMode.NONE || mThumbMode == ThumbnailMode.ASYNC_PREVIEW ) {
			generateDefaultThumbnails();
		} else if( mThumbMode == ThumbnailMode.PREVIEW ) {
			generatePreviewThumbnails();
		}
	}

	protected void generateDefaultThumbnails() {
		for( int i = 0; i < nThumbs; i++ ) {
			ImageView view = getOptionImage( i );
			view.setImageResource( getDefaultThumbnailResourceId( i ) );
		}
	}

	private void generatePreviewThumbnails() {

		ImageView view = getOptionImage( 0 );

		int width = 100;
		int height = 100;

		for( int i = 0; i < nThumbs; i++ ) {
			view = getOptionImage( i );
			view.setImageBitmap( getThumbnail( i, mBitmap, width, height, 0xFF000000 ) );
		}
	}

	/**
	 * Return the overlay image for the specified thumbnail index
	 * 
	 * @param index
	 * @return
	 */
	protected ImageView getOptionOverlay( int index ) {
		return (ImageView) mOptionView.findViewById( optionIds[index] ).findViewById( R.id.thumb_overlay );
	}

	/**
	 * Return the default image container for the specified thumbnail index
	 * 
	 * @param index
	 * @return
	 */
	protected ImageView getOptionImage( int index ) {
		return (ImageView) mOptionView.findViewById( optionIds[index] ).findViewById( R.id.thumb_option );
	}

	/**
	 * Return the thumbnail background View. Currently used for the display the
	 * selection state
	 * 
	 * @param index
	 * @return
	 */
	protected View getOptionBackground( int index ) {
		if( index >= 0 && index < optionIds.length )
			return mOptionView.findViewById( optionIds[index] ).findViewById( R.id.thumb_background );
		else
			return null;
	}

	/**
	 * Return the ViewGroup associated to the thumbnail index
	 * 
	 * @param index
	 * @return
	 */
	protected View getOptionView( int index ) {
		return mOptionView.findViewById( optionIds[index] );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		for( int i = 0; i < nThumbs; i++ ) {
			getOptionBackground( i ).setOnClickListener( this );
		}

		if( mThumbMode == ThumbnailMode.ASYNC_PREVIEW ) {
			ImageView view = getOptionImage( 0 );
			int width = ((BitmapDrawable) view.getDrawable()).getBitmap().getWidth();
			int height = ((BitmapDrawable) view.getDrawable()).getBitmap().getHeight();

			GenerateThumbnailsTask task = new GenerateThumbnailsTask( width, height );
			task.execute( mBitmap );
		}
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		for( int i = 0; i < nThumbs; i++ ) {
			getOptionBackground( i ).setOnClickListener( null );
		}
	}

	protected int getParentId( View backgroundView ) {
		View parent = (View) backgroundView.getParent();
		if( parent == null )
			return -1;

		return parent.getId();
	}

	@Override
	public void onClick( View v ) {

		if( !isActive() )
			return;
		final int id = getParentId( v );

		Logger.info( this, "onClick: " + id );

		int index = -1;

		switch( id ) {
			case R.id.option1:
				index = 0;
				break;

			case R.id.option2:
				index = 1;
				break;

			case R.id.option3:
				index = 2;
				break;

			case R.id.option4:
				index = 3;
				break;
		}

		if( index > -1 ) {
			onOptionClick( index );
			setCurrentSelected( index );
		}
	}

	protected void setCurrentSelected( View v ) {
		if( mThumbSelected != null )
			mThumbSelected.setSelected( false );

		mThumbSelected = v;

		if( v != null )
			mThumbSelected.setSelected( true );
	}

	protected void setCurrentSelected( int index ) {
		View view = getOptionBackground( index );
		setCurrentSelected( view );
	}

	class GenerateThumbnailsTask extends AsyncTask<Bitmap, Void, Bitmap[]> {

		private int width;
		private int height;

		public GenerateThumbnailsTask( int w, int h ) {
			width = w;
			height = h;
		}

		@Override
		protected void onCancelled() {
			super.onCancelled();
		}

		@Override
		protected Bitmap[] doInBackground( Bitmap... params ) {
			Bitmap input = params[0];
			Bitmap[] outputs = new Bitmap[nThumbs];

			for( int i = 0; i < nThumbs; i++ ) {
				if( isCreated() )
					outputs[i] = getThumbnail( i, input, width, height, 0xFF000000 );
			}
			return outputs;
		}

		@Override
		protected void onPostExecute( Bitmap[] result ) {
			super.onPostExecute( result );

			if( result != null && isCreated() ) {

				ImageView view;

				for( int i = 0; i < nThumbs; i++ ) {
					view = getOptionOverlay( i );
					if( result[i] != null ) {
						view.setImageBitmap( result[i] );

						Animation animation = AnimationUtils.loadAnimation( getContext().getBaseContext(), android.R.anim.fade_in );
						animation.setStartOffset( i * 50 );
						view.startAnimation( animation );
					}
				}
			}
		}
	};
}
