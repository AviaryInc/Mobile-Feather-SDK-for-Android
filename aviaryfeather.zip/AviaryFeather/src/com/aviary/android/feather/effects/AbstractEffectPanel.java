package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import java.util.HashMap;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.library.services.EffectContext;

public abstract class AbstractEffectPanel {
	
	public static interface OnContentReadyListener {
		void onReady( AbstractEffectPanel panel );
	};

	public static interface OnPreviewListener {

		/**
		 * Some parameters have changed and the effect has generated a new bitmap
		 * with the new parameters applied on it
		 * 
		 * @param result
		 */
		void onPreviewChange( Bitmap result );
	};

	public static interface OnApplyResultListener {

		void onComplete( Bitmap result, HashMap<String, String> trackingAttributes );
	}

	public static interface OnErrorListener {

		void onError( String error );
	}

	public static interface OptionPanel {
		View getOptionView( LayoutInflater inflater );
	}
	
	public static interface DynamicHeightOptionPanel {
		
	}

	public static interface ContentPanel {
		void setOnReadyListener( OnContentReadyListener listener );
		View getContentView( LayoutInflater inflater );
		View getContentView();
		ImageViewTouch getImageView();
	}

	protected Bitmap mPreview;
	protected Bitmap mBitmap;
	
	private boolean mActive;
	private boolean mCreated;
	protected boolean mChanged;
	protected boolean mSaving;
	protected long mRenderTime;
	protected IFilter mFilter;
	protected HashMap<String, String> mTrackingAttributes;
	
	protected OnPreviewListener mListener;
	protected OnApplyResultListener mApplyListener;
	protected OnErrorListener mErrorListener;
	private EffectContext mFilterContext;
	protected Logger mLogger;

	public AbstractEffectPanel( EffectContext context ) {
		mFilterContext = context;
		mActive = false;
		mTrackingAttributes = new HashMap<String, String>();
		setIsChanged( false );
		mLogger = LoggerFactory.getLogger( this.getClass().getSimpleName(), LoggerType.ConsoleLoggerType );
	}

	/**
	 * Return true if current panel state is between
	 * the onActivate/onDeactivate states
	 * 
	 * @return
	 */
	public boolean isActive() {
		return mActive && isCreated();
	}

	/**
	 * Return true if current panel state is between
	 * onCreate/onDestroy states
	 * 
	 * @return
	 */
	public boolean isCreated() {
		return mCreated;
	}

	public void setOnPreviewListener( OnPreviewListener listener ) {
		mListener = listener;
	}

	public void setOnApplyResultListener( OnApplyResultListener listener ) {
		mApplyListener = listener;
	}

	public void setOnErrorListener( OnErrorListener listener ) {
		mErrorListener = listener;
	}

	public void onCreate( Bitmap bitmap ) {
		mBitmap = bitmap;
		mCreated = true;
	}
	
	public void onConfigurationChanged( Configuration newConfig ) {
		
	}

	/**
	 * The main context requests
	 * to apply the current status of the filter.
	 */
	public void onSave() {
		mLogger.info( "onSave" );
		
		if( mSaving == false ) {
			mSaving = true;
			mRenderTime = System.currentTimeMillis();
			onGenerateResult();
		}
	}

	public boolean getIsChanged() {
		return mChanged;
	}

	protected void setIsChanged( boolean value ) {
		mChanged = value;
	}

	public void onDestroy() {
		mLogger.info( "onDestroy" );
		mCreated = false;
		onDispose();
		internalDispose();
	}

	public void onActivate() {
		mLogger.info( "onActivate" );
		mTrackingAttributes = new HashMap<String, String>();
		mActive = true;
	}

	public void onDeactivate() {
		mLogger.info( "onDeactivate" );
		mActive = false;
	}

	public EffectContext getContext() {
		return mFilterContext;
	}

	protected void onDispose() {
		mLogger.info( "onDispose" );
	}

	private void internalDispose() {
		recyclePreview();

		mPreview = null;
		mBitmap = null;
		mListener = null;
		mErrorListener = null;
		mApplyListener = null;
		mFilterContext = null;
		mFilter = null;
		mTrackingAttributes = null;
	}

	protected void recyclePreview() {
		if( mPreview != null && !mPreview.isRecycled() && !mPreview.equals( mBitmap ) ) {
			mPreview.recycle();
			mLogger.warning( "preview.recycled (1)" );
		}
	}

	protected void onPreviewChanged( Bitmap bitmap ) {
		onPreviewChanged( bitmap, true );
	}

	protected void onPreviewChanged( Bitmap bitmap, boolean notify ) {
		setIsChanged( bitmap != null );

		if( bitmap == null || !bitmap.equals( mPreview ) ) {
			recyclePreview();
		}

		mPreview = bitmap;

		if( mListener != null && notify && isActive() )
			mListener.onPreviewChange( bitmap );
	}

	/**
	 * should be called when the current effect panel
	 * completed the generation of the final bitmap
	 * 
	 * @param bitmap
	 */
	protected void onComplete( Bitmap bitmap ) {
		long t = System.currentTimeMillis();
		if( mApplyListener != null && isActive() ){
			if( !mTrackingAttributes.containsKey( "renderTime" ))
				mTrackingAttributes.put( "renderTime", Long.toString( t - mRenderTime ) );
			mApplyListener.onComplete( bitmap, mTrackingAttributes );
		}
		mPreview = null;
		mSaving = false;
	}

	protected void onGenericError( String error ) {
		if( mErrorListener != null && isActive() )
			mErrorListener.onError( error );
	}

	protected void onGenericError( Exception e ) {
		onGenericError( e.getMessage() );
	}

	public abstract Bitmap render();

	protected void onGenerateResult() {
		onComplete( mPreview );
	}
}
