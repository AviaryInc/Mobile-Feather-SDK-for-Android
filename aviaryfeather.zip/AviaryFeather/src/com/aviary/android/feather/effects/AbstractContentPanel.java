package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.view.LayoutInflater;
import android.view.View;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.effects.AbstractEffectPanel.ContentPanel;


abstract class AbstractContentPanel extends AbstractOptionPanel implements ContentPanel {
	
	protected OnContentReadyListener mContentReadyListener;
	protected View mDrawingPanel;
	protected ImageViewTouch mImageView;

	public AbstractContentPanel( EffectContext context ) {
		super( context );
	}

	@Override
	public final void setOnReadyListener( OnContentReadyListener listener ) {
		mContentReadyListener = listener;
	}

	@Override
	public final View getContentView( LayoutInflater inflater ) {
		mDrawingPanel = generateContentView( inflater );
		return mDrawingPanel;
	}

	@Override
	public final View getContentView() {
		return mDrawingPanel;
	}
	
	@Override
	protected void onDispose() {
		mContentReadyListener = null;
		super.onDispose();
	}
	@Override
	public void onDestroy(){
		super.onDestroy();
	}
	
	protected void contentReady() {
		if( mContentReadyListener != null && isActive() )
			mContentReadyListener.onReady( this );
	}
	
	protected abstract View generateContentView( LayoutInflater inflater );
	
	/**
	 * Return the current content image display matrix
	 * @return
	 */
	@Override
	public ImageViewTouch getImageView(){
		return mImageView;
	}
}
