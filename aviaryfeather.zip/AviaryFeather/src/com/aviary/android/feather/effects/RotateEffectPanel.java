package com.aviary.android.feather.effects;

import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;

import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.ISimpleFilter;
import com.aviary.android.feather.library.filters.IThumbnailIndexFilter;

public class RotateEffectPanel extends ThumbnailsEffectOptionPanel {

	public RotateEffectPanel( EffectContext context ) {
		super( context );
	}

	@Override
	protected IFilter createFilter() {
		final FilterService service = (FilterService) getContext().getService( EffectContext.FILTER_SERVICE );
		return service.load( Filters.ROTATE );
	}

	@Override
	protected Bitmap getThumbnail( int index, Bitmap input, int width, int height, int backgroundColor ) {
		return ((IThumbnailIndexFilter) mFilter).getThumbnail( index, input, width, height, backgroundColor );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	protected void onOptionClick( int index ) {
		switch( index ) {
			case 0:
				applyRotation( 0 );
				break;
			case 1:
				applyRotation( 90 );
				break;
			case 2:
				applyRotation( 180 );
				break;
			case 3:
				applyRotation( 270 );
				break;
		}
	}

	private void applyRotation( int value ) {
		mPreview = ((ISimpleFilter) mFilter).execute( mBitmap, value );
		onPreviewChanged( mPreview );
	}

	@Override
	protected int getDefaultThumbnailResourceId( int index ) {
		switch( index ) {
			case 0:
				return R.drawable.rotate_thumb_0;
			case 1:
				return R.drawable.rotate_thumb_1;
			case 2:
				return R.drawable.rotate_thumb_2;
			case 3:
				return R.drawable.rotate_thumb_3;
		}
		return 0;
	}

	@Override
	protected int getTotalOptions() {
		return 4;
	}

	@Override
	protected ThumbnailMode getThumbnailGenerationMode() {
		return super.getThumbnailGenerationMode();
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_four_options_panel, null );
	}
}
