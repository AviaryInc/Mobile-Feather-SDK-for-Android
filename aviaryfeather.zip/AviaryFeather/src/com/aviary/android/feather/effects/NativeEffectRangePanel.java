package com.aviary.android.feather.effects;

import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.filters.NativeFilter;
import com.aviary.android.feather.library.filters.NativeRangeFilter;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.library.moa_interface.ActionListEncoder;
import com.aviary.android.feather.library.utils.BitmapUtils;

public class NativeEffectRangePanel extends AbstractOptionPanel {

	private SeekBar mSeekBar;
	private TextView text01;
	private TextView text02;
	
	private int mMaxValue;
	private int mMinTextRes;
	private int mMaxTextRes;

	public NativeEffectRangePanel( EffectContext context, NativeRangeFilter filter, int minTextRes, int maxTextRes, int maxValue ) {
		super( context );
		mFilter = (IFilter)filter;
		mMaxValue = maxValue;
		mMaxTextRes = maxTextRes;
		mMinTextRes = minTextRes;
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		mSeekBar = (SeekBar) getOptionView().findViewById( R.id.seekBar1 );
		text01 = (TextView) getOptionView().findViewById( R.id.text1 );
		text02 = (TextView) getOptionView().findViewById( R.id.text2 );

		text01.setText( mMinTextRes );
		text02.setText( mMaxTextRes );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		mSeekBar.setOnSeekBarChangeListener( new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch( SeekBar seekBar ) {
				applyFilter( seekBar.getProgress() );
			}

			@Override
			public void onStartTrackingTouch( SeekBar seekBar ) {
			}

			@Override
			public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {
			}
		} );
	}

	@Override
	public void onDeactivate() {
		mSeekBar.setOnSeekBarChangeListener( null );
		super.onDeactivate();
	}

	protected void applyFilter( int value ) {
		if( value == 0 ) {
			onPreviewChanged( mBitmap );
		} else {
			ApplyFilterTask task = new ApplyFilterTask( value );
			task.execute( mBitmap );
		}
	}

	@Override
	public Bitmap render() {
		return null;
	}

	class ApplyFilterTask extends AsyncTask<Bitmap, Void, Bitmap> {

		ProgressDialog mProgress = new ProgressDialog( getContext().getBaseContext() );

		public ApplyFilterTask( int value ) {
			((NativeRangeFilter) mFilter).setValue( (((float) value / 100) * mMaxValue) );
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

			Logger.log( this, "executing native filter" );
			mProgress.setTitle( getContext().getBaseContext().getString( R.string.effet_loading_title ) );
			mProgress.setMessage( getContext().getBaseContext().getString( R.string.effect_loading_message ) );
			mProgress.setIndeterminate( true );
			mProgress.show();
		}

		@Override
		protected Bitmap doInBackground( Bitmap... arg0 ) {
			Bitmap bitmap = arg0[0];
			Bitmap mOutput = null;
			long t1 = System.currentTimeMillis();
			try {
				mOutput = BitmapUtils.copy( bitmap, Config.ARGB_8888 );
				
				ActionListEncoder encoder = new ActionListEncoder();
				encoder.metadata.setImageSize( mOutput.getWidth(), mOutput.getHeight() );
				encoder.addAction( ((NativeRangeFilter)mFilter).getAction() );
				String json = encoder.encode();
				Logger.log( this, json );
				String result = NativeFilter.applyActions( json, mOutput );
				Logger.log( this, result );
				
			} catch( Exception exception ){
				exception.printStackTrace();
				Logger.error( this, "error: " + exception.getMessage() );
				return null;
			}
			long t2 = System.currentTimeMillis();
			mTrackingAttributes.put( "renderTime", Long.toString( t2-t1 ) );
			return mOutput;
		}

		@Override
		protected void onPostExecute( Bitmap result ) {
			Logger.info( this, "onPostExecute" );
			super.onPostExecute( result );

			if( mProgress.isShowing() )
				mProgress.dismiss();

			if( result != null ){
				onPreviewChanged( result );
			} else {
				onGenericError( "Sorry, there was an error rendering the image." );
			}
		}
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		View view = inflater.inflate( R.layout.feather_single_slider_panel, null );
		return view;
	}
}
