package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.DrawingPanel.ColorAdapter;
import com.aviary.android.feather.library.graphics.drawable.EditableDrawable;
import com.aviary.android.feather.library.graphics.drawable.TextDrawable;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.library.utils.MatrixUtils;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.DrawableHighlightView;
import com.aviary.android.feather.widget.DrawableHighlightView.OnDeleteClickListener;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay;
import com.aviary.android.feather.widget.ImageViewDrawableOverlay.OnDrawableEventListener;
import com.aviary.android.feather.widget.QuickActionView;

public class TextPanel extends AbstractContentPanel implements OnDrawableEventListener, OnEditorActionListener {

	abstract class MyTextWatcher implements TextWatcher {

		public DrawableHighlightView view;
	}

	private int mColor;
	private int minTextSize = 16;
	private int defaultTextSize = 16;
	private int textPadding = 10;
	private int outlineColorNormal, outlineColorPressed;
	private ImageButton mColorButton;
	private Button mToolButton;
	private Canvas mCanvas;
	private InputMethodManager mInputManager;
	private EditText mEditText;
	private ConfigService config;

	private final MyTextWatcher mEditTextWatcher = new MyTextWatcher() {

		@Override
		public void afterTextChanged( final Editable s ) {}

		@Override
		public void beforeTextChanged( final CharSequence s, final int start, final int count, final int after ) {}

		@Override
		public void onTextChanged( final CharSequence s, final int start, final int before, final int count ) {
			if ( ( view != null ) && ( view.getContent() instanceof EditableDrawable ) ) {
				final EditableDrawable editable = (EditableDrawable) view.getContent();

				if ( !editable.isEditing() ) return;

				editable.setText( s.toString() );
				view.forceUpdate();
			}
		}
	};

	public TextPanel( final EffectContext context ) {
		super( context );
	}

	private void beginEdit( final DrawableHighlightView view ) {
		mEditTextWatcher.view = null;
		mEditText.removeTextChangedListener( mEditTextWatcher );

		final EditableDrawable editable = (EditableDrawable) view.getContent();
		final String oldText = (String) editable.getText();
		mEditText.setText( oldText );
		mEditText.setSelection( mEditText.length() );
		mEditText.setImeOptions( EditorInfo.IME_ACTION_DONE );
		mEditText.requestFocusFromTouch();
		mInputManager.showSoftInput( mEditText, InputMethodManager.SHOW_IMPLICIT );

		mEditTextWatcher.view = view;
		mEditText.setOnEditorActionListener( this );
		mEditText.addTextChangedListener( mEditTextWatcher );
	}

	private void createAndConfigurePreview() {

		if ( ( mPreview != null ) && !mPreview.isRecycled() ) {
			mPreview.recycle();
			mPreview = null;
		}

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mCanvas = new Canvas( mPreview );
	}

	private void endEdit( final DrawableHighlightView view ) {
		mEditTextWatcher.view = null;
		mEditText.removeTextChangedListener( mEditTextWatcher );
		if ( mInputManager.isActive( mEditText ) )
			mInputManager.hideSoftInputFromWindow( mEditText.getWindowToken(), InputMethodManager.HIDE_NOT_ALWAYS );
	}

	@Override
	protected View generateContentView( final LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_text_content, null );
	}

	@Override
	protected View generateOptionView( final LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_text_panel, null );
	}

	@Override
	public boolean getIsChanged() {
		return super.getIsChanged() || ( ( (ImageViewDrawableOverlay) mImageView ).getHighlightCount() > 0 );
	}

	@Override
	public void onActivate() {
		super.onActivate();
		
		minTextSize = config.getInteger( R.integer.text_minSize );
		defaultTextSize = config.getInteger( R.integer.text_defaultSize );
		textPadding = config.getInteger( R.integer.text_padding );
		outlineColorNormal = config.getColor( R.color.text_outline_normal );
		outlineColorPressed = config.getColor( R.color.text_outline_pressed );

		mColorButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( final View v ) {
				final int[] colors = config.getIntArray( R.array.default_colors );

				final ColorAdapter adapter = new ColorAdapter( getContext().getBaseContext(), R.layout.feather_action_item_color,
						colors, mColor );

				final QuickActionView qa = QuickActionView.Builder( v, R.layout.feather_action_popup_vertical );
				qa.setNumColumns( (int) Math.ceil( Math.sqrt( colors.length ) ) );
				qa.setAdapter( adapter );
				qa.setOnClickListener( new DialogInterface.OnClickListener() {

					@Override
					public void onClick( final DialogInterface dialog, final int which ) {
						dialog.dismiss();

						final int color = (Integer) adapter.getItem( which );
						mColor = color;
						updateCurrentHighlightColor();
						updateColorButtonBitmap();
					}
				} );
				qa.show();
			}
		} );

		mToolButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( final View v ) {
				onAddNewText();
			}
		} );

		( (ImageViewDrawableOverlay) mImageView ).setOnDrawableEventListener( this );
		mInputManager = (InputMethodManager) getContext().getBaseContext().getSystemService( Context.INPUT_METHOD_SERVICE );

		mImageView.requestLayout();
		contentReady();

		onAddNewText();
	}

	private void onAddNewText() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;

		if ( image.getHighlightCount() > 0 ) onApplyCurrent( image.getHighlightViewAt( 0 ) );

		final TextDrawable text = new TextDrawable( "", defaultTextSize );
		text.setTextColor( mColor );

		final DrawableHighlightView hv = new DrawableHighlightView( mImageView, text );

		hv.setOnDeleteClickListener( new OnDeleteClickListener() {

			@Override
			public void onDeleteClick() {
				onAskClearCurrent( hv );
			}
		} );

		final Matrix mImageMatrix = mImageView.getImageViewMatrix();

		final int width = mImageView.getWidth();
		final int height = mImageView.getHeight();

		// width/height of the sticker
		final int cropWidth = text.getIntrinsicWidth();
		final int cropHeight = text.getIntrinsicHeight();

		final int x = ( width - cropWidth ) / 2;
		final int y = ( height - cropHeight ) / 2;

		final Matrix matrix = new Matrix( mImageMatrix );
		matrix.invert( matrix );

		final float[] pts = new float[] { x, y, x + cropWidth, y + cropHeight };
		MatrixUtils.mapPoints( matrix, pts );

		final RectF cropRect = new RectF( pts[0], pts[1], pts[2], pts[3] );
		final Rect imageRect = new Rect( 0, 0, width, height );

		hv.setRotateAndScale( true );
		hv.setup( mImageMatrix, imageRect, cropRect, false );
		hv.drawOutlineFill( true );
		hv.drawOutlineStroke( false );
		hv.getOutlineFillPaint().setXfermode( new PorterDuffXfermode( android.graphics.PorterDuff.Mode.SRC_ATOP ) );
		hv.setPadding( textPadding );
		hv.setMinSize( minTextSize );
		hv.setOutlineFillColor( outlineColorNormal );
		hv.setOutlineFillColorPressed( outlineColorPressed );

		image.addHighlightView( hv );
		image.setSelectedHighlightView( hv );
		onClick( hv );
	}

	private void onApplyCurrent() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getHighlightCount() < 1 ) return;
		final DrawableHighlightView hv = ( (ImageViewDrawableOverlay) mImageView ).getHighlightViewAt( 0 );

		if ( hv != null ) onApplyCurrent( hv );
	}

	private void onApplyCurrent( final DrawableHighlightView hv ) {

		if ( hv != null ) {
			setIsChanged( true );

			final RectF cropRect = hv.getCropRectF();
			final Rect rect = new Rect( (int) cropRect.left, (int) cropRect.top, (int) cropRect.right, (int) cropRect.bottom );

			final Matrix rotateMatrix = hv.getCropRotationMatrix();
			final Matrix matrix = new Matrix( mImageView.getImageMatrix() );
			if ( !matrix.invert( matrix ) ) Log.e( "stickers", "unale to invert matrix" );

			final int saveCount = mCanvas.save( Canvas.MATRIX_SAVE_FLAG );
			mCanvas.concat( rotateMatrix );
			hv.getContent().setBounds( rect );
			hv.getContent().draw( mCanvas );
			mCanvas.restoreToCount( saveCount );
			mImageView.invalidate();
			onClearCurrent( hv );
		}
		onPreviewChanged( mPreview, false );
	}

	private void onAskClearCurrent( final DrawableHighlightView hv ) {

		final android.content.DialogInterface.OnClickListener yesListener = new DialogInterface.OnClickListener() {

			@Override
			public void onClick( final DialogInterface dialog, final int which ) {
				if ( which == DialogInterface.BUTTON_POSITIVE ) {
					onClearCurrent( hv );
					mImageView.postInvalidate();
				}
				dialog.dismiss();
			}
		};

		new AlertDialog.Builder( getContext().getBaseContext() ).setTitle( R.string.text_delete_title )
				.setMessage( R.string.text_delete_message ).setPositiveButton( android.R.string.yes, yesListener )
				.setNegativeButton( android.R.string.no, yesListener ).show();
	}

	private void onClearCurrent( final DrawableHighlightView hv ) {
		hv.setOnDeleteClickListener( null );
		( (ImageViewDrawableOverlay) mImageView ).removeHightlightView( hv );
	}

	@Override
	public void onClick( final DrawableHighlightView view ) {
		if ( view != null ) if ( view.getContent() instanceof EditableDrawable ) {
			final EditableDrawable text = (EditableDrawable) view.getContent();
			if ( !text.isEditing() ) {
				text.beginEdit();
				beginEdit( view );
			}
		}
	}

	@Override
	public void onCreate( final Bitmap bitmap ) {
		super.onCreate( bitmap );
		
		try {
			config = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e1 ) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		mColor = config.getColor( R.color.text_defaultColor );

		mEditText = (EditText) getContentView().findViewById( R.id.invisible_text );
		mColorButton = (ImageButton) getOptionView().findViewById( R.id.color_button );
		mToolButton = (Button) getOptionView().findViewById( R.id.text_button );
		mImageView = (ImageViewTouch) getContentView().findViewById( R.id.overlay );
		mImageView.setDoubleTapEnabled( false );

		createAndConfigurePreview();
		updateColorButtonBitmap();
		
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
	}

	@Override
	public void onDeactivate() {
		( (ImageViewDrawableOverlay) mImageView ).setOnDrawableEventListener( null );
		endEdit( null );
		super.onDeactivate();
	}

	@Override
	public void onDestroy() {
		mCanvas = null;
		mInputManager = null;
		super.onDestroy();
	}

	@Override
	public void onDown( final DrawableHighlightView view ) {
	}

	@Override
	public void onFocusChange( final DrawableHighlightView newFocus, final DrawableHighlightView oldFocus ) {
		EditableDrawable text;

		if ( oldFocus != null ) if ( oldFocus.getContent() instanceof EditableDrawable ) {
			text = (EditableDrawable) oldFocus.getContent();
			if ( text.isEditing() ) {
				text.endEdit();
				endEdit( oldFocus );
			}

			if ( !oldFocus.equals( newFocus ) ) if ( text.getText().length() == 0 ) onClearCurrent( oldFocus );
		}

		if ( newFocus != null ) if ( newFocus.getContent() instanceof EditableDrawable ) {
			text = (EditableDrawable) newFocus.getContent();
			mColor = text.getTextColor();
			updateColorButtonBitmap();
		}
	}

	@Override
	protected void onGenerateResult() {
		onApplyCurrent();
		super.onGenerateResult();
	}

	@Override
	public void onMove( final DrawableHighlightView view ) {
		if ( view.getContent() instanceof EditableDrawable ) if ( ( (EditableDrawable) view.getContent() ).isEditing() ) {
			( (EditableDrawable) view.getContent() ).endEdit();
			endEdit( view );
		}
	}

	private void updateColorButtonBitmap() {
		mColorButton.getDrawable().setColorFilter( mColor, Mode.MULTIPLY );
		mColorButton.invalidate();
	}

	private void updateCurrentHighlightColor() {
		final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
		if ( image.getSelectedHighlightView() != null ) {
			final DrawableHighlightView hv = image.getSelectedHighlightView();
			if ( hv.getContent() instanceof EditableDrawable ) {
				( (EditableDrawable) hv.getContent() ).setTextColor( mColor );
				mImageView.postInvalidate();
			}
		}
	}

	@Override
	public boolean onEditorAction( TextView v, int actionId, KeyEvent event ) {

		if ( mEditText != null ) {
			if ( mEditText.equals( v ) ) {
				if ( actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_UNSPECIFIED ) {
					final ImageViewDrawableOverlay image = (ImageViewDrawableOverlay) mImageView;
					if ( image.getSelectedHighlightView() != null ) {
						DrawableHighlightView d = image.getSelectedHighlightView();
						if ( d.getContent() instanceof EditableDrawable ) {
							EditableDrawable text = (EditableDrawable) d.getContent();
							if ( text.isEditing() ) {
								text.endEdit();
								if ( text.getText().length() < 1 ) {
									onClearCurrent( d );
								}
								endEdit( d );
							}
						}
					}
				}
			}
		}

		return false;
	}

}
