package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import org.json.JSONException;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.AbstractEffectPanel.DynamicHeightOptionPanel;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IColorFilter;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.services.FilterService;

public class ColorPanel extends AbstractContentPanel implements OnSeekBarChangeListener, DynamicHeightOptionPanel {

	private SeekBar redBar;
	private SeekBar greenBar;
	private SeekBar blueBar;

	private IColorFilter mFilter;

	private int maxValue = 256;

	public ColorPanel( EffectContext context ) {
		super( context );

		FilterService service = null;
		try {
			service = context.getService( FilterService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		mFilter = (IColorFilter) service.load( Filters.COLORS );

		ConfigService config = null;
		try {
			config = context.getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		maxValue = config.getInteger( R.integer.color_max_value );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		redBar = (SeekBar) getOptionView().findViewById( R.id.seekBar1 );
		greenBar = (SeekBar) getOptionView().findViewById( R.id.seekBar2 );
		blueBar = (SeekBar) getOptionView().findViewById( R.id.seekBar3 );
		redBar.setProgress( 50 );
		greenBar.setProgress( 50 );
		blueBar.setProgress( 50 );

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );

		mImageView = (ImageViewTouch) getContentView().findViewById( R.id.image );
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
		mImageView.setDoubleTapEnabled( false );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		redBar.setOnSeekBarChangeListener( this );
		greenBar.setOnSeekBarChangeListener( this );
		blueBar.setOnSeekBarChangeListener( this );

		contentReady();
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		redBar.setOnSeekBarChangeListener( null );
		greenBar.setOnSeekBarChangeListener( null );
		blueBar.setOnSeekBarChangeListener( null );
	}

	@Override
	public void onDestroy() {
		mImageView.clear();
		redBar = null;
		greenBar = null;
		blueBar = null;
		mPreview = null;
		super.onDestroy();
	}

	protected void onOptionClick( int colorIndex, int progress ) {
		mLogger.info( this, "onOptionClick: " + colorIndex + ", " + progress );

		float red = (float) redBar.getProgress() / redBar.getMax();
		float green = (float) greenBar.getProgress() / greenBar.getMax();
		float blue = (float) blueBar.getProgress() / blueBar.getMax();

		red = -maxValue + ( red * maxValue * 2 );
		green = -maxValue + ( green * maxValue * 2 );
		blue = -maxValue + ( blue * maxValue * 2 );

		try {
			mPreview = mFilter.apply( red, green, blue, mBitmap );
			mImageView.setImageBitmapReset( mPreview, false );
		} catch ( JSONException e ) {
			e.printStackTrace();
		}

		mImageView.postInvalidate();
		setIsChanged( true );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {

	}

	@Override
	public void onStartTrackingTouch( SeekBar seekBar ) {}

	@Override
	public void onStopTrackingTouch( SeekBar seekBar ) {
		int colorIndex = 0;

		if ( seekBar.getId() == R.id.seekBar1 ) {
			colorIndex = 0;
		} else if ( seekBar.getId() == R.id.seekBar2 ) {
			colorIndex = 1;
		} else if ( seekBar.getId() == R.id.seekBar3 ) {
			colorIndex = 2;
		}

		onOptionClick( colorIndex, seekBar.getProgress() );
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_panel, null );
	}

}
