package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.aviary.android.feather.ConfigService;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.AbstractEffectPanel.DynamicHeightOptionPanel;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IColorFilter;
import com.aviary.android.feather.library.log.Logger;

public class ColorPanel extends AbstractContentPanel implements OnSeekBarChangeListener, DynamicHeightOptionPanel {

	private SeekBar redBar;
	private SeekBar greenBar;
	private SeekBar blueBar;

	private IColorFilter mFilter;
	private ColorMatrixColorFilter mCurrentColorFilter;

	public ColorPanel( EffectContext context ) {
		super( context );
		
		final FilterService service = (FilterService) context.getService( EffectContext.FILTER_SERVICE );
		mFilter = (IColorFilter) service.load( Filters.COLORS );
		
		ConfigService config = (ConfigService) context.getService( EffectContext.CONFIG_SERVICE );
		((IColorFilter)mFilter).setMaxValue( config.getInteger( R.integer.color_max_value ) );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		redBar = (SeekBar) getOptionView().findViewById( R.id.seekBar1 );
		greenBar = (SeekBar) getOptionView().findViewById( R.id.seekBar2 );
		blueBar = (SeekBar) getOptionView().findViewById( R.id.seekBar3 );
		redBar.setProgress( 50 );
		greenBar.setProgress( 50 );
		blueBar.setProgress( 50 );

		// TODO: check outofmemory exception
		mPreview = mBitmap.copy( mBitmap.getConfig(), true );

		mImageView = (ImageViewTouch) getContentView().findViewById( R.id.image );
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
		mImageView.setDoubleTapEnabled( false );
	}

	@Override
	protected void onGenerateResult() {
		Canvas canvas = new Canvas( mPreview );
		Paint paint = new Paint( Paint.ANTI_ALIAS_FLAG );
		paint.setColorFilter( mCurrentColorFilter );
		canvas.drawBitmap( mBitmap, 0, 0, paint );
		onComplete( mPreview );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		redBar.setOnSeekBarChangeListener( this );
		greenBar.setOnSeekBarChangeListener( this );
		blueBar.setOnSeekBarChangeListener( this );
		
		contentReady();
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		redBar.setOnSeekBarChangeListener( null );
		greenBar.setOnSeekBarChangeListener( null );
		blueBar.setOnSeekBarChangeListener( null );
	}

	@Override
	public void onDestroy() {
		mImageView.clear();
		redBar = null;
		greenBar = null;
		blueBar = null;
		mPreview = null;
		super.onDestroy();
	}

	protected void onOptionClick( int colorIndex, int progress ) {
		Logger.info( this, "onOptionClick: " + colorIndex + ", " + progress );

		float red = (float) redBar.getProgress() / redBar.getMax();
		float green = (float) greenBar.getProgress() / greenBar.getMax();
		float blue = (float) blueBar.getProgress() / blueBar.getMax();

		Logger.info( this, "rgb: " + red + ", " + green + ", " + blue );
		mCurrentColorFilter = mFilter.apply( red, green, blue );

		mImageView.setColorFilter( mCurrentColorFilter );
		setIsChanged( true );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {

	}

	@Override
	public void onStartTrackingTouch( SeekBar seekBar ) {
	}

	@Override
	public void onStopTrackingTouch( SeekBar seekBar ) {
		int colorIndex = 0;
		
		switch( seekBar.getId() ) {
			case R.id.seekBar1:
				colorIndex = 0;
				break;
				
			case R.id.seekBar2:
				colorIndex = 1;
				break;
				
			case R.id.seekBar3:
				colorIndex = 2;
				break;
		}
		
		onOptionClick( colorIndex, seekBar.getProgress() );
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_panel, null );
	}

}
