package com.aviary.android.feather.effects;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import com.aviary.android.feather.ConfigService;
import com.aviary.android.feather.EffectContext;
import com.aviary.android.feather.FilterService;
import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.AbstractEffectPanel.DynamicHeightOptionPanel;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IColorFilter;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.library.utils.BitmapUtils;

public class ColorPanel extends AbstractContentPanel implements OnSeekBarChangeListener, DynamicHeightOptionPanel {

	private SeekBar redBar;
	private SeekBar greenBar;
	private SeekBar blueBar;

	private IColorFilter mFilter;
	
	private int maxValue = 256;

	public ColorPanel( EffectContext context ) {
		super( context );
		
		final FilterService service = (FilterService) context.getService( EffectContext.FILTER_SERVICE );
		mFilter = (IColorFilter) service.load( Filters.COLORS );
		
		ConfigService config = (ConfigService) context.getService( EffectContext.CONFIG_SERVICE );
		maxValue = config.getInteger( R.integer.color_max_value );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		redBar = (SeekBar) getOptionView().findViewById( R.id.seekBar1 );
		greenBar = (SeekBar) getOptionView().findViewById( R.id.seekBar2 );
		blueBar = (SeekBar) getOptionView().findViewById( R.id.seekBar3 );
		redBar.setProgress( 50 );
		greenBar.setProgress( 50 );
		blueBar.setProgress( 50 );

		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );

		mImageView = (ImageViewTouch) getContentView().findViewById( R.id.image );
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
		mImageView.setDoubleTapEnabled( false );
	}

	@Override
	public void onActivate() {
		super.onActivate();

		redBar.setOnSeekBarChangeListener( this );
		greenBar.setOnSeekBarChangeListener( this );
		blueBar.setOnSeekBarChangeListener( this );
		
		contentReady();
	}

	@Override
	public void onDeactivate() {
		super.onDeactivate();

		redBar.setOnSeekBarChangeListener( null );
		greenBar.setOnSeekBarChangeListener( null );
		blueBar.setOnSeekBarChangeListener( null );
	}

	@Override
	public void onDestroy() {
		mImageView.clear();
		redBar = null;
		greenBar = null;
		blueBar = null;
		mPreview = null;
		super.onDestroy();
	}

	protected void onOptionClick( int colorIndex, int progress ) {
		Logger.info( this, "onOptionClick: " + colorIndex + ", " + progress );

		float red = (float) redBar.getProgress() / redBar.getMax();
		float green = (float) greenBar.getProgress() / greenBar.getMax();
		float blue = (float) blueBar.getProgress() / blueBar.getMax();
		
		red = -maxValue + (red * maxValue * 2);
		green = -maxValue + (green * maxValue * 2);
		blue = -maxValue + (blue * maxValue* 2);

		Logger.info( this, "rgb: " + red + ", " + green + ", " + blue );
		mFilter.apply( red, green, blue, mBitmap, mPreview );
		
		mImageView.postInvalidate();
		setIsChanged( true );
	}

	@Override
	public Bitmap render() {
		return null;
	}

	@Override
	public void onProgressChanged( SeekBar seekBar, int progress, boolean fromUser ) {

	}

	@Override
	public void onStartTrackingTouch( SeekBar seekBar ) {
	}

	@Override
	public void onStopTrackingTouch( SeekBar seekBar ) {
		int colorIndex = 0;
		
		switch( seekBar.getId() ) {
			case R.id.seekBar1:
				colorIndex = 0;
				break;
				
			case R.id.seekBar2:
				colorIndex = 1;
				break;
				
			case R.id.seekBar3:
				colorIndex = 2;
				break;
		}
		
		onOptionClick( colorIndex, seekBar.getProgress() );
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_colors_panel, null );
	}

}
