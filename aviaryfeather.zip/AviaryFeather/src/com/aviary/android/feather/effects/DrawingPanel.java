package com.aviary.android.feather.effects;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.BlurMaskFilter;
import android.graphics.BlurMaskFilter.Blur;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.graphics.drawable.CircleDrawable;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.utils.BitmapUtils;
import com.aviary.android.feather.services.ConfigService;
import com.aviary.android.feather.widget.ActionItemText;
import com.aviary.android.feather.widget.CustomQuickActionView;
import com.aviary.android.feather.widget.ImageViewTouchAndDraw;
import com.aviary.android.feather.widget.ImageViewTouchAndDraw.OnDrawStartListener;
import com.aviary.android.feather.widget.ImageViewTouchAndDraw.TouchMode;
import com.aviary.android.feather.widget.QuickActionView;

public class DrawingPanel extends AbstractContentPanel implements OnDrawStartListener {
	
	private enum DrawinTool {
		Draw, Erase, Zoom,
	};

	protected int defaultOption = 0;
	private int mColor;
	private int mSize;
	private boolean mSoftBrush;
	private int mBlur = 1;
	private DrawinTool mSelectedTool;

	private ImageButton mSizeButton;
	private ImageButton mColorButton;
	private ImageButton mToolButton;
	private Paint mPaint;
	private ConfigService mConfig;

	public DrawingPanel( EffectContext context ) {
		super( context );
	}

	@Override
	public void onCreate( Bitmap bitmap ) {
		super.onCreate( bitmap );

		try {
			mConfig = getContext().getService( ConfigService.class );
		} catch ( IllegalAccessException e ) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		mSize = mConfig.getInteger( R.integer.draw_defaultSize );
		mColor = mConfig.getColor( R.color.draw_defaultColor );
		mBlur = mConfig.getInteger( R.integer.draw_softValue );

		initPaint();

		mColorButton = (ImageButton) getOptionView().findViewById( R.id.color_button );
		mSizeButton = (ImageButton) getOptionView().findViewById( R.id.size_button );
		mToolButton = (ImageButton) getOptionView().findViewById( R.id.tool_button );

		mImageView = (ImageViewTouchAndDraw) getContentView().findViewById( R.id.image );
		resetBitmap();
	}

	private void resetBitmap() {
		if( mPreview != null ) {
			mPreview.recycle();
			mPreview = null;
		}
		mPreview = BitmapUtils.copy( mBitmap, mBitmap.getConfig() );
		mImageView.setImageBitmapReset( mPreview, true, getContext().getCurrentImageViewMatrix() );
		((ImageViewTouchAndDraw) mImageView).setDrawMode( TouchMode.DRAW );
	}

	private void updateSizeButtonBitmap() {

		Rect rect = mSizeButton.getDrawable().copyBounds();
		Bitmap bitmap = Bitmap.createBitmap( rect.width(), rect.height(), Config.ARGB_8888 );

		Paint paint = new Paint( Paint.ANTI_ALIAS_FLAG );
		paint.setColor( Color.BLACK );
		paint.setMaskFilter( mPaint.getMaskFilter() );

		final float left = (rect.width() - mSize) / 2;
		final float top = (rect.height() - mSize) / 2;
		RectF drawRect = new RectF( left, top, left + mSize, top + mSize );
		Canvas canvas = new Canvas( bitmap );
		canvas.drawColor( 0 );
		canvas.drawOval( drawRect, paint );
		mSizeButton.setImageBitmap( bitmap );
	}

	private void updateColorButtonBitmap() {

		mColorButton.getBackground().setColorFilter( mColor, Mode.MULTIPLY );
		mColorButton.invalidate();
	}

	@Override
	public void onActivate() {
		super.onActivate();
		
		setSelectedTool( DrawinTool.Draw );
		
		updatePaint();
		updateColorButtonBitmap();
		updateSizeButtonBitmap();

		mColorButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {

				final int[] colors = mConfig.getIntArray( R.array.default_colors );

				final ColorAdapter adapter = new ColorAdapter( getContext().getBaseContext(), R.layout.feather_action_item_color,
						colors, mColor );

				QuickActionView qa = QuickActionView.Builder( v, R.layout.feather_action_popup_colors );
				qa.setNumColumns( (int) Math.ceil( Math.sqrt( colors.length ) ) );
				qa.setAdapter( adapter );
				qa.setOnClickListener( new DialogInterface.OnClickListener() {

					@Override
					public void onClick( DialogInterface dialog, int which ) {
						dialog.dismiss();

						final int color = (Integer) adapter.getItem( which );
						mPaint.setColor( color );
						mColor = color;
						
						if( getSelectedTool() != DrawinTool.Draw ){
							setSelectedTool( DrawinTool.Draw );
						}
						
						updatePaint();
						updateColorButtonBitmap();
					}
				} );
				qa.show();
			}
		} );

		mSizeButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				final int[] sizes = mConfig.getIntArray( R.array.draw_brushSizes );

				final BrushSizeAdapter adapter = new BrushSizeAdapter( getContext().getBaseContext(),
						R.layout.feather_action_item_brush, sizes, mSize, mSoftBrush );

				QuickActionView qa = CustomQuickActionView.Builder( v, R.layout.feather_action_popup_sizes );
				qa.setNumColumns( 4 );
				qa.setAdapter( adapter );
				qa.setOnClickListener( new DialogInterface.OnClickListener() {

					@Override
					public void onClick( DialogInterface dialog, int which ) {
						dialog.dismiss();

						final int size = (Integer) adapter.getItem( which );
						final boolean soft = adapter.getIsSoft( which );
						
						if( soft )
							mPaint.setMaskFilter( new BlurMaskFilter( mBlur, Blur.NORMAL ) );
						else
							mPaint.setMaskFilter( null );

						mSize = size;
						mSoftBrush = soft;
						
						if( getSelectedTool() == DrawinTool.Zoom ){
							setSelectedTool( DrawinTool.Draw );
						}
						
						updateSizeButtonBitmap();
						updatePaint();
					}
				} );
				qa.show();
			}
		} );

		mToolButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( final View v ) {

				Context context = getContext().getBaseContext();

				ActionItemText[] items = new ActionItemText[] {
						new ActionItemText( context, R.string.brush, R.drawable.draw_icon_brush ),
						new ActionItemText( context, R.string.eraser, R.drawable.draw_icon_eraser ),
						new ActionItemText( context, R.string.zoom, R.drawable.draw_icon_zoom ), };

				final ActionItemAdapter adapter = new ActionItemAdapter( getContext().getBaseContext(), R.layout.action_item, items );

				QuickActionView qa = QuickActionView.Builder( v, R.layout.feather_action_popup_vertical );
				qa.setNumColumns( 3 );
				qa.setAdapter( adapter );
				qa.setOnClickListener( new DialogInterface.OnClickListener() {

					@Override
					public void onClick( DialogInterface dialog, int which ) {
						dialog.dismiss();
						
						switch( which ){
							case 0:
								setSelectedTool( DrawinTool.Draw );
								break;
								
							case 1:
								setSelectedTool( DrawinTool.Erase );
								break;
								
							case 2:
								setSelectedTool( DrawinTool.Zoom );
								break;
						}
					}
				} );
				qa.show();
			}
		} );

		((ImageViewTouchAndDraw) mImageView).setOnDrawStartListener( this );
		contentReady();
	}
	
	private void setSelectedTool( DrawinTool which ){
		switch( which ) {
			case Draw:
				((ImageViewTouchAndDraw) mImageView).setDrawMode( TouchMode.DRAW );
				mPaint.setAlpha( 255 );
				mPaint.setXfermode( null );
				updatePaint();
				mToolButton.setImageResource( R.drawable.draw_icon_brush );
				break;

			case Erase:
				((ImageViewTouchAndDraw) mImageView).setDrawMode( TouchMode.DRAW );
				mPaint.setXfermode( new PorterDuffXfermode( PorterDuff.Mode.CLEAR ) );
				mPaint.setAlpha( 0 );
				updatePaint();
				mToolButton.setImageResource( R.drawable.draw_icon_eraser );
				break;

			case Zoom:
				((ImageViewTouchAndDraw) mImageView).setDrawMode( TouchMode.IMAGE );
				mToolButton.setImageResource( R.drawable.draw_icon_zoom );
				break;
		}
		
		mSelectedTool = which;
	}
	
	private DrawinTool getSelectedTool(){
		return mSelectedTool;
	}

	@Override
	public void onDeactivate() {
		((ImageViewTouchAndDraw) mImageView).setOnDrawStartListener( null );
		mColorButton.setOnClickListener( null );
		mSizeButton.setOnClickListener( null );
		super.onDeactivate();
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		mImageView.clear();
	}

	@Override
	public Bitmap render() {
		return null;
	}

	private void initPaint() {
		mPaint = new Paint( Paint.ANTI_ALIAS_FLAG );
		mPaint.setFilterBitmap( false );
		mPaint.setDither( true );
		mPaint.setColor( mColor );
		mPaint.setStrokeWidth( mSize );
		mPaint.setStyle( Paint.Style.STROKE );
		mPaint.setStrokeJoin( Paint.Join.ROUND );
		mPaint.setStrokeCap( Paint.Cap.ROUND );
	}

	private void updatePaint() {
		mPaint.setStrokeWidth( mSize );
		((ImageViewTouchAndDraw) mImageView).setPaint( mPaint );
		mColorButton.invalidate();
	}

	@Override
	protected View generateContentView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_drawing_content, null );
	}

	@Override
	protected View generateOptionView( LayoutInflater inflater ) {
		return inflater.inflate( R.layout.feather_drawing_panel, null );
	}

	@Override
	protected void onGenerateResult() {
		Canvas canvas = new Canvas( mPreview );
		((ImageViewTouchAndDraw) mImageView).commit( canvas );
		onComplete( mPreview );
	}

	@Override
	public void onDrawStart() {
		//FeatherActivity a = FeatherActivity.getSharedFeatherActivity();
		//a.showAlertBeforeCancel(true, "Are you sure?", "Are you sure you want to discard all drawing changes?", "Yes, discard", "Keep editing", getContext());
		onPreviewChanged( mPreview, false );
	}
	
	

	public class BrushSizeAdapter extends BaseAdapter {

		private int mLayoutRes;
		private int[] mSizes;
		private LayoutInflater mLayoutInflater;
		private int mCurrentSize;
		private boolean mCurrentSoft;

		public BrushSizeAdapter( Context c, int resId, int[] sizes, int selectedSize, boolean selectedIsSoft ) {
			mLayoutRes = resId;
			mSizes = sizes;
			mCurrentSize = selectedSize;
			mCurrentSoft = selectedIsSoft;
			mLayoutInflater = (LayoutInflater) c.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		}

		@Override
		public int getCount() {
			return mSizes.length * 2;
		}

		public boolean getIsSoft( int position ) {
			return position >= mSizes.length;
		}

		@Override
		public Object getItem( int position ) {
			return mSizes[position % mSizes.length];
		}

		@Override
		public long getItemId( int position ) {
			return position;
		}

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			View view = mLayoutInflater.inflate( mLayoutRes, parent, false );
			ImageView imageView = (ImageView) view.findViewById( R.id.image );

			final int size = (Integer) getItem( position );
			final boolean soft = getIsSoft( position );

			//Drawable d = new android.graphics.drawable.ColorDrawable( 0xFFFF0000 );
			CircleDrawable d = new CircleDrawable( size, soft );
			d.setBackgroundColor( Color.WHITE );
			imageView.setImageDrawable( d );
			view.setSelected( mCurrentSize == size && soft == mCurrentSoft );
			return view;
		}
	}

	public static class ColorAdapter extends BaseAdapter {

		private int mLayoutRes;
		private int[] mColors;
		private LayoutInflater mLayoutInflater;
		private int mCurrentColor;

		public ColorAdapter( Context c, int resId, int[] colors, int selectedColor ) {
			mLayoutRes = resId;
			mColors = colors;
			mCurrentColor = selectedColor;
			mLayoutInflater = (LayoutInflater) c.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		}

		@Override
		public int getCount() {
			return mColors.length;
		}

		@Override
		public Object getItem( int position ) {
			return mColors[position];
		}

		@Override
		public long getItemId( int position ) {
			return position;
		}

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			View view = mLayoutInflater.inflate( mLayoutRes, parent, false );
			ImageView imageView = (ImageView) view.findViewById( R.id.image );
			final int color = (Integer) getItem( position );
			imageView.setColorFilter( color, Mode.SRC_ATOP );
			view.setSelected( mCurrentColor == color );
			return view;
		}
	}

	public class ActionItemAdapter extends ArrayAdapter<ActionItemText> {

		private int mLayoutRes;
		private LayoutInflater mLayoutInflater;

		public ActionItemAdapter( Context c, int resId, ActionItemText[] items ) {
			super( c, resId, items );
			mLayoutRes = resId;
			mLayoutInflater = (LayoutInflater) c.getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		}

		@Override
		public long getItemId( int position ) {
			return position;
		}

		@Override
		public View getView( int position, View convertView, ViewGroup parent ) {

			final ActionItemText item = getItem( position );

			View view = mLayoutInflater.inflate( mLayoutRes, parent, false );
			TextView textView = (TextView) view.findViewById( R.id.title );
			ImageView imageView = (ImageView) view.findViewById( R.id.image );

			textView.setText( item.getTitle() );
			imageView.setImageDrawable( item.getIcon() );

			return view;
		}
	}
}
