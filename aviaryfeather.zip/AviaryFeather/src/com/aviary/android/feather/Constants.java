package com.aviary.android.feather;

import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.util.DisplayMetrics;

public class Constants {

	public static void init( Context context ) {
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		MAX_IMAGE_SIZE_LOCAL = Math.max( metrics.widthPixels, metrics.heightPixels );
		
		final ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
		MAX_MEMORY = manager.getMemoryClass();
	}
	
	
	/**
	 * Return the maximum image size allowed for this device
	 * @return
	 */
	public static int getManagedMaxImageSize(){
		//if( android.os.Build.VERSION.SDK_INT >= 8 )
		//	return MAX_IMAGE_SIZE_LOCAL;

		if( MAX_MEMORY >= 64 ){
			return 2048;
		} else if( MAX_MEMORY >= 32 ){
			return 1024;
		} else {
			return 800;
		}
	}
	
	public static int getMaxImageSize(){
		return MAX_IMAGE_SIZE_LOCAL;
	}
	
	public static int getApplicationMaxMemory(){
		return MAX_MEMORY;
	}

	static int MAX_IMAGE_SIZE_LOCAL = -1;
	static int MAX_MEMORY = -1;
	
	public static final int MIN_MEMORY_FOR_THUMBS = 16;
	public static final int MIN_MEMORY_FOR_CONVOLUTION_THUMBS = 24;

	public static final String API_KEY = "API_KEY";
	public static final String API_SECRET = "API_SECRET";

	/**
	 * Result bitmap will be returned inline within the
	 * result Intent
	 */
	public static final String EXTRA_RETURN_DATA = "return-data";

	/**
	 * Define an output uri used by Feather to save the
	 * result bitmap in the specified location
	 */
	public static final String EXTRA_OUTPUT = "output";

	/**
	 * if an the EXTRA_OUTPUT is passed, this is used to
	 * determine the bitmap output format
	 * For valid values see Bitmap.CompressFormat
	 * 
	 * @see Bitmap.CompressFormat
	 */
	public static final String EXTRA_OUTPUT_FORMAT = "output-format";

	/**
	 * if EXTRA_OUTPUT is passed then this is used to determine
	 * the output quality ( if compress format is jpeg )
	 * valid value: 0..100
	 */
	public static final String EXTRA_OUTPUT_QUALITY = "output-quality";
	
	/**
	 * If tools-list is passed among the intent to Feather
	 * then only the selected list of tools will be shown
	 * Actually the list of tools:
	 * 	SHARPEN, BRIGHTNESS, CONTRAST, SATURATION, ROTATE, FLIP, BLUR, EFFECTS, COLORS, RED_EYE, CROP, WHITEN, DRAWING, STICKERS
	 */
	public static final String EXTRA_TOOLS_LIST = "tools-list";
}
