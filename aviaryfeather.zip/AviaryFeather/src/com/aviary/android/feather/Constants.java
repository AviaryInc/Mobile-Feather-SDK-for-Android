package com.aviary.android.feather;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.utils.SystemUtils;

// TODO: Auto-generated Javadoc
/**
 * The Class Constants.
 */
public class Constants {

	private static Boolean mEnableFastPreview;

	/** The original bundle. */
	private static Bundle mOriginalBundle;

	/** Arbitrary number indicating a fast cpu. */
	public static final int BOGO_CPU_FAST = 1400;

	/** Arbitrary number indicating a medium fast cpu. */
	public static final int BOGO_CPU_MEDIUM = 950;

	/** default image view maximum zoom. */
	public static final float IMAGE_VIEW_MAX_ZOOM = 8F;

	public static final int ANDROID_SDK = android.os.Build.VERSION.SDK_INT;

	/**
	 * Initialize the constant fields used in feather like the screen resolution, memory available, etc and copy all the extras field
	 * from the original activity's intent.
	 * 
	 * @param activity
	 *           the activity
	 */
	public static void init( Activity activity ) {
		initContext( activity );
		initIntent( activity.getIntent() );
	}

	/**
	 * Get if the fast preview mode is enabled. If the 'effect-enable-fast-preview' intent-extra has been passed within the original
	 * intent the intent value will be used, otherwise the device cpu speed will be used to determine the return value
	 * 
	 * @return
	 */
	public static boolean getFastPreviewEnabled() {
		if ( mEnableFastPreview == null ) {
			boolean value = false;
			if ( containsValue( EXTRA_EFFECTS_ENABLE_FAST_PREVIEW ) ) {
				value = getValueFromIntent( EXTRA_EFFECTS_ENABLE_FAST_PREVIEW, false );
			} else {
				float speed = SystemUtils.getCpuSpeed();
				value = speed >= BOGO_CPU_FAST;
			}
			mEnableFastPreview = value;
		}
		return mEnableFastPreview.booleanValue();
	}

	/**
	 * Inits the context.
	 * 
	 * @param context
	 *           the context
	 */
	private static void initContext( Context context ) {
		DisplayMetrics metrics = context.getResources().getDisplayMetrics();
		final ActivityManager manager = (ActivityManager) context.getSystemService( Context.ACTIVITY_SERVICE );

		MAX_MEMORY = manager.getMemoryClass();
		SCREEN_WIDTH = metrics.widthPixels;
		SCREEN_HEIGHT = metrics.heightPixels;

		if ( ANDROID_SDK > 10 ) {
			LARGE_HEAP = manager.getLargeMemoryClass() > MAX_MEMORY;
		}

		Log.i( LoggerFactory.LOG_TAG, "screen size: " + SCREEN_WIDTH + "x" + SCREEN_HEIGHT );
	}

	/**
	 * Register the original host {@link #android.content.Intent}.
	 * 
	 * @param intent
	 *           the intent
	 */
	private static void initIntent( Intent intent ) {
		if ( intent != null ) {
			Bundle extras = intent.getExtras();
			if ( extras != null ) {
				mOriginalBundle = (Bundle) extras.clone();
			}
		}
	}

	/**
	 * Gets a value from the original intent.
	 * 
	 * @param <T>
	 *           the generic type
	 * @param key
	 *           the key
	 * @param defaultValue
	 *           the default value
	 * @return the value from intent
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getValueFromIntent( String key, T defaultValue ) {
		if ( mOriginalBundle != null ) {
			if ( mOriginalBundle.containsKey( key ) ) {
				T value;
				try {
					value = (T) mOriginalBundle.get( key );
				} catch ( ClassCastException e ) {
					return defaultValue;
				}

				if ( value != null ) return value;
				return defaultValue;
			}
		}
		return defaultValue;
	}

	/**
	 * Check if the key string exists in the original bundle.
	 * 
	 * @param key
	 *           the key
	 * @return true, if successful
	 */
	public static boolean containsValue( String key ) {
		if ( mOriginalBundle != null ) {
			return mOriginalBundle.containsKey( key );
		}
		return false;
	}

	/**
	 * Return the maximum image size allowed for this device.
	 * 
	 * @return the managed max image size
	 */
	public static final int getManagedMaxImageSize() {

		if( containsValue( EXTRA_MAX_IMAGE_SIZE ) ){
			int size = getValueFromIntent( EXTRA_MAX_IMAGE_SIZE, 0 );
			if( size > 0 ){
				return size;
			}
		}
		final int screen_size = Math.max( SCREEN_HEIGHT, SCREEN_WIDTH );
		
		if ( MAX_MEMORY >= 48 ) {
			return 1280;
		} else if ( MAX_MEMORY >= 32 ) {
			return 1024;
		} else {
			return Math.min( screen_size, 800 );
		}
	}

	/**
	 * Return the max allowed heap size for application.
	 * 
	 * @return the application max memory
	 */
	public static int getApplicationMaxMemory() {
		return MAX_MEMORY;
	}

	/** The MAX image size */
	static int MAX_IMAGE_SIZE_LOCAL = -1;

	/** The max memory. */
	static int MAX_MEMORY = -1;

	/** large heap enabled for this app */
	static boolean LARGE_HEAP = false;

	/** The SCREEN width. */
	public static int SCREEN_WIDTH = -1;

	/** The SCREEN height. */
	public static int SCREEN_HEIGHT = -1;

	/** The Constant API_KEY. */
	public static final String API_KEY = "API_KEY";

	/** Result bitmap will be returned inline within the result Intent. */
	public static final String EXTRA_RETURN_DATA = "return-data";

	/** Define an output uri used by Feather to save the result bitmap in the specified location. */
	public static final String EXTRA_OUTPUT = "output";

	/**
	 * if an the EXTRA_OUTPUT is passed, this is used to determine the bitmap output format For valid values see
	 * Bitmap.CompressFormat
	 * 
	 * @see Bitmap.CompressFormat
	 */
	public static final String EXTRA_OUTPUT_FORMAT = "output-format";

	/**
	 * if EXTRA_OUTPUT is passed then this is used to determine the output quality ( if compress format is jpeg ) valid value: 0..100
	 */
	public static final String EXTRA_OUTPUT_QUALITY = "output-quality";

	/**
	 * If tools-list is passed among the intent to Feather then only the selected list of tools will be shown Actually the list of
	 * tools: SHARPEN, BRIGHTNESS, CONTRAST, SATURATION, ROTATE, FLIP, BLUR, EFFECTS, COLORS, RED_EYE, CROP, WHITEN, DRAWING,
	 * STICKERS.
	 */
	public static final String EXTRA_TOOLS_LIST = "tools-list";

	/**
	 * When the user click on the back-button and the image contains unsaved data a confirmation dialog appears by default. Setting
	 * this flag to true will hide that confirmation and the application will terminate.
	 */
	public static final String EXTRA_HIDE_EXIT_UNSAVE_CONFIRMATION = "hide-exit-unsave-confirmation";

	/**
	 * Depending on the curremt image size and the current user device, some effects can take longer than expected to render the
	 * image. Passing in the caller intent this flag as boolean "true" will affect the behavior of some of the feather's panels, such
	 * as the effect panel. All the panels will use a small progress loader in the toolbar. Passing this value as "false" a modal
	 * progress loader will be used. If you omit this extra in the calling intent, Feather will determine this value reading the
	 * device cpu speed. Moreover the effect panel, when this value is "true", will create also an intermediate fast preview of the
	 * current selected effect while the full size preview is being loaded.
	 */
	public static final String EXTRA_EFFECTS_ENABLE_FAST_PREVIEW = "effect-enable-fast-preview";

	/**
	 * By default feather offers to the final user the possibility to install external filters from the android market. If you want
	 * to disable this feature you can pass this extra boolean to the launching intent as "false". The default behavior is to enable
	 * the external filters.
	 */
	public static final String EXTRA_EFFECTS_ENABLE_EXTERNAL_PACKS = "effect-enable-external-pack";

	/**
	 * By default Feather will resize the image loaded using the {@link Constants#getManagedMaxImageSize()} method based on the
	 * device memory. If you want to set at runtime the max image size allowed pass an integer value like this:<br />
	 * 
	 * <pre>
	 * intent.putExtra( &quot;max-image-size&quot;, 1024 );
	 * </pre>
	 * 
	 * Remember that the available application memory is shared between the host application and the Aviary editor, so you should
	 * keep that in mind when setting the max image size.
	 */
	public static final String EXTRA_MAX_IMAGE_SIZE = "max-image-size";

}
