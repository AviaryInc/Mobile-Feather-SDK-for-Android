package com.aviary.android.feather.plugins;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.Resources;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.utils.PackageManagerUtils;

public class PluginManager extends BackgroundRunnable {
	
	private ApplicationInfo mThisInfo;
	private Context mContext;
	@SuppressWarnings("unused")
	private String mPackageName;
	private String mBaseName;
	private HashMap<String, ApplicationInfo> mInstalled;
	private Logger logger;

	public PluginManager( Context context, String baseName ) {
		mContext = context;
		mPackageName = context.getPackageName();
		mBaseName = baseName;
		mInstalled = new HashMap<String, ApplicationInfo>();
		logger = LoggerFactory.getLogger( "PluginManager", LoggerType.ConsoleLoggerType );
		init();
	}
	
	private void init()
	{
		mThisInfo = PackageManagerUtils.getApplicationInfo( mContext );
	}

	public void update() {
		requestUpdate();
	}
	
	/**
	 * Return a list of ApplicationInfo currently installed on the system
	 * which contains the folder @name into their assets folder
	 * @param name
	 * @return
	 */
	public List<ApplicationInfo> listAssetsPlugins( String name )
	{
		List<ApplicationInfo> result = new ArrayList<ApplicationInfo>();
		if( mThisInfo != null )
		{
			result.add( mThisInfo );
		}
		
		synchronized ( mInstalled ) {
			Iterator<ApplicationInfo> iterator = mInstalled.values().iterator();
			while( iterator.hasNext() )
			{
				ApplicationInfo info = iterator.next();
				Resources resource;
				String[] files = null;
				try {
					resource = mContext.getPackageManager().getResourcesForApplication( info );
					files = resource.getAssets().list( "" );
				} catch ( NameNotFoundException e ) {
					e.printStackTrace();
				} catch ( IOException e ) {
					e.printStackTrace();
				}
				
				for( String file : files )
				{
					if( file.equals( name ))
					{
						result.add( info );
						break;
					}
				}
			}
		}
		
		return result;
	}
	
	@Override
	public void run() {
		logger.log( "run..." );
		PackageManager manager = mContext.getPackageManager();
		List<ApplicationInfo> apps = manager.getInstalledApplications( 0 );

		@SuppressWarnings("unused")
		boolean changed = false;
		synchronized ( mInstalled ) {
			if( mInstalled.size() > 0 )
			{
				Iterator<String> keys = mInstalled.keySet().iterator();
				while ( keys.hasNext() ) {
					String name = keys.next();
					boolean found = false;
					for( ApplicationInfo info : apps )
					{
						if( info.packageName.equals( name ))
						{
							found = true;
							break;
						}
					}
					
					if( !found )
					{
						mInstalled.remove( name );
						changed = true;
					}
				}
			}

			Iterator<ApplicationInfo> iter = apps.iterator();
			while ( iter.hasNext() ) {
				ApplicationInfo info = iter.next();
				String packageName = info.packageName;
				if ( packageName.startsWith( mBaseName + ".plugins." ) ) {
					if ( !mInstalled.containsKey( packageName ) ) {
						mInstalled.put( packageName, info );
						logger.log( "founded", packageName );
						changed = true;
					}
				}
			}
		}
	}
}
