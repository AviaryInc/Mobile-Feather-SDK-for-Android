package com.aviary.android.feather.plugins;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.content.res.Resources;


public class ThemeManager {
	private Resources mRes;
	private ApplicationInfo mInfo;
	
	public ThemeManager( PackageManager packageManager, ApplicationInfo info ) throws NameNotFoundException
	{
		mInfo = info;
		mRes = packageManager.getResourcesForApplication( info );
	}
	
	public String getPackageName(){
		return mInfo.packageName;
	}
	

	public AssetManager getAssets(){
		return mRes.getAssets();
	}

}
