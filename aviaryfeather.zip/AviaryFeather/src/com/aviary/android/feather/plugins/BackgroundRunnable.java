package com.aviary.android.feather.plugins;


public abstract class BackgroundRunnable implements Runnable {
	
	public interface OnUpdateListener {
		void onUpdate( BackgroundRunnable runnable );
	}
	
	protected OnUpdateListener mListener;
	
	public void setOnUpdateListener( OnUpdateListener listener )
	{
		mListener = listener;
	}
	
	protected void requestUpdate()
	{
		if( mListener != null )
		{
			mListener.onUpdate( this );
		}
	}
}
