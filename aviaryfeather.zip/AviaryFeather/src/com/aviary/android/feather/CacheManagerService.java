package com.aviary.android.feather;

import it.sephiroth.android.library.imagezoom.IDisposable;

import java.io.File;

public class CacheManagerService extends EffectContextService implements IDisposable {

	private File mCacheDir;

	protected CacheManagerService( EffectContext context ) {
		super( context );
		File file = new File( context.getBaseContext().getCacheDir(), ".tmp" );
		if( !file.exists() ) {
			if( file.mkdir() ) {
				mCacheDir = file;
			}
		} else {
			mCacheDir = file;
		}
	}

	public File createTempFile( String prefix, String suffix ) {
		return new File( mCacheDir, prefix + suffix );
	}

	@Override
	public void dispose() {
	}
}
