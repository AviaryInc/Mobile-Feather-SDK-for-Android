package com.aviary.android.feather.content;

import android.content.Intent;


public class FeatherIntent extends Intent {
	public static final String ACTION_PLUGIN_ADDED = "aviary.android.intent.ACTION_PLUGIN_ADDED";
	public static final String ACTION_PLUGIN_REMOVED = "aviary.android.intent.ACTION_PLUGIN_REMOVED";
	public static final String ACTION_PLUGIN_REPLACED = "aviary.android.intent.ACTION_PLUGIN_REPLACED";
}
