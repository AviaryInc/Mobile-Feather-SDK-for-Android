package com.aviary.android.feather.services;

import com.aviary.android.feather.library.filters.FilterLoaderFactory;
import com.aviary.android.feather.library.filters.FilterLoaderFactory.Filters;
import com.aviary.android.feather.library.filters.IFilter;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.EffectContextService;


public final class FilterService extends EffectContextService {

	public FilterService( EffectContext context ) {
		super( context );
	}
	
	public IFilter load( Filters type ){
		return FilterLoaderFactory.get( type );
	}

	@Override
	public void dispose() {
	}
}
