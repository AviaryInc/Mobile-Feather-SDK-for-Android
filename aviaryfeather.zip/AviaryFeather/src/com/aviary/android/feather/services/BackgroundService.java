package com.aviary.android.feather.services;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.EffectContextService;
import com.aviary.android.feather.plugins.BackgroundRunnable;
import com.aviary.android.feather.plugins.BackgroundRunnable.OnUpdateListener;

public class BackgroundService extends EffectContextService implements OnUpdateListener {
	
	private LinkedList<Runnable> tasks;
	private List<BackgroundRunnable> internalTasks;

	private Thread thread;
	private boolean running;
	private Runnable internalRunnable;
	Logger logger;

	private class InternalRunnable implements Runnable {

		@Override
		public void run() {
			internalRun();
		}
	}

	public BackgroundService( EffectContext context ) {
		super( context );
		tasks = new LinkedList<Runnable>();
		internalTasks = new ArrayList<BackgroundRunnable>();
		internalRunnable = new InternalRunnable();
		logger = LoggerFactory.getLogger( "BackgroundService", LoggerType.ConsoleLoggerType );
	}

	public void register( BackgroundRunnable task, boolean runImmediately ) {
		synchronized ( internalTasks ) {
			if ( !internalTasks.contains( task ) ) {
				internalTasks.add( task );
				task.setOnUpdateListener( this );
			}
		}

		if ( runImmediately ) {
			addTask( task );
		}
	}

	public BackgroundRunnable getInternalTask( Class<? extends BackgroundRunnable> cls ) {
		synchronized ( internalTasks ) {
			Iterator<? extends BackgroundRunnable> iterator = internalTasks.iterator();
			while ( iterator.hasNext() ) {
				BackgroundRunnable entry = iterator.next();
				if ( entry.getClass().equals( cls ) ) return entry;
			}
		}
		return null;
	}

	public void start() {
		logger.info( "start" );
		if ( !running ) {
			thread = new Thread( internalRunnable );
			thread.setDaemon( true );
			running = true;
			thread.start();
		}
	}

	public void stop() {
		logger.info( "stop" );
		running = false;
	}

	public void addTask( Runnable task ) {
		synchronized ( tasks ) {
			tasks.addFirst( task );
			tasks.notify(); // notify any waiting threads
		}
	}

	private Runnable getNextTask() {
		synchronized ( tasks ) {
			if ( tasks.isEmpty() ) {
				try {
					tasks.wait();
				} catch ( InterruptedException e ) {
					logger.log( "Task interrupted: " + e );
					e.printStackTrace();
					stop();
				}
			}
			return tasks.removeLast();
		}
	}

	private void internalRun() {
		while ( running ) {
			Runnable task = getNextTask();
			try {
				task.run();
			} catch ( Throwable t ) {
				logger.error( t );
				t.printStackTrace();
			}
		}
	}

	@Override
	public void onUpdate( BackgroundRunnable runnable ) {
		logger.info( "onUpdate", runnable );
		addTask( runnable );
	}

	@Override
	public void dispose() {
		logger.info( "dispose" );
		synchronized ( internalTasks ) {
			while ( internalTasks.size() > 0 ) {
				BackgroundRunnable runnable = internalTasks.remove( 0 );
				runnable.setOnUpdateListener( null );
			}
		}
		stop();
	}
}