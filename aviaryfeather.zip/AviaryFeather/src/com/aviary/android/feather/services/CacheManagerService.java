package com.aviary.android.feather.services;


import java.io.File;
import com.aviary.android.feather.library.services.EffectContext;
import com.aviary.android.feather.library.services.EffectContextService;
import com.aviary.android.feather.library.utils.IDisposable;

public class CacheManagerService extends EffectContextService implements IDisposable {

	private File mCacheDir;

	public CacheManagerService( EffectContext context ) {
		super( context );
		File file = new File( context.getBaseContext().getCacheDir(), ".tmp" );
		if( !file.exists() ) {
			if( file.mkdir() ) {
				mCacheDir = file;
			}
		} else {
			mCacheDir = file;
		}
	}

	public File createTempFile( String prefix, String suffix ) {
		return new File( mCacheDir, prefix + suffix );
	}

	@Override
	public void dispose() {
	}
}
