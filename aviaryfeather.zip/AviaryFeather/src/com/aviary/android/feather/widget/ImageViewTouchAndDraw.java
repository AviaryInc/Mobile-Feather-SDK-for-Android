package com.aviary.android.feather.widget;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import it.sephiroth.android.library.imagezoom.RotateBitmap;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.MotionEvent;

public class ImageViewTouchAndDraw extends ImageViewTouch {

	public static enum TouchMode {
		IMAGE, DRAW
	};

	public static interface OnDrawStartListener {

		void onDrawStart();
	};

	protected Paint mPaint;
	protected Path tmpPath = new Path();
	protected Canvas mCanvas;
	protected TouchMode mTouchMode = TouchMode.DRAW;
	protected float mX, mY;
	protected Matrix mIdentityMatrix = new Matrix();
	protected Matrix mInvertedMatrix = new Matrix();
	protected Bitmap mCopy;
	protected static final float TOUCH_TOLERANCE = 4;

	private OnDrawStartListener mDrawListener;

	public ImageViewTouchAndDraw( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	public void setOnDrawStartListener( OnDrawStartListener listener ) {
		mDrawListener = listener;
	}

	@Override
	protected void init() {
		super.init();
		mPaint = new Paint( Paint.ANTI_ALIAS_FLAG );
		mPaint.setFilterBitmap( false );
		mPaint.setColor( 0xFFFF0000 );
		mPaint.setStyle( Paint.Style.STROKE );
		mPaint.setStrokeJoin( Paint.Join.ROUND );
		mPaint.setStrokeCap( Paint.Cap.ROUND );
		mPaint.setStrokeWidth( 10.0f );

		tmpPath = new Path();
	}

	public TouchMode getDrawMode() {
		return mTouchMode;
	}

	public void setDrawMode( TouchMode mode ) {
		if( mode != mTouchMode ) {
			mTouchMode = mode;
			onDrawModeChanged();
		}
	}

	protected void onDrawModeChanged() {
		if( mTouchMode == TouchMode.DRAW ) {

			Matrix m1 = new Matrix( getImageMatrix() );
			mInvertedMatrix.reset();

			float[] v1 = getMatrixValues( m1 );
			m1.invert( m1 );
			float[] v2 = getMatrixValues( m1 );

			mInvertedMatrix.postTranslate( -v1[Matrix.MTRANS_X], -v1[Matrix.MTRANS_Y] );
			mInvertedMatrix.postScale( v2[Matrix.MSCALE_X], v2[Matrix.MSCALE_Y] );
			mCanvas.setMatrix( mInvertedMatrix );
		}
	}

	public Paint getPaint() {
		return mPaint;
	}

	public void setPaint( Paint paint ) {
		mPaint.set( paint );
	}

	@Override
	protected void onDraw( Canvas canvas ) {
		super.onDraw( canvas );

		if( mCopy != null ) {
			final int saveCount = canvas.getSaveCount();
			canvas.save();
			canvas.drawBitmap( mCopy, getImageMatrix(), null );
			canvas.restoreToCount( saveCount );
		}
	}

	public void commit( Canvas canvas ) {
		canvas.drawBitmap( getDisplayBitmap().getBitmap(), new Matrix(), null );
		canvas.drawBitmap( mCopy, new Matrix(), null );
	}

	@Override
	protected void onBitmapChanged( RotateBitmap bitmap ) {
		super.onBitmapChanged( bitmap );

		if( mCopy != null ) {
			mCopy.recycle();
			mCopy = null;
		}

		if( bitmap != null && bitmap.getBitmap() != null ) {
			mCopy = Bitmap.createBitmap( bitmap.getWidth(), bitmap.getHeight(), Config.ARGB_8888 );
			mCanvas = new Canvas( mCopy );
			mCanvas.drawColor( 0 );
			//mCanvas.drawBitmap( bitmap.getBitmap(), mIdentityMatrix, null );
			onDrawModeChanged();
		}
	}

	private void touch_start( float x, float y ) {
		tmpPath.reset();
		tmpPath.moveTo( x, y );

		mX = x;
		mY = y;

		if( mDrawListener != null )
			mDrawListener.onDrawStart();
	}

	private void touch_move( float x, float y ) {
		float dx = Math.abs( x - mX );
		float dy = Math.abs( y - mY );
		if( dx >= TOUCH_TOLERANCE || dy >= TOUCH_TOLERANCE ) {
			tmpPath.quadTo( mX, mY, (x + mX) / 2, (y + mY) / 2 );
			mCanvas.drawPath( tmpPath, mPaint );

			tmpPath.reset();
			tmpPath.moveTo( (x + mX) / 2, (y + mY) / 2 );

			mX = x;
			mY = y;
		}
	}

	public static float[] getMatrixValues( Matrix m ) {
		float[] values = new float[9];
		m.getValues( values );
		return values;
	}

	private void touch_up() {
		tmpPath.reset();
	}

	@Override
	public boolean onTouchEvent( MotionEvent event ) {
		if( mTouchMode == TouchMode.DRAW && event.getPointerCount() == 1 ) {
			float x = event.getX();
			float y = event.getY();

			switch( event.getAction() ) {
				case MotionEvent.ACTION_DOWN:
					touch_start( x, y );
					invalidate();
					break;
				case MotionEvent.ACTION_MOVE:
					touch_move( x, y );
					invalidate();
					break;
				case MotionEvent.ACTION_UP:
					touch_up();
					invalidate();
					break;
			}
			return true;
		} else {
			if( mTouchMode == TouchMode.IMAGE )
				return super.onTouchEvent( event );
			else
				return false;
		}
	}

	public Bitmap getOverlayBitmap() {
		return mCopy;
	}

}
