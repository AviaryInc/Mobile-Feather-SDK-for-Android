package com.aviary.android.feather.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.TranslateAnimation;
import android.widget.LinearLayout;
import com.aviary.android.feather.R;

public class FilterOptionsSlider extends LinearLayout {

	public static interface OnPanelOpenListener {

		void onOpening();

		void onOpened();
	};

	public static interface OnPanelCloseListener {

		void onClosing();

		void onClosed();
	};

	private OnPanelOpenListener mOpenListener;
	private OnPanelCloseListener mCloseListener;
	private boolean opened;
	private Animation openAnimation;
	private Animation closeAnimation;
	private FilterOptionsView mContentView;

	public FilterOptionsSlider( Context context, AttributeSet attrs ) {
		super( context, attrs );
		init( context, attrs );
	}

	/**
	 * Returns the application options panel view
	 * which will contains all the filters options
	 * 
	 * @see FilterOptionsView
	 * @return
	 */
	public FilterOptionsView getContent() {
		return mContentView;
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
		mContentView = (FilterOptionsView) findViewById( R.id.content );
	}

	private void init( Context context, AttributeSet attrs ) {

		int closeAnimDuration = 400;
		int openAnimDuration = 400;
		int closeAnimInterpolator = android.R.anim.accelerate_interpolator;
		int openAnimInterpolator = android.R.anim.decelerate_interpolator;

		TypedArray a = context.obtainStyledAttributes( attrs, R.styleable.FeatherTheme );
		for( int i = 0; i < a.getIndexCount(); i++ ) {
			int attr = a.getIndex( i );
			switch( a.getIndex( i ) ) {
				case R.styleable.FeatherTheme_options_open_anim_duration:
					openAnimDuration = a.getInt( attr, 4000 );
					break;

				case R.styleable.FeatherTheme_options_close_anim_duration:
					closeAnimDuration = a.getInt( attr, 4000 );
					break;

				case R.styleable.FeatherTheme_options_open_anim_interpolator:
					openAnimInterpolator = a.getResourceId( attr, android.R.anim.decelerate_interpolator );
					break;

				case R.styleable.FeatherTheme_options_close_anim_interpolator:
					closeAnimInterpolator = a.getResourceId( attr, android.R.anim.accelerate_interpolator );
					break;
			}
		}

		openAnimation = new TranslateAnimation( TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF, 0,
				TranslateAnimation.RELATIVE_TO_SELF, 1, TranslateAnimation.RELATIVE_TO_SELF, 0 );
		openAnimation.setDuration( openAnimDuration );
		openAnimation.setStartOffset( 150 );
		openAnimation.setInterpolator( getContext(), openAnimInterpolator );
		openAnimation.setAnimationListener( openAnimationListener );

		closeAnimation = new TranslateAnimation( TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF, 0,
				TranslateAnimation.RELATIVE_TO_SELF, 0, TranslateAnimation.RELATIVE_TO_SELF, 1 );
		closeAnimation.setDuration( closeAnimDuration );
		closeAnimation.setInterpolator( getContext(), closeAnimInterpolator );
		closeAnimation.setAnimationListener( closeAnimationListener );

		setAlwaysDrawnWithCacheEnabled( false );
	}

	public void setOnPanelOpenListener( OnPanelOpenListener listener ) {
		mOpenListener = listener;
	}

	public void setOnPanelCloseListener( OnPanelCloseListener listener ) {
		mCloseListener = listener;
	}

	/**
	 * Return the current status of the panel
	 * opended means that the panel is currently visible
	 * on the stage ( expanded or contracted doesn't matter here )
	 */
	public boolean isOpened() {
		return opened;
	}

	/**
	 * Show with an animation effect the panel on the stage.
	 * 
	 */
	public void open() {

		if( opened )
			throw new IllegalStateException( "options panel is already opened!" );

		clearAnimation();
		enableChildrenCache();
		startAnimation( openAnimation );
		setVisibility( View.VISIBLE );
	}

	/**
	 * Hide the panel
	 */
	public void close() {

		if( !opened )
			throw new IllegalStateException( "options panel is already closed!" );

		clearAnimation();
		enableChildrenCache();
		startAnimation( closeAnimation );
	}

	void enableChildrenCache() {
		mContentView.buildDrawingCache();
		/*
		 * setChildrenDrawnWithCacheEnabled( true );
		 * setChildrenDrawingCacheEnabled( true );
		 * 
		 * for( int i = 0; i < getChildCount(); i++ ) {
		 * final View child = getChildAt( i );
		 * child.setDrawingCacheEnabled( true );
		 * child.buildDrawingCache( true );
		 * }
		 */
	}

	void clearChildrenCache() {
		mContentView.destroyDrawingCache();
		/*
		 * setChildrenDrawnWithCacheEnabled( false );
		 * setChildrenDrawingCacheEnabled( false );
		 * 
		 * for( int i = 0; i < getChildCount(); i++ ) {
		 * final View child = getChildAt( i );
		 * child.setDrawingCacheEnabled( false );
		 * child.destroyDrawingCache();
		 * }
		 */
	}

	final AnimationListener openAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationStart( Animation animation ) {
			setVisibility( View.VISIBLE );
			if( mOpenListener != null )
				mOpenListener.onOpening();
			opened = true;
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {
		}

		@Override
		public void onAnimationEnd( Animation animation ) {
			clearChildrenCache();
			if( mOpenListener != null )
				mOpenListener.onOpened();
		}
	};

	final AnimationListener closeAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationStart( Animation animation ) {
			if( mCloseListener != null )
				mCloseListener.onClosing();
			opened = false;
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {
		}

		@Override
		public void onAnimationEnd( Animation animation ) {
			clearChildrenCache();
			setVisibility( View.GONE );

			if( mCloseListener != null )
				mCloseListener.onClosed();
		}
	};

	@Override
	protected void onDetachedFromWindow() {
		mOpenListener = null;
		mCloseListener = null;
		super.onDetachedFromWindow();
	}

}
