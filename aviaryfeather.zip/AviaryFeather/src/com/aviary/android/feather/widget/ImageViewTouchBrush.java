package com.aviary.android.feather.widget;

import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;

public class ImageViewTouchBrush extends ImageViewTouch {

	private BrushHighlight mBrushHighlight;
	private OnSingleTapConfirmedListener mSingleTapConfirmedListener;

	public static interface OnSingleTapConfirmedListener {

		void onSingleTap( float x, float y );
	}

	public ImageViewTouchBrush( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	@Override
	protected void init() {
		super.init();
		mBrushHighlight = new BrushHighlight( this );
	}

	@Override
	protected void onDraw( Canvas canvas ) {
		super.onDraw( canvas );
		mBrushHighlight.draw( canvas );
	}

	@Override
	protected OnGestureListener getGestureListener() {
		return new GestureListenerNoDoubleTap();
	}

	@Override
	protected void onDetachedFromWindow() {
		mBrushHighlight.clear();
		mBrushHighlight = null;
		super.onDetachedFromWindow();
	}

	public void setOnSingleTapConfirmedListener( OnSingleTapConfirmedListener listener ) {
		mSingleTapConfirmedListener = listener;
	}

	private void doSomeStuff( float x, float y ) {

		if( mSingleTapConfirmedListener != null ) {
			mSingleTapConfirmedListener.onSingleTap( x, y );
		}
		
		playSoundEffect( SoundEffectConstants.CLICK );
		mBrushHighlight.addTouch( x, y, mBrushDuration, mBrushEndSize / 2, mBrushEndSize );

	}

	class GestureListenerNoDoubleTap extends GestureListener {

		@Override
		public boolean onSingleTapConfirmed( MotionEvent e ) {
			doSomeStuff( e.getX(), e.getY() );
			return super.onSingleTapConfirmed( e );
		}

		@Override
		public boolean onDoubleTap( MotionEvent e ) {
			doSomeStuff( e.getX(), e.getY() );
			return false;
		}
	}

	private float mBrushEndSize = 10.f;
	private long mBrushDuration = 400;

	public void setTapRadius( float f ) {
		mBrushEndSize = f;
	}

	public void setBrushDuration( long duration ) {
		mBrushDuration = duration;
	}
}
