package com.aviary.android.feather.widget;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Message;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.aviary.android.feather.InfoScreenActivity;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.log.Logger;

public class ToolbarView extends ViewFlipper {

	public static interface OnToolbarClickListener {
		void onUndoClick();
		void onRedoClick();
		void onSaveClick();
		void onApplyClick();
		void onCancelClick();
	};

	public static enum STATE {
		STATE_SAVE, STATE_APPLY,
	};

	private Button mApplyButton;
	private Button mCancelButton;
	private Button mUndoButton;
	private Button mRedoButton;
	private Button mSaveButton;
	private TextView mTitleText;
	private View mAviaryLogo;

	@SuppressWarnings("unused")
	private boolean isAnimating;
	private STATE mCurrentState;
	private Animation mOutAnimation;
	private Animation mInAnimation;
	private OnToolbarClickListener mListener;
	private Typeface mTypeFace = null;
	private boolean mClickable;

	private static final int MSG_SHOW_CHILD = 1;

	private Handler mHandler = new Handler() {

		@Override
		public void handleMessage( android.os.Message msg ) {
			switch ( msg.what ) {
				case MSG_SHOW_CHILD:
					setDisplayedChild( msg.arg1 );
					break;
			}
		};
	};

	public ToolbarView( Context context ) {
		super( context );
		init( context, null );
	}

	public ToolbarView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		init( context, attrs );
	}

	private void init( Context context, AttributeSet attrs ) {
		mCurrentState = STATE.STATE_SAVE;

		if ( attrs != null ) {
			TypedArray a = getContext().obtainStyledAttributes( attrs,
					com.aviary.android.feather.R.styleable.com_aviary_android_feather_Custom );
			for ( int i = 0; i < a.getIndexCount(); i++ ) {
				switch ( a.getIndex( i ) ) {
					case R.styleable.com_aviary_android_feather_Custom_toolbar_fontname:
						
						final String fontName = a.getString(i);
						
						if( fontName != null && fontName.length() > 0 ){
							try {
								mTypeFace = Typeface.createFromAsset( context.getAssets(), fontName );
							} catch ( Exception e ) {
								Logger.error( this, e.getMessage() );
							}
						}
						break;
				}
			}
		}
		
		setAnimationCacheEnabled( true );
		setAlwaysDrawnWithCacheEnabled( true );
	}

	@Override
	public void setClickable( boolean clickable ) {
		mClickable = clickable;
	}

	@Override
	public boolean isClickable() {
		return mClickable;
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();

		mApplyButton = (Button) findViewById( R.id.button_apply );
		mCancelButton = (Button) findViewById( R.id.button_cancel );
		mUndoButton = (Button) findViewById( R.id.button_undo );
		mRedoButton = (Button) findViewById( R.id.button_redo );
		mSaveButton = (Button) findViewById( R.id.button_save );
		mTitleText = (TextView) findViewById( R.id.toolbar_title );
		mAviaryLogo = findViewById( R.id.aviary_logo );

		if ( mTypeFace != null ) {
			mApplyButton.setTypeface( mTypeFace );
			mUndoButton.setTypeface( mTypeFace );
			mRedoButton.setTypeface( mTypeFace );
			mCancelButton.setTypeface( mTypeFace );
			mSaveButton.setTypeface( mTypeFace );
			mTitleText.setTypeface( mTypeFace );
		}

		mOutAnimation = new ScaleAnimation( 1.0f, 1.0f, 1.0f, 0.0f, ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
				ScaleAnimation.RELATIVE_TO_SELF, 0.5f );
		mOutAnimation.setDuration( 300 );
		mOutAnimation.setAnimationListener( mInAnimationListener );

		mInAnimation = new ScaleAnimation( 1.0f, 1.0f, 0.0f, 1.0f, ScaleAnimation.RELATIVE_TO_SELF, 0.5f,
				ScaleAnimation.RELATIVE_TO_SELF, 0.5f );
		mInAnimation.setInterpolator( new DecelerateInterpolator() );
		mInAnimation.setDuration( 300 );
		mInAnimation.setStartOffset( mOutAnimation.getDuration() / 2 );
		mInAnimation.setAnimationListener( mInAnimationListener );

		setInAnimation( mInAnimation );
		setOutAnimation( mOutAnimation );

		mUndoButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mListener != null && mCurrentState == STATE.STATE_SAVE && isClickable() ) mListener.onUndoClick();
			}
		} );

		mRedoButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mListener != null && mCurrentState == STATE.STATE_SAVE && isClickable() ) mListener.onRedoClick();
			}
		} );

		mApplyButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mListener != null && mCurrentState == STATE.STATE_APPLY && isClickable() ) mListener.onApplyClick();
			}
		} );

		mCancelButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mListener != null && mCurrentState == STATE.STATE_APPLY && isClickable() ) mListener.onCancelClick();
			}
		} );

		mSaveButton.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				if ( mListener != null && mCurrentState == STATE.STATE_SAVE && isClickable() ) mListener.onSaveClick();
			}
		} );

		mAviaryLogo.setOnClickListener( new OnClickListener() {

			@Override
			public void onClick( View v ) {
				// TODO: check the internet connection first

				Intent intent = new Intent( getContext(), InfoScreenActivity.class );
				try {
					getContext().startActivity( intent );
				} catch( ActivityNotFoundException e ){
					e.printStackTrace();
				}
			}
		} );
	}

	/**
	 * Change the current toolbar state creating an animation between the current and the new view state
	 * 
	 * @param state
	 */
	public void setState( STATE state, final boolean showMiddle ) {
		if ( state != mCurrentState ) {
			mCurrentState = state;

			post( new Runnable() {
				
				@Override
				public void run() {
					switch ( mCurrentState ) {
						case STATE_APPLY:
							showApplyState();
							break;
							
						case STATE_SAVE:
							showSaveState( showMiddle );
							break;
					}
				}
			} );
		}
	}

	/**
	 * Return the current toolbar state
	 * 
	 * @see #STATE
	 * @return
	 */
	public STATE getState() {
		return mCurrentState;
	}

	/**
	 * Set the toolbar click listener
	 * 
	 * @see OnToolbarClickListener
	 * @param listener
	 */
	public void setOnToolbarClickListener( OnToolbarClickListener listener ) {
		mListener = listener;
	}

	public void setUndoEnabled( boolean value ) {
		mUndoButton.setEnabled( value );
	}

	public void setRedoEnabled( boolean value ) {
		mRedoButton.setEnabled( value );
	}

	public void setApplyEnabled( boolean value ) {
		mApplyButton.setEnabled( value );
	}

	@Override
	public void setSaveEnabled( boolean value ) {
		mSaveButton.setEnabled( value );
	}

	public void setTitle( CharSequence value ) {
		mTitleText.setText( value );
	}

	public void setTitle( int resourceId ) {
		setTitle( getContext().getString( resourceId ) );
	}

	private void showApplyState() {
		//enableChildrenCache();
		setDisplayedChild( getChildCount() - 1 );
	}

	private void showSaveState( boolean showMiddle ) {
		//enableChildrenCache();

		if ( showMiddle && getChildCount() == 3 )
			setDisplayedChild( 1 );
		else
			setDisplayedChild( 0 );
	}

	private void enableChildrenCache() {

		setChildrenDrawnWithCacheEnabled( true );
		setChildrenDrawingCacheEnabled( true );

		for ( int i = 0; i < getChildCount(); i++ ) {
			final View child = getChildAt( i );
			child.setDrawingCacheEnabled( true );
			child.buildDrawingCache( true );
		}
	}

	private void clearChildrenCache() {
		setChildrenDrawnWithCacheEnabled( false );
	}

	public void setApplyEnabled( boolean applyEnabled, boolean cancelEnabled ) {
		mApplyButton.setEnabled( applyEnabled );
		mCancelButton.setEnabled( cancelEnabled );
	}

	AnimationListener mInAnimationListener = new AnimationListener() {

		@Override
		public void onAnimationStart( Animation animation ) {
			isAnimating = true;
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {}

		@Override
		public void onAnimationEnd( Animation animation ) {
			//clearChildrenCache();
			isAnimating = false;
			if ( getDisplayedChild() == 1 && getChildCount() > 2 ) {
				Thread t = new Thread( new Runnable() {

					@Override
					public void run() {
						try {
							Thread.sleep( 300 );
						} catch ( InterruptedException e ) {
							e.printStackTrace();
						}

						Message msg = mHandler.obtainMessage( MSG_SHOW_CHILD );
						msg.arg1 = 0;
						mHandler.sendMessage( msg );
					}
				} );
				t.start();
			}
		}
	};
}
