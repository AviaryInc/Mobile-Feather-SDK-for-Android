/*
 * HorizontalListView.java v1.5
 *
 * 
 * The MIT License
 * Copyright (c) 2011 Paul Soucy (paul@dev-smart.com)
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

package com.aviary.android.feather.widget;

import java.util.LinkedList;
import java.util.Queue;
import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.OverScroller;
import android.widget.Scroller;

// TODO: Auto-generated Javadoc
/**
 * The Class HorizontialFixedListView.
 */
public class HorizontialFixedListView extends AdapterView<ListAdapter> implements OnGestureListener {

	/** The Constant LOG_TAG. */
	protected static final String LOG_TAG = "hv";
	
	/** The m always override touch. */
	public boolean mAlwaysOverrideTouch = true;
	
	/** The m adapter. */
	protected ListAdapter mAdapter;
	
	/** The m left view index. */
	private int mLeftViewIndex = -1;
	
	/** The m right view index. */
	private int mRightViewIndex = 0;
	
	/** The m gesture. */
	private GestureDetector mGesture;
	
	/** The m removed view queue. */
	private Queue<View> mRemovedViewQueue = new LinkedList<View>();
	
	/** The m on item selected. */
	private OnItemSelectedListener mOnItemSelected;
	
	/** The m on item clicked. */
	private OnItemClickListener mOnItemClicked;
	
	/** The m data changed. */
	private boolean mDataChanged = false;
	
	/** The m fling runnable. */
	private IFlingRunnable mFlingRunnable;
	
	/** The m force layout. */
	private boolean mForceLayout;

	/**
	 * Instantiates a new horizontial fixed list view.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 */
	public HorizontialFixedListView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		initView();
	}

	/**
	 * Inits the view.
	 */
	private synchronized void initView() {

		if ( Build.VERSION.SDK_INT > 8 )
			mFlingRunnable = new Fling9Runnable();
		else
			mFlingRunnable = new Fling8Runnable();

		mLeftViewIndex = -1;
		mRightViewIndex = 0;
		mMaxX = 0;
		mMinX = 0;
		mChildWidth = 0;
		mChildHeight = 0;
		mRightEdge = 0;
		mLeftEdge = 0;
		mGesture = new GestureDetector( getContext(), mGestureListener );
		mGesture.setIsLongpressEnabled( false );

		setFocusable( true );
		setFocusableInTouchMode( true );

		mTouchSlop = ViewConfiguration.getTouchSlop();
	}

	/**
	 * Track motion scroll.
	 *
	 * @param newX the new x
	 */
	void trackMotionScroll( int newX ) {
		scrollTo( newX, 0 );
		mCurrentX = getScrollX();
		removeNonVisibleItems( mCurrentX );
		fillList( mCurrentX );
		invalidate();
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#setOnItemSelectedListener(android.widget.AdapterView.OnItemSelectedListener)
	 */
	@Override
	public void setOnItemSelectedListener( AdapterView.OnItemSelectedListener listener ) {
		mOnItemSelected = listener;
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#setOnItemClickListener(android.widget.AdapterView.OnItemClickListener)
	 */
	@Override
	public void setOnItemClickListener( AdapterView.OnItemClickListener listener ) {
		mOnItemClicked = listener;
	}

	/** The m data observer. */
	private DataSetObserver mDataObserver = new DataSetObserver() {

		@Override
		public void onChanged() {
			synchronized ( HorizontialFixedListView.this ) {
				mDataChanged = true;
			}
			invalidate();
			mForceLayout = true;
			requestLayout();
		}

		@Override
		public void onInvalidated() {
			reset();
			invalidate();
			mForceLayout = true;
			requestLayout();
		}
	};

	/** The m height measure spec. */
	private int mHeightMeasureSpec;
	
	/** The m width measure spec. */
	private int mWidthMeasureSpec;
	
	/** The m is first scroll. */
	private boolean mIsFirstScroll;
	
	/** The m left edge. */
	private int mRightEdge, mLeftEdge;

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#getAdapter()
	 */
	@Override
	public ListAdapter getAdapter() {
		return mAdapter;
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#getSelectedView()
	 */
	@Override
	public View getSelectedView() {
		// TODO: implement
		return null;
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#setAdapter(android.widget.Adapter)
	 */
	@Override
	public void setAdapter( ListAdapter adapter ) {

		if ( mAdapter != null ) {
			mAdapter.unregisterDataSetObserver( mDataObserver );
		}
		mAdapter = adapter;
		
		if( mAdapter != null ){
			mAdapter.registerDataSetObserver( mDataObserver );
		}
		reset();
	}

	/**
	 * Reset.
	 */
	private synchronized void reset() {
		initView();
		removeAllViewsInLayout();
		mRemovedViewQueue.clear();
		mForceLayout = true;
		requestLayout();
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#setSelection(int)
	 */
	@Override
	public void setSelection( int position ) {
		// TODO: implement
	}

	/* (non-Javadoc)
	 * @see android.view.View#onMeasure(int, int)
	 */
	@Override
	protected void onMeasure( int widthMeasureSpec, int heightMeasureSpec ) {
		super.onMeasure( widthMeasureSpec, heightMeasureSpec );

		mHeightMeasureSpec = heightMeasureSpec;
		mWidthMeasureSpec = widthMeasureSpec;
	}

	/**
	 * Adds the and measure child.
	 *
	 * @param child the child
	 * @param viewPos the view pos
	 */
	private void addAndMeasureChild( final View child, int viewPos ) {
		LayoutParams params = child.getLayoutParams();

		if ( params == null ) {
			params = new LayoutParams( LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT );
		}

		addViewInLayout( child, viewPos, params );
		int childHeightSpec = ViewGroup.getChildMeasureSpec( mHeightMeasureSpec, getPaddingTop() + getPaddingBottom(), params.height );
		int childWidthSpec = ViewGroup.getChildMeasureSpec( mWidthMeasureSpec, getPaddingLeft() + getPaddingRight(), params.width );
		child.measure( childWidthSpec, childHeightSpec );
	}

	/* (non-Javadoc)
	 * @see android.widget.AdapterView#onLayout(boolean, int, int, int, int)
	 */
	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		super.onLayout( changed, left, top, right, bottom );

		if ( mAdapter == null ) {
			return;
		}

		if ( mDataChanged || mForceLayout ) {
			mCurrentX = mOldX = 0;
			initView();
			removeAllViewsInLayout();
			mDataChanged = false;
			mForceLayout = false;
			trackMotionScroll( 0 );
		}
	}

	/**
	 * Fill list.
	 *
	 * @param positionX the position x
	 */
	private void fillList( final int positionX ) {
		int edge = 0;

		View child = getChildAt( getChildCount() - 1 );
		if ( child != null ) {
			edge = child.getRight();
		}
		fillListRight( mCurrentX, edge );

		edge = 0;
		child = getChildAt( 0 );
		if ( child != null ) {
			edge = child.getLeft();
		}
		fillListLeft( mCurrentX, edge );
	}

	/**
	 * Fill list left.
	 *
	 * @param positionX the position x
	 * @param leftEdge the left edge
	 */
	private void fillListLeft( int positionX, int leftEdge ) {
		while ( ( leftEdge - positionX ) > mLeftEdge && mLeftViewIndex >= 0 ) {
			View child = mAdapter.getView( mLeftViewIndex, mRemovedViewQueue.poll(), this );
			addAndMeasureChild( child, 0 );

			int childTop = getPaddingTop();
			child.layout( leftEdge - mChildWidth, childTop, leftEdge, childTop + mChildHeight );
			leftEdge -= mChildWidth;
			mLeftViewIndex--;
		}
	}

	/**
	 * Fill list right.
	 *
	 * @param positionX the position x
	 * @param rightEdge the right edge
	 */
	private void fillListRight( int positionX, int rightEdge ) {
		boolean firstChild = getChildCount() == 0;

		while ( ( rightEdge - positionX ) < mRightEdge || firstChild ) {

			if ( mRightViewIndex >= mAdapter.getCount() ) {
				break;
			}

			View child = mAdapter.getView( mRightViewIndex, mRemovedViewQueue.poll(), this );
			addAndMeasureChild( child, -1 );

			if ( firstChild ) {
				mChildWidth = child.getMeasuredWidth();
				mChildHeight = child.getMeasuredHeight();
				mRightEdge = getWidth() + mChildWidth;
				mLeftEdge = -mChildWidth;
				mMaxX = Math.max( mAdapter.getCount() * ( mChildWidth ) - ( getWidth() ) - (mChildWidth/2), 0 );
				mMinX = 0;
				firstChild = false;
				
				Log.d( "hv", "original right: " + rightEdge );
				Log.d( "hv", "left: " + mLeftEdge );
				Log.d( "hv", "right: " + mRightEdge );
				Log.d( "hv", "minX: " + mMinX );
				Log.d( "hv", "maxX: " + mMaxX );
				Log.d( "hv", "width: " + getWidth() + ", " + getMeasuredWidth() );
				
				if( mMaxX == 0 ){
					rightEdge += getWidth() - (mAdapter.getCount() * mChildWidth);
					mLeftEdge = 0;
					mRightEdge = getWidth();
					Log.d( "hv", "new right: " + rightEdge );
				}
			}

			int childTop = getPaddingTop();
			child.layout( rightEdge, childTop, rightEdge + mChildWidth, childTop + child.getMeasuredHeight() );
			rightEdge += mChildWidth;
			mRightViewIndex++;
		}

	}

	/**
	 * Removes the non visible items.
	 *
	 * @param positionX the position x
	 */
	private void removeNonVisibleItems( final int positionX ) {
		View child = getChildAt( 0 );

		// remove to left...
		while ( child != null && child.getRight() - positionX <= mLeftEdge ) {
			mRemovedViewQueue.offer( child );
			removeViewInLayout( child );
			mLeftViewIndex++;
			child = getChildAt( 0 );
		}

		// remove to right...
		child = getChildAt( getChildCount() - 1 );
		while ( child != null && child.getLeft() - positionX >= mRightEdge ) {
			mRemovedViewQueue.offer( child );
			removeViewInLayout( child );
			mRightViewIndex--;
			child = getChildAt( getChildCount() - 1 );
		}
	}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onDown(android.view.MotionEvent)
	 */
	@Override
	public boolean onDown( MotionEvent event ) {
		mFlingRunnable.stop( false );
		mIsFirstScroll = true;
		return true;
	}

	/**
	 * On up.
	 */
	void onUp() {
		if ( mFlingRunnable.isFinished() ) {
			scrollIntoSlots();
		}
	}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onFling(android.view.MotionEvent, android.view.MotionEvent, float, float)
	 */
	@Override
	public boolean onFling( MotionEvent event0, MotionEvent event1, float velocityX, float velocityY ) {
		if( mMaxX == 0 ) return false;
		mFlingRunnable.startUsingVelocity( mCurrentX, (int) -velocityX );
		return true;
	}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onLongPress(android.view.MotionEvent)
	 */
	@Override
	public void onLongPress( MotionEvent arg0 ) {}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onScroll(android.view.MotionEvent, android.view.MotionEvent, float, float)
	 */
	@Override
	public boolean onScroll( MotionEvent event0, MotionEvent event1, float distanceX, float distanceY ) {
		
		if( mAdapter == null ) return false;
		if( mMaxX == 0 ) return false;
		
		getParent().requestDisallowInterceptTouchEvent( true );

		if ( mIsFirstScroll ) {
			if ( distanceX > 0 )
				distanceX -= mTouchSlop;
			else
				distanceX += mTouchSlop;
		}

		mIsFirstScroll = false;

		mToLeft = distanceX > 0; // finger direction

		if ( mToLeft ) {
			if ( mCurrentX + distanceX > mMaxX ) {
				distanceX /= 10;
			}
		} else {
			if ( mCurrentX + distanceX < mMinX ) {
				distanceX /= 10;
			}
		}

		trackMotionScroll( (int) ( mCurrentX + distanceX ) );
		return true;
	}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onShowPress(android.view.MotionEvent)
	 */
	@Override
	public void onShowPress( MotionEvent arg0 ) {}

	/* (non-Javadoc)
	 * @see android.view.GestureDetector.OnGestureListener#onSingleTapUp(android.view.MotionEvent)
	 */
	@Override
	public boolean onSingleTapUp( MotionEvent arg0 ) {
		return false;
	}

	/* (non-Javadoc)
	 * @see android.view.ViewGroup#dispatchTouchEvent(android.view.MotionEvent)
	 */
	@Override
	public boolean dispatchTouchEvent( MotionEvent ev ) {
		boolean handled = mGesture.onTouchEvent( ev );

		if ( !handled ) {
			int action = ev.getAction();
			if ( action == MotionEvent.ACTION_UP ) {
				onUp();
			}
		}

		return handled;
	}

	/** The m animation duration. */
	int mAnimationDuration = 400;
	
	/** The m child height. */
	int mMaxX, mMinX, mChildWidth, mChildHeight;
	
	/** The m should stop fling. */
	boolean mShouldStopFling;
	
	/** The m to left. */
	boolean mToLeft;
	
	/** The m current x. */
	int mCurrentX = 0;
	
	/** The m old x. */
	int mOldX = 0;
	
	/** The m touch slop. */
	int mTouchSlop;

	/**
	 * Scroll into slots.
	 */
	private void scrollIntoSlots() {
		if ( !mFlingRunnable.isFinished() ) {
			return;
		}
		
		//boolean greater_enough = mAdapter.getCount() * ( mChildWidth ) > getWidth();

		if ( mCurrentX > mMaxX || mCurrentX < mMinX ) {
			if ( mCurrentX > mMaxX ) {
				if( mMaxX < 0 ){
					mFlingRunnable.startUsingDistance( mCurrentX, mMinX - mCurrentX );
				} else {
					mFlingRunnable.startUsingDistance( mCurrentX, mMaxX - mCurrentX );
				}
				return;
			} else {
				mFlingRunnable.startUsingDistance( mCurrentX, mMinX - mCurrentX );
				return;
			}
		}
		onFinishedMovement();
	}

	/**
	 * On finished movement.
	 */
	protected void onFinishedMovement() {

	}

	/**
	 * The Class IFlingRunnable.
	 */
	abstract class IFlingRunnable implements Runnable {

		/** The m last fling x. */
		protected int mLastFlingX;

		/**
		 * Start common.
		 */
		protected void startCommon() {
			removeCallbacks( this );
		}

		/**
		 * Stop.
		 *
		 * @param scrollIntoSlots the scroll into slots
		 */
		public void stop( boolean scrollIntoSlots ) {
			removeCallbacks( this );
			endFling( scrollIntoSlots );
		}

		/**
		 * Start using distance.
		 *
		 * @param initialX the initial x
		 * @param distance the distance
		 */
		public void startUsingDistance( int initialX, int distance ) {
			if ( distance == 0 ) return;
			startCommon();
			mLastFlingX = initialX;
			_startUsingDistance( mLastFlingX, distance );
			post( this );
		}

		/**
		 * Start using velocity.
		 *
		 * @param initialX the initial x
		 * @param initialVelocity the initial velocity
		 */
		public void startUsingVelocity( int initialX, int initialVelocity ) {
			if ( initialVelocity == 0 ) return;
			startCommon();
			mLastFlingX = initialX;
			_startUsingVelocity( mLastFlingX, initialVelocity );
			post( this );
		}

		/**
		 * End fling.
		 *
		 * @param scrollIntoSlots the scroll into slots
		 */
		protected void endFling( boolean scrollIntoSlots ) {
			forceFinished( true );

			if ( scrollIntoSlots ) {
				scrollIntoSlots();
			}
		}

		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		@Override
		public void run() {
			mShouldStopFling = false;

			final boolean more = computeScrollOffset();
			int x = getCurrX();

			trackMotionScroll( x );

			if ( more && !mShouldStopFling ) {
				mLastFlingX = x;
				post( this );
			} else {
				endFling( true );
			}
		}

		/**
		 * Compute scroll offset.
		 *
		 * @return true, if successful
		 */
		protected abstract boolean computeScrollOffset();

		/**
		 * Gets the curr x.
		 *
		 * @return the curr x
		 */
		protected abstract int getCurrX();

		/**
		 * Force finished.
		 *
		 * @param finished the finished
		 */
		protected abstract void forceFinished( boolean finished );

		/**
		 * _start using velocity.
		 *
		 * @param initialX the initial x
		 * @param velocity the velocity
		 */
		protected abstract void _startUsingVelocity( int initialX, int velocity ); // private

		/**
		 * _start using distance.
		 *
		 * @param initialX the initial x
		 * @param distance the distance
		 */
		protected abstract void _startUsingDistance( int initialX, int distance ); // private

		/**
		 * Checks if is finished.
		 *
		 * @return true, if is finished
		 */
		public abstract boolean isFinished();
	}
	
	/**
	 * The Class Fling8Runnable.
	 */
	private class Fling8Runnable extends IFlingRunnable {

		/** The m scroller. */
		private Scroller mScroller;

		/**
		 * Instantiates a new fling8 runnable.
		 */
		public Fling8Runnable() {
			mScroller = new Scroller( getContext(), null);
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#isFinished()
		 */
		@Override
		public boolean isFinished() {
			return mScroller.isFinished();
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#_startUsingVelocity(int, int)
		 */
		@Override
		protected void _startUsingVelocity( int initialX, int velocity ) {
			mScroller.fling( initialX, 0, velocity, 0, mMinX, mMaxX, 0, Integer.MAX_VALUE );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#_startUsingDistance(int, int)
		 */
		@Override
		protected void _startUsingDistance( int initialX, int distance ) {
			mScroller.startScroll( initialX, 0, distance, 0, mAnimationDuration );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#forceFinished(boolean)
		 */
		@Override
		protected void forceFinished( boolean finished ) {
			mScroller.forceFinished( finished );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#computeScrollOffset()
		 */
		@Override
		protected boolean computeScrollOffset() {
			return mScroller.computeScrollOffset();
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#getCurrX()
		 */
		@Override
		protected int getCurrX() {
			return mScroller.getCurrX();
		}
	}

	/**
	 * The Class Fling9Runnable.
	 */
	private class Fling9Runnable extends IFlingRunnable {

		/** The m scroller. */
		private OverScroller mScroller;

		/**
		 * Instantiates a new fling9 runnable.
		 */
		public Fling9Runnable() {
			mScroller = new OverScroller( getContext(), null );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#isFinished()
		 */
		@Override
		public boolean isFinished() {
			return mScroller.isFinished();
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#_startUsingVelocity(int, int)
		 */
		@Override
		protected void _startUsingVelocity( int initialX, int velocity ) {
			mScroller.fling( initialX, 0, velocity, 0, mMinX, mMaxX, 0, Integer.MAX_VALUE, 10, 0 );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#_startUsingDistance(int, int)
		 */
		@Override
		protected void _startUsingDistance( int initialX, int distance ) {
			mScroller.startScroll( initialX, 0, distance, 0, mAnimationDuration );
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#computeScrollOffset()
		 */
		@Override
		protected boolean computeScrollOffset() {
			return mScroller.computeScrollOffset();
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#getCurrX()
		 */
		@Override
		protected int getCurrX() {
			return mScroller.getCurrX();
		}

		/* (non-Javadoc)
		 * @see com.aviary.android.feather.widget.HorizontialFixedListView.IFlingRunnable#forceFinished(boolean)
		 */
		@Override
		protected void forceFinished( boolean finished ) {
			mScroller.forceFinished( finished );
		}
	}

	/** The m gesture listener. */
	private OnGestureListener mGestureListener = new GestureDetector.SimpleOnGestureListener() {

		@Override
		public boolean onDoubleTap( MotionEvent e ) {
			return false;
		};

		@Override
		public boolean onDown( MotionEvent e ) {
			return HorizontialFixedListView.this.onDown( e );
		};

		@Override
		public boolean onFling( MotionEvent e1, MotionEvent e2, float velocityX, float velocityY ) {
			return HorizontialFixedListView.this.onFling( e1, e2, velocityX, velocityY );
		};

		@Override
		public void onLongPress( MotionEvent e ) {};

		@Override
		public boolean onScroll( MotionEvent e1, MotionEvent e2, float distanceX, float distanceY ) {
			return HorizontialFixedListView.this.onScroll( e1, e2, distanceX, distanceY );
		};

		@Override
		public void onShowPress( MotionEvent e ) {};

		@Override
		public boolean onSingleTapConfirmed( MotionEvent e ) {

			if ( !mFlingRunnable.isFinished() ) return false;

			Rect viewRect = new Rect();

			for ( int i = 0; i < getChildCount(); i++ ) {
				View child = getChildAt( i );
				int left = child.getLeft();
				int right = child.getRight();
				int top = child.getTop();
				int bottom = child.getBottom();
				viewRect.set( left, top, right, bottom );
				viewRect.offset( -mCurrentX, 0 );

				if ( viewRect.contains( (int) e.getX(), (int) e.getY() ) ) {
					if ( mOnItemClicked != null ) {
						mOnItemClicked.onItemClick( HorizontialFixedListView.this, child, mLeftViewIndex + 1 + i,
								mAdapter.getItemId( mLeftViewIndex + 1 + i ) );
					}
					if ( mOnItemSelected != null ) {
						mOnItemSelected.onItemSelected( HorizontialFixedListView.this, child, mLeftViewIndex + 1 + i,
								mAdapter.getItemId( mLeftViewIndex + 1 + i ) );
					}
					break;
				}
			}
			return true;
		}
	};
}
