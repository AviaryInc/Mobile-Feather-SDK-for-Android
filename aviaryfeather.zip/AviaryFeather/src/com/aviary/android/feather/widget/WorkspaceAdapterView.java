package com.aviary.android.feather.widget;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.Scroller;

import com.aviary.android.feather.library.log.Logger;

public class WorkspaceAdapterView extends AbsSpinner {

	public static interface OnPageChangeListener {
		void onPageChanged( int pageNum, int totalPages );
	};
	
	public static interface OnLayoutListener {
		void onLayout( boolean changed, int left, int top, int right, int bottom );		
	};

	static final String LOG_TAG = "workspace";

	private Scroller mScroller;
	private VelocityTracker mVelocityTracker;
	private WorkspaceInterpolator mScrollInterpolator;
	private WorkspaceIndicator mIndicator;
	private float mLastMotionX;
	private float mLastMotionY;
	private int mDefaultScreen;
	private int mCurrentScreen;
	private int mNextScreen = INVALID_POSITION;
	private int mTouchState = TOUCH_STATE_REST;
	private int mTouchSlop;
	private int mMaximumVelocity;
	private int mActivePointerId = INVALID_POINTER;
	private float mSmoothingTime;
	private float mTouchX;
	private boolean mFirstLayout = true;
	private OnPageChangeListener mPageChangeListener;
	private OnLayoutListener mLayoutListener;

	private static final int SNAP_VELOCITY = 300;
	private final static int TOUCH_STATE_REST = 0;
	private final static int TOUCH_STATE_SCROLLING = 1;
	private static final int INVALID_POINTER = -1;
	private static final float NANOTIME_DIV = 1000000000.0f;
	private static final float SMOOTHING_SPEED = 0.75f;
	private static final float SMOOTHING_CONSTANT = (float) (0.016 / Math.log( SMOOTHING_SPEED ));
	private static final float BASELINE_FLING_VELOCITY = 1500.f;
	private static final float FLING_VELOCITY_INFLUENCE = 0.4f;

	private View mSelectedChild;

	public WorkspaceAdapterView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		setHapticFeedbackEnabled( false );
		initWorkspace( context, attrs );
	}

	public static interface WorkspaceInterpolator extends Interpolator {

		void setDistance( float distance );

		void disableSettle();
	};

	private static class WorkspaceOvershootInterpolator implements WorkspaceInterpolator {

		private static final float DEFAULT_TENSION = 1.3f;
		@SuppressWarnings("unused")
		private float mTension;

		public WorkspaceOvershootInterpolator() {
			mTension = DEFAULT_TENSION;
		}

		@Override
		public void setDistance( float distance ) {
			mTension = distance > 0 ? DEFAULT_TENSION / distance : DEFAULT_TENSION;
		}

		@Override
		public void disableSettle() {
			mTension = 0.f;
		}

		@Override
		public float getInterpolation( float t ) {
			t -= 1.0f;
			// mTension /= 2.0f;
			// return t * t * ((mTension + 1) * t + mTension) + 1.0f;
			return 1.0f * (t * t * t + 1);
		}
	}

	public void setOnPageChangeListener( OnPageChangeListener listener ) {
		mPageChangeListener = listener;
	}
	
	public void setOnLayoutListener( OnLayoutListener listener ){
		mLayoutListener = listener;
	}

	@Override
	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		mPageChangeListener = null;
		mLayoutListener = null;
	}

	/**
	 * Initializes various states for this workspace.
	 * 
	 * @param attrs
	 * @param context2
	 */
	private void initWorkspace( Context context2, AttributeSet attrs ) {
		Context context = getContext();
		mScrollInterpolator = new WorkspaceOvershootInterpolator();
		mScroller = new Scroller( context, mScrollInterpolator );
		mCurrentScreen = mDefaultScreen;
		final ViewConfiguration configuration = ViewConfiguration.get( getContext() );
		mTouchSlop = configuration.getScaledTouchSlop();
		mMaximumVelocity = configuration.getScaledMaximumFlingVelocity();
	}

	public void setInterpolator( WorkspaceInterpolator interpolator ) {
		mScrollInterpolator = interpolator;
		mScroller = new Scroller( getContext(), mScrollInterpolator );
	}

	public void setIndicator( WorkspaceIndicator view ) {
		mIndicator = view;
		requestLayout();
	}

	public void onEggClick( View view, String tag ) {
	}

	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		Logger.info( this, "onLayout: " + changed + ", width: " + (right - left) + ", height: " + (bottom - top) );

		super.onLayout( changed, left, top, right, bottom );

		mInLayout = true;
		layout( 0, changed );
		mInLayout = false;

		if( true ) {
			if( mIndicator != null ) {
				mIndicator.setTotalScreens( mItemCount );
				mIndicator.setCurrentScreen( mCurrentScreen );
				mIndicator.hide( 0 );
				mIndicator.requestLayout();
			}
		}
		
		if( mLayoutListener != null ){
			mLayoutListener.onLayout( changed, left, top, right, bottom );
		}
	}

	@Override
	protected boolean checkLayoutParams( ViewGroup.LayoutParams p ) {
		return p instanceof LayoutParams;
	}

	@Override
	protected ViewGroup.LayoutParams generateLayoutParams( ViewGroup.LayoutParams p ) {
		return new LayoutParams( p );
	}

	@Override
	public ViewGroup.LayoutParams generateLayoutParams( AttributeSet attrs ) {
		return new LayoutParams( getContext(), attrs );
	}

	@Override
	protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
		return new LinearLayout.LayoutParams( ViewGroup.LayoutParams.FILL_PARENT, ViewGroup.LayoutParams.FILL_PARENT );
	}

	@Override
	int getChildHeight( View child ) {
		return child.getMeasuredHeight();
	}

	@Override
	public View getChildAt( int index ) {
		return super.getChildAt( index - mFirstPosition );
	}

	@Override
	protected boolean onRequestFocusInDescendants( int direction, Rect previouslyFocusedRect ) {
		int focusableScreen;
		if( mNextScreen != INVALID_POSITION ) {
			focusableScreen = mNextScreen;
		} else {
			focusableScreen = mCurrentScreen;
		}

		if( getChildAt( focusableScreen ) != null ) {
			getChildAt( focusableScreen ).requestFocus( direction, previouslyFocusedRect );
			return true;
		}
		return false;
	}

	@Override
	public void addFocusables( ArrayList<View> views, int direction, int focusableMode ) {
		if( true ) {
			getChildAt( mCurrentScreen ).addFocusables( views, direction );
			if( direction == View.FOCUS_LEFT ) {
				if( mCurrentScreen > 0 ) {
					getChildAt( mCurrentScreen - 1 ).addFocusables( views, direction );
				}
			} else if( direction == View.FOCUS_RIGHT ) {
				if( mCurrentScreen < getChildCount() - 1 ) {
					getChildAt( mCurrentScreen + 1 ).addFocusables( views, direction );
				}
			}

		}
	}

	@Override
	public boolean dispatchUnhandledMove( View focused, int direction ) {
		if( direction == View.FOCUS_LEFT ) {
			if( getCurrentScreen() > 0 ) {
				snapToScreen( getCurrentScreen() - 1 );
				return true;
			}
		} else if( direction == View.FOCUS_RIGHT ) {
			if( getCurrentScreen() < mItemCount - 1 ) {
				snapToScreen( getCurrentScreen() + 1 );
				return true;
			}
		}
		return super.dispatchUnhandledMove( focused, direction );
	}

	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		computeScroll();
	}

	@Override
	public boolean requestChildRectangleOnScreen( View child, Rect rectangle, boolean immediate ) {
		int screen = indexOfChild( child ) + mFirstPosition;
		if( screen != mCurrentScreen || !mScroller.isFinished() ) {
			snapToScreen( screen );
			return true;
		}
		return false;
	}

	public int getCurrentScreen() {
		return mCurrentScreen;
	}

	public int getItemCount() {
		return mItemCount;
	}

	@Override
	public void scrollTo( int x, int y ) {
		super.scrollTo( x, y );
		mTouchX = x;
		mSmoothingTime = System.nanoTime() / NANOTIME_DIV;

		if( mIndicator != null )
			mIndicator.scroll( x, getTotalWidth() );
	}

	@Override
	public void computeScroll() {

		if( mScroller.computeScrollOffset() ) {
			scrollTo( mScroller.getCurrX(), mScroller.getCurrY() );
			postInvalidate();
		} else if( mNextScreen != INVALID_POSITION ) {
			onFinishedAnimation( Math.max( 0, Math.min( mNextScreen, mItemCount - 1 ) ) );
		} else if( mTouchState == TOUCH_STATE_SCROLLING ) {
			final float now = System.nanoTime() / NANOTIME_DIV;
			final float e = (float) Math.exp( (now - mSmoothingTime) / SMOOTHING_CONSTANT );
			final float dx = mTouchX - getScrollX();
			scrollBy( (int) (dx * e), 0 );
			mSmoothingTime = now;

			// Keep generating points as long as we're more than 1px away from the
			// target
			if( dx > 1.f || dx < -1.f ) {
				postInvalidate();
			}
		}
	}

	@Override
	protected void dispatchDraw( Canvas canvas ) {
		boolean restore = false;
		int restoreCount = 0;

		boolean fastDraw = mTouchState != TOUCH_STATE_SCROLLING && mNextScreen == INVALID_POSITION;

		if( getChildCount() > 0 ) {
			if( fastDraw ) {
				drawChild( canvas, getChildAt( mCurrentScreen ), getDrawingTime() );
			} else {
				final long drawingTime = getDrawingTime();
				final float scrollPos = (float) getScrollX() / (getTotalWidth());
				final int leftScreen = (int) scrollPos;
				final int rightScreen = leftScreen + 1;
				if( leftScreen >= 0 ) {
					drawChild( canvas, getChildAt( leftScreen ), drawingTime );
				}
				if( scrollPos != leftScreen && rightScreen < mItemCount ) {
					drawChild( canvas, getChildAt( rightScreen ), drawingTime );
				}
			}
		}

		if( restore ) {
			canvas.restoreToCount( restoreCount );
		}
	}

	private void onFinishedAnimation( int newScreen ) {
		final boolean toLeft = newScreen > mCurrentScreen;
		final boolean toRight = newScreen < mCurrentScreen;
		final boolean changed = newScreen != mCurrentScreen;

		mCurrentScreen = newScreen;
		mNextScreen = INVALID_POSITION;
		clearChildrenCache();

		if( toLeft ) {
			fillToGalleryRight();
			detachOffScreenChildren( true );
		} else if( toRight ) {
			fillToGalleryLeft();
			detachOffScreenChildren( false );
		}

		// mRecycler.clear();

		if( changed ) {
			setSelectedPositionInt( newScreen );
			setNextSelectedPositionInt( newScreen );
			checkSelectionChanged();

			if( mPageChangeListener != null )
				mPageChangeListener.onPageChanged( newScreen, mItemCount );
		}
	}

	void snapToScreen( int whichScreen ) {
		snapToScreen( whichScreen, 0, false );

		if( mIndicator != null )
			mIndicator.show();
	}

	private void snapToScreen( int whichScreen, int velocity, boolean settle ) {
		whichScreen = Math.max( 0, Math.min( whichScreen, mItemCount - 1 ) );

		enableChildrenCache( mCurrentScreen, whichScreen );
		mNextScreen = whichScreen;

		View focusedChild = getFocusedChild();
		if( focusedChild != null && whichScreen != mCurrentScreen && focusedChild == getChildAt( mCurrentScreen ) ) {
			focusedChild.clearFocus();
		}

		final int screenDelta = Math.max( 1, Math.abs( whichScreen - mCurrentScreen ) );

		final int newX = getScreenScrollPositionX( whichScreen );
		final int delta = newX - getScrollX();
		int duration = (screenDelta + 1) * 100;

		if( !mScroller.isFinished() ) {
			mScroller.abortAnimation();
		}

		if( settle ) {
			mScrollInterpolator.setDistance( screenDelta );
		} else {
			mScrollInterpolator.disableSettle();
		}

		velocity = Math.abs( velocity );
		if( velocity > 0 ) {
			duration += (duration / (velocity / BASELINE_FLING_VELOCITY)) * FLING_VELOCITY_INFLUENCE;
		} else {
			duration += 100;
		}

		mScroller.startScroll( getScrollX(), 0, delta, 0, duration );

		if( mIndicator != null ) {
			mIndicator.setCurrentScreen( whichScreen );
			mIndicator.hide( duration );
		}

		invalidate();
	}

	private void detachOffScreenChildren( boolean toLeft ) {

		int numChildren = getChildCount();
		int start = 0;
		int count = 0;

		// detach from 0..current position
		if( toLeft ) {
			final int galleryLeft = getPaddingLeft() + getScreenScrollPositionX( mCurrentScreen );
			for( int i = 0; i < numChildren; i++ ) {
				final View child = super.getChildAt( i );
				if( child.getRight() >= galleryLeft ) {
					break;
				} else {
					count++;
					mRecycler.add( child );
				}
			}
		} else {
			final int galleryRight = getPaddingLeft() + getScreenScrollPositionX( mCurrentScreen + 1 );
			for( int i = numChildren - 1; i >= 0; i-- ) {
				final View child = super.getChildAt( i );
				if( child.getLeft() <= galleryRight ) {
					break;
				} else {
					start = i;
					count++;
					mRecycler.add( child );
				}
			}
		}

		if( count > 0 )
			detachViewsFromParent( start, count );

		if( toLeft && count != 0 ) {
			mFirstPosition += count;
		}
	}

	@Override
	public boolean onInterceptTouchEvent( MotionEvent ev ) {
		final int action = ev.getAction();
		if( (action == MotionEvent.ACTION_MOVE) && (mTouchState != TOUCH_STATE_REST) ) {
			return true;
		}

		acquireVelocityTrackerAndAddMovement( ev );

		switch( action & MotionEvent.ACTION_MASK ) {
			case MotionEvent.ACTION_MOVE: {
				final int pointerIndex = ev.findPointerIndex( mActivePointerId );
				final float x = ev.getX( pointerIndex );
				final float y = ev.getY( pointerIndex );
				final int xDiff = (int) Math.abs( x - mLastMotionX );
				final int yDiff = (int) Math.abs( y - mLastMotionY );

				final int touchSlop = mTouchSlop;
				boolean xMoved = xDiff > touchSlop;
				boolean yMoved = yDiff > touchSlop;

				if( xMoved || yMoved ) {

					if( xMoved ) {
						// Scroll if the user moved far enough along the X axis
						mTouchState = TOUCH_STATE_SCROLLING;
						mLastMotionX = x;
						mTouchX = getScrollX();
						mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
						enableChildrenCache( mCurrentScreen - 1, mCurrentScreen + 1 );
						mIndicator.show();
					}
				}
				break;
			}

			case MotionEvent.ACTION_DOWN: {
				final float x = ev.getX();
				final float y = ev.getY();
				// Remember location of down touch
				mLastMotionX = x;
				mLastMotionY = y;
				mActivePointerId = ev.getPointerId( 0 );

				mTouchState = mScroller.isFinished() ? TOUCH_STATE_REST : TOUCH_STATE_SCROLLING;
				break;
			}

			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP:
				clearChildrenCache();
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;

			case MotionEvent.ACTION_POINTER_UP:
				onSecondaryPointerUp( ev );
				break;
		}

		return mTouchState != TOUCH_STATE_REST;
	}

	@Override
	public void focusableViewAvailable( View focused ) {
		View current = getChildAt( mCurrentScreen );
		View v = focused;
		while( true ) {
			if( v == current ) {
				super.focusableViewAvailable( focused );
				return;
			}
			if( v == this ) {
				return;
			}
			ViewParent parent = v.getParent();
			if( parent instanceof View ) {
				v = (View) v.getParent();
			} else {
				return;
			}
		}
	}

	@Override
	public boolean onTouchEvent( MotionEvent ev ) {

		acquireVelocityTrackerAndAddMovement( ev );

		final int action = ev.getAction();

		switch( action & MotionEvent.ACTION_MASK ) {
			case MotionEvent.ACTION_DOWN:
				/*
				 * If being flinged and user touches, stop the fling. isFinished
				 * will be false if being flinged.
				 */
				if( !mScroller.isFinished() ) {
					mScroller.abortAnimation();
				}

				// Remember where the motion event started
				mLastMotionX = ev.getX();
				mActivePointerId = ev.getPointerId( 0 );
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					enableChildrenCache( mCurrentScreen - 1, mCurrentScreen + 1 );
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					// Scroll to follow the motion event
					final int pointerIndex = ev.findPointerIndex( mActivePointerId );
					final float x = ev.getX( pointerIndex );
					final float deltaX = mLastMotionX - x;
					mLastMotionX = x;

					if( deltaX < 0 ) {
						if( mTouchX > -(float) getTotalWidth() ) {
							// mTouchX += Math.max( -mTouchX, deltaX );
							mTouchX += deltaX;
							mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
							invalidate();
						}
					} else if( deltaX > 0 ) {
						final float availableToScroll = getScreenScrollPositionX( mItemCount ) - mTouchX;
						if( availableToScroll > 0 ) {
							mTouchX += Math.min( availableToScroll, deltaX );
							mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
							invalidate();
						}
					} else {
						// awakenScrollBars();
						mIndicator.show();
					}
				}
				break;
			case MotionEvent.ACTION_UP:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					final VelocityTracker velocityTracker = mVelocityTracker;
					velocityTracker.computeCurrentVelocity( 1000, mMaximumVelocity );
					int velocityX = 0;

					if( android.os.Build.VERSION.SDK_INT < 8 )
						velocityX = (int) velocityTracker.getXVelocity();
					else
						velocityX = (int) velocityTracker.getXVelocity( mActivePointerId );

					final int screenWidth = getTotalWidth();
					final int whichScreen = (getScrollX() + (screenWidth / 2)) / screenWidth;
					final float scrolledPos = (float) getScrollX() / screenWidth;

					if( velocityX > SNAP_VELOCITY && mCurrentScreen > 0 ) {
						final int bound = scrolledPos < whichScreen ? mCurrentScreen - 1 : mCurrentScreen;
						snapToScreen( Math.min( whichScreen, bound ), velocityX, true );
					} else if( velocityX < -SNAP_VELOCITY && mCurrentScreen < mItemCount - 1 ) {
						final int bound = scrolledPos > whichScreen ? mCurrentScreen + 1 : mCurrentScreen;
						snapToScreen( Math.max( whichScreen, bound ), velocityX, true );
					} else {
						snapToScreen( whichScreen, 0, true );
					}
				}
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;
			case MotionEvent.ACTION_CANCEL:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					final int screenWidth = getTotalWidth();
					final int whichScreen = (getScrollX() + (screenWidth / 2)) / screenWidth;
					snapToScreen( whichScreen, 0, true );
				}
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;
			case MotionEvent.ACTION_POINTER_UP:
				onSecondaryPointerUp( ev );
				break;
		}

		return true;
	}

	void clearChildrenCache() {
		final int count = getChildCount();
		for( int i = 0; i < count; i++ ) {
			final LinearLayout layout = (LinearLayout) super.getChildAt( i );

			if( layout != null )
				layout.setDrawingCacheEnabled( false );
			else
				Logger.error( this, "layout " + i + " is null!" );
		}
	}

	void enableChildrenCache( int fromScreen, int toScreen ) {
		if( fromScreen > toScreen ) {
			final int temp = fromScreen;
			fromScreen = toScreen;
			toScreen = temp;
		}

		final int count = getChildCount();

		fromScreen = Math.max( fromScreen, 0 );
		toScreen = Math.min( toScreen, count - 1 );

		for( int i = fromScreen; i <= toScreen; i++ ) {
			final LinearLayout layout = (LinearLayout) getChildAt( i );

			if( layout != null )
				layout.setDrawingCacheEnabled( true );
			else
				Logger.error( this, "layout " + i + " is null!" );
			// layout.setChildrenDrawnWithCacheEnabled( true );
			// layout.setChildrenDrawingCacheEnabled( true );
		}
	}

	private void acquireVelocityTrackerAndAddMovement( MotionEvent ev ) {
		if( mVelocityTracker == null ) {
			mVelocityTracker = VelocityTracker.obtain();
		}
		mVelocityTracker.addMovement( ev );
	}

	private void releaseVelocityTracker() {
		if( mVelocityTracker != null ) {
			mVelocityTracker.recycle();
			mVelocityTracker = null;
		}
	}

	private void onSecondaryPointerUp( MotionEvent ev ) {
		if( android.os.Build.VERSION.SDK_INT >= 8 ) {
			final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
			final int pointerId = ev.getPointerId( pointerIndex );
			if( pointerId == mActivePointerId ) {
				final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
				mLastMotionX = ev.getX( newPointerIndex );
				mLastMotionY = ev.getY( newPointerIndex );
				mActivePointerId = ev.getPointerId( newPointerIndex );
				if( mVelocityTracker != null ) {
					mVelocityTracker.clear();
				}
			}
		}
	}

	public void scrollLeft() {
		if( mScroller.isFinished() ) {
			if( mCurrentScreen > 0 )
				snapToScreen( mCurrentScreen - 1 );
		} else {
			if( mNextScreen > 0 )
				snapToScreen( mNextScreen - 1 );
		}
	}

	public void scrollRight() {
		if( mScroller.isFinished() ) {
			if( mCurrentScreen < mItemCount - 1 )
				snapToScreen( mCurrentScreen + 1 );
		} else {
			if( mNextScreen < mItemCount - 1 )
				snapToScreen( mNextScreen + 1 );
		}
	}

	@Override
	void layout( int delta, boolean changed ) {

		if( mDataChanged ) {
			handleDataChanged();
		}

		if( mItemCount == 0 ) {
			resetList();
			return;
		}

		// Update to the new selected position.
		if( mNextSelectedPosition >= 0 ) {
			setSelectedPositionInt( mNextSelectedPosition );
		}

		if( changed ) {

			if( mFirstLayout ) {
				recycleAllViews();
				detachAllViewsFromParent();

				mFirstPosition = mSelectedPosition;
				mCurrentScreen = mSelectedPosition;
				mNextScreen = INVALID_POSITION;

				makeAndAddView( mSelectedPosition, 0, getPaddingLeft(), true );

				fillToGalleryRight();
				fillToGalleryLeft();

				mRecycler.clear();
				mFirstLayout = false;
			}
		}

		if( changed )
			layoutChildren();
		
		invalidate();
		checkSelectionChanged();

		mDataChanged = false;
		mNeedSync = false;
		setNextSelectedPositionInt( mSelectedPosition );
		updateSelectedItemMetadata();
	}
	
	protected void layoutChildren() {

		int childCount = getChildCount();
		for( int i = 0; i < childCount; i++ ) {
			View child = super.getChildAt( i );
			layoutChild( child, child.getLeft(), true, child.getLayoutParams() );
		}
	}

	private void updateSelectedItemMetadata() {
		View oldSelectedChild = mSelectedChild;
		View child = mSelectedChild = getChildAt( mSelectedPosition );
		if( child == null ) {
			return;
		}

		//child.setSelected( true );
		child.setFocusable( true );

		if( hasFocus() ) {
			child.requestFocus();
		}

		if( oldSelectedChild != null ) {
			//oldSelectedChild.setSelected( false );
			oldSelectedChild.setFocusable( false );
		}
	}

	private int getTotalWidth() {
		return (getWidth() - (getPaddingLeft() + getPaddingRight()));
	}

	private int getScreenScrollPositionX( int screen ) {
		return (screen * getTotalWidth());
	}

	private void fillToGalleryRight() {
		int numChildren = getChildCount();
		int numItems = mItemCount;
		int galleryRight = getScreenScrollPositionX( mCurrentScreen + 2 );

		// Set state for initial iteration
		View lastView = super.getChildAt( numChildren - 1 );
		int curPosition;
		int curLeftEdge;

		if( lastView != null ) {
			curPosition = mFirstPosition + numChildren;
			curLeftEdge = lastView.getRight();
		} else {
			mFirstPosition = curPosition = mItemCount - 1;
			curLeftEdge = getPaddingLeft();
		}

		while( curLeftEdge < galleryRight && curPosition < numItems ) {
			lastView = makeAndAddView( curPosition, curPosition - mSelectedPosition, curLeftEdge, true );

			// Set state for next iteration
			curLeftEdge = lastView.getRight();
			curPosition++;
		}
	}

	private void fillToGalleryLeft() {
		int galleryLeft = getScreenScrollPositionX( mCurrentScreen - 1 );
		View lastView = super.getChildAt( 0 );
		int curPosition;
		int curRightEdge;

		if( lastView != null ) {
			curPosition = mFirstPosition - 1;
			curRightEdge = lastView.getLeft();
		} else {
			curPosition = 0;
			curRightEdge = getRight() - getLeft() - getPaddingRight();
		}

		while( curRightEdge > galleryLeft && curPosition >= 0 ) {
			lastView = makeAndAddView( curPosition, curPosition - mSelectedPosition, curRightEdge, false );

			// Remember some state
			mFirstPosition = curPosition;

			// Set state for next iteration
			curRightEdge = lastView.getLeft();
			curPosition--;
		}
	}

	private View makeAndAddView( int position, int offset, int x, boolean fromLeft ) {
		View child;

		if( !mDataChanged ) {
			child = mRecycler.remove();
			if( child != null ) {
				child = mAdapter.getView( position, child, this );
				setUpChild( child, offset, x, fromLeft );
				return child;
			}
		}
		child = mAdapter.getView( position, null, this );
		setUpChild( child, offset, x, fromLeft );
		return child;
	}

	private void setUpChild( View child, int offset, int x, boolean fromLeft ) {

		LayoutParams lp = (LayoutParams) child.getLayoutParams();
		if( lp == null ) {
			lp = generateDefaultLayoutParams();
		}

		addViewInLayout( child, fromLeft ? -1 : 0, lp );
		//child.setSelected( offset == 0 );
		layoutChild( child, x, fromLeft, lp );
	}

	private void layoutChild( View child, int x, boolean fromLeft, LayoutParams lp ) {

		int childHeightSpec = ViewGroup.getChildMeasureSpec( mHeightMeasureSpec, mSpinnerPadding.top + mSpinnerPadding.bottom,
				lp.height );
		int childWidthSpec = ViewGroup
				.getChildMeasureSpec( mWidthMeasureSpec, mSpinnerPadding.left + mSpinnerPadding.right, lp.width );

		child.measure( childWidthSpec, childHeightSpec );

		int childLeft;
		int childRight;

		int childTop = 0;
		int childBottom = childTop + child.getMeasuredHeight();

		int width = child.getMeasuredWidth();
		if( fromLeft ) {
			childLeft = x;
			childRight = childLeft + width;
		} else {
			childLeft = x - width;
			childRight = x;
		}

		child.layout( childLeft, childTop, childRight, childBottom );
		child.invalidate();
	}

	@Override
	void setSelectedPositionInt( int position ) {
		super.setSelectedPositionInt( position );
		updateSelectedItemMetadata();
	}
}
