package com.aviary.android.feather.widget;

import it.sephiroth.android.library.imagezoom.easing.Cubic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

class BrushHighlight {

	private View mContext;
	static final String LOG_TAG = ImageViewTouchBrush.LOG_TAG;
	List<Brush> mBrushes = Collections.synchronizedList( new ArrayList<Brush>() );

	BrushHighlight( View context ) {
		mContext = context;
	}

	public void addTouch( final float x, final float y, final long duration, final float startSize, final float endSize ) {
		if( mContext != null ) {

			Brush brush = new Brush( x, y, duration, startSize, endSize );

			synchronized( mBrushes ) {
				mBrushes.add( brush );
			}

			mContext.invalidate();
		}
	}

	public void clear() {
		mContext = null;
		mBrushes.clear();
	}

	protected void draw( Canvas canvas ) {

		boolean shouldInvalidate = false;

		synchronized( mBrushes ) {

			if( mBrushes.size() > 0 ) {
				shouldInvalidate = true;
				int i = mBrushes.size() - 1;
				while( i >= 0 ) {
					Brush brush = mBrushes.get( i );
					if( brush.mActive ) {
						brush.draw( canvas );
					} else {
						mBrushes.remove( i );
					}
					i--;
				}
			}
		}

		if( shouldInvalidate )
			mContext.invalidate();
	}

	class Brush {

		private Paint mPaint;
		private long mStartTime;
		private boolean mActive;
		private float mX, mY;
		private long mDurationMs;
		private float mStartSize;
		private float mEndSize;

		public Brush( float x, float y, long duration, float startSize, float endSize ) {
			mX = x;
			mY = y;
			mDurationMs = duration;
			mStartSize = startSize;
			mEndSize = endSize;
			mStartTime = System.currentTimeMillis();
			mActive = true;
			mPaint = new Paint( Paint.ANTI_ALIAS_FLAG );
			mPaint.setColor( Color.BLACK );
		}

		protected void draw( Canvas canvas ) {

			if( mActive ) {
				final long now = System.currentTimeMillis();
				final float currentMs = Math.min( mDurationMs, now - mStartTime );

				final float radius = mStartSize + Cubic.easeOut( currentMs, 0, mEndSize - mStartSize, mDurationMs );
				final float alpha = Cubic.easeOut( currentMs, 0.0f, 255.0f, mDurationMs );

				if( (now - mStartTime) > mDurationMs ) {
					mActive = false;
					return;
				}

				mPaint.setAlpha( 255 - (int) alpha );
				canvas.drawCircle( mX, mY, radius, mPaint );
			}
		}

	};
}
