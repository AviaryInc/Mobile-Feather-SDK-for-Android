package com.aviary.android.feather.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.aviary.android.feather.R;

public class EggView extends RelativeLayout {

	private ImageView mBgImage;
	private ImageView mIconImage;
	private TextView mTextView;

	private Typeface mTypeFace;
	private int mIconResourceId = -1;
	private int mLabelResourceId = -1;
	private int mToolImageId;
	private int mFilterImageId;

	private EGG_TYPE mType = EGG_TYPE.DEFAULT;

	public static enum EGG_TYPE {
		DEFAULT, GOLDEN_EGG,
	};

	public EggView( Context context, AttributeSet attrs, int defStyle ) {
		super( context, attrs, defStyle );
		init( context, attrs, defStyle );
	}

	public EggView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		init( context, attrs, 0 );
	}

	@Override
	public boolean onTouchEvent( MotionEvent event ) {
		switch( event.getAction() ) {
			case MotionEvent.ACTION_DOWN:
				mBgImage.setPressed( true );
				mTextView.setPressed( true );
				break;

			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP:
				mBgImage.setPressed( false );
				mTextView.setPressed( false );
				break;
		}
		return super.onTouchEvent( event );
	}

	public EGG_TYPE getType() {
		return mType;
	}

	public void setType( EGG_TYPE type ) {
		mType = type;

		if( type == EGG_TYPE.DEFAULT ) {
			mBgImage.setImageResource( mToolImageId );
		} else {
			mBgImage.setImageResource( mFilterImageId );
		}
	}

	public void setIcon( int resourceId ) {
		mIconResourceId = resourceId;
		mIconImage.setImageResource( resourceId );
	}
	
	public void setIcon( Drawable resource ) {
		mIconImage.setImageDrawable( resource );
	}
	
	public void setIcon( Bitmap resource ) {
		mIconImage.setImageBitmap( resource );
	}
	
	public ImageView getIcon()
	{
		return mIconImage;
	}

	public void setLabel( int resourceId ) {
		mLabelResourceId = resourceId;
		mTextView.setText( resourceId );
	}
	
	public void setLabel( String label )
	{
		mTextView.setText( label );
	}

	public void setTypeFace( Typeface value ) {
		mTypeFace = value;
		mTextView.setTypeface( value );
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();

		mIconImage = (ImageView) findViewById( R.id.egg_icon );
		mTextView = (TextView) findViewById( R.id.egg_text );
		mBgImage = (ImageView) findViewById( R.id.egg_image_bg );

		if( mIconResourceId > -1 )
			setIcon( mIconResourceId );

		if( mLabelResourceId > -1 )
			setLabel( mLabelResourceId );

		if( mTypeFace != null )
			setTypeFace( mTypeFace );

		setType( mType );
	}
	
	private void init( Context context, AttributeSet attrs, int defStyle ) {
		TypedArray a = getContext().obtainStyledAttributes( attrs, R.styleable.FeatherTheme, defStyle, 0 );
		LayoutInflater inflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
		inflater.inflate( R.layout.feather_egg_view, this );

		mType = EGG_TYPE.DEFAULT;
		String fontName = a.getString( R.styleable.FeatherTheme_tool_fontname );

		final int N = a.getIndexCount();
		for( int i = 0; i < N; i++ ) {

			int attr = a.getIndex( i );

			switch( attr ) {

				case R.styleable.FeatherTheme_tool_icon:
					mIconResourceId = a.getResourceId( attr, 0 );
					break;

				case R.styleable.FeatherTheme_tool_text:
					mLabelResourceId = a.getResourceId( attr, 0 );
					break;

				case R.styleable.FeatherTheme_tool_fontname:
					if( fontName.length() > 0 ){
						try {
							mTypeFace = Typeface.createFromAsset( context.getAssets(), fontName );
						} catch( Exception e ) {
							e.printStackTrace();
						}
					}
					break;

				case R.styleable.FeatherTheme_tool_filter_image:
					mFilterImageId = a.getResourceId( attr, R.drawable.egg_filter );
					break;

				case R.styleable.FeatherTheme_tool_default_image:
					mToolImageId = a.getResourceId( attr, R.drawable.egg_tool );
					break;

				case R.styleable.FeatherTheme_tool_type:
					int type = a.getInt( attr, 0 );
					if( type == 0 )
						mType = EGG_TYPE.DEFAULT;
					else
						mType = EGG_TYPE.GOLDEN_EGG;
					break;
			}
		}
		
		a.recycle();
	}
}
