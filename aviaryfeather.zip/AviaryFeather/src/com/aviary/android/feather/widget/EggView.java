package com.aviary.android.feather.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import com.aviary.android.feather.R;
import com.aviary.android.feather.library.log.LoggerFactory;
import com.aviary.android.feather.library.log.LoggerFactory.Logger;
import com.aviary.android.feather.library.log.LoggerFactory.LoggerType;

public class EggView extends RelativeLayout {

	private ImageView mBgImage;
	private ImageView mIconImage;
	private TextView mTextView;

	private Typeface mTypeFace;
	private int mIconResourceId = -1;
	private int mLabelResourceId = -1;
	private int mToolImageId;
	private int mFilterImageId;

	private EGG_TYPE mType;
	private EGG_TYPE mNextType;
	
	public static enum EGG_TYPE {
		DEFAULT, GOLDEN_EGG,
	};

	public EggView( Context context ) {
		super( context );
	}

	public EggView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		init( context, attrs, 0 );
	}

	public EggView( Context context, AttributeSet attrs, int defStyle ) {
		super( context, attrs, defStyle );
		init( context, attrs, defStyle );
	}
	
	@Override
	public void setDrawingCacheEnabled( boolean enabled ) {
		super.setDrawingCacheEnabled( enabled );
		Logger logger = LoggerFactory.getLogger( "EggView", LoggerType.ConsoleLoggerType );
		logger.info( "setDrawingCacheEnabled: " + enabled );
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();

		mIconImage = (ImageView) findViewById( R.id.egg_icon );
		mTextView = (TextView) findViewById( R.id.egg_text );
		mBgImage = (ImageView) findViewById( R.id.egg_image_bg );

		if ( mIconResourceId > 0 ) setIcon( mIconResourceId );
		if ( mLabelResourceId > 0 ) setLabel( mLabelResourceId );
		if ( mTypeFace != null ) setTypeFace( mTypeFace );

		setType( mNextType );
	}

	private void init( Context context, AttributeSet attrs, int defStyle ) {
		TypedArray a = getContext().obtainStyledAttributes( attrs, R.styleable.EggView, defStyle, 0 );

		String fontName = a.getString( R.styleable.EggView_fontName );
		mIconResourceId = a.getResourceId( R.styleable.EggView_icon, 0 );
		mLabelResourceId = a.getResourceId( R.styleable.EggView_text, 0 );
		mFilterImageId = a.getResourceId( R.styleable.EggView_filterImage, R.drawable.egg_filter );
		mToolImageId = a.getResourceId( R.styleable.EggView_toolImage, R.drawable.egg_tool );

		int type = a.getInt( R.styleable.EggView_toolType, 0 );
		if ( type == 0 )
			mNextType = EGG_TYPE.DEFAULT;
		else
			mNextType = EGG_TYPE.GOLDEN_EGG;

		if ( fontName != null ) {
			try {
				mTypeFace = Typeface.createFromAsset( context.getAssets(), fontName );
			} catch ( Exception e ) {
				e.printStackTrace();
			}
		}
		a.recycle();
	}

	public void setLabel( int resourceId ) {
		mLabelResourceId = resourceId;
		mTextView.setText( resourceId );
	}

	public void setLabel( String name ) {
		mTextView.setText( name );
	}

	public void setType( EGG_TYPE type ) {
		if ( type != mType ) {
			mType = type;

			if ( type == EGG_TYPE.DEFAULT ) {
				mBgImage.setImageResource( mToolImageId );
			} else {
				mBgImage.setImageResource( mFilterImageId );
			}
		}
	}

	public void setIcon( int resourceId ) {
		mIconResourceId = resourceId;
		mIconImage.setImageResource( resourceId );
	}

	public void setIcon( Drawable resource ) {
		mIconImage.setImageDrawable( resource );
	}

	public void setIcon( Bitmap resource ) {
		mIconImage.setImageBitmap( resource );
	}

	public void setTypeFace( Typeface value ) {
		mTypeFace = value;
		mTextView.setTypeface( value );
	}

	public ImageView getIcon() {
		return mIconImage;
	}

	@Override
	public boolean onTouchEvent( MotionEvent event ) {
		switch ( event.getAction() ) {
			case MotionEvent.ACTION_DOWN:
				mBgImage.setPressed( true );
				mTextView.setPressed( true );
				break;

			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP:
				mBgImage.setPressed( false );
				mTextView.setPressed( false );
				break;
		}
		return super.onTouchEvent( event );
	}
}
