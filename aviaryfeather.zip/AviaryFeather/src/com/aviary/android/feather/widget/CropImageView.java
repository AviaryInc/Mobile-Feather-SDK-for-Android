package com.aviary.android.feather.widget;

import it.sephiroth.android.library.imagezoom.IScaleGestureDetector;
import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import it.sephiroth.android.library.imagezoom.ScaleGestureDetector7;
import it.sephiroth.android.library.imagezoom.ScaleGestureDetector8;
import it.sephiroth.android.library.imagezoom.SimpleOnScaleGestureListener;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;

public class CropImageView extends ImageViewTouch {

	public interface OnLayoutListener {

		void onLayoutChanged( boolean changed, int left, int top, int right, int bottom );
	}

	public static final int GROW = 0;
	public static final int SHRINK = 1;
	private int mMotionEdge = HighlightView.GROW_NONE;
	private HighlightView mHighlightView;
	private OnLayoutListener mLayoutListener;
	private HighlightView mMotionHighlightView;

	@SuppressWarnings("unused")
	private boolean mMoved = false;
	private boolean mScaled = false;

	public CropImageView( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	@Override
	protected void init() {
		super.init();
		mGestureDetector = null;
		mScaleDetector = null;
		mGestureListener = null;
		mScaleListener = null;

		if( android.os.Build.VERSION.SDK_INT < 8 ) {
			mScaleDetector = new ScaleGestureDetector7( getContext(), new CropScaleListener() );
			mGestureDetector = new GestureDetector( getContext(), new CropGestureListener(), null );
		} else {
			mScaleDetector = new ScaleGestureDetector8( getContext(), new CropScaleListener() );
			mGestureDetector = new GestureDetector( getContext(), new CropGestureListener(), null, true );
		}

		mTouchSlop = 20 * 20;
	}

	public void setOnLayoutListener( OnLayoutListener listener ) {
		mLayoutListener = listener;
	}

	@Override
	public void setImageBitmapReset( Bitmap bitmap, boolean reset ) {
		mMotionHighlightView = null;
		super.setImageBitmapReset( bitmap, reset );
	}

	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		super.onLayout( changed, left, top, right, bottom );

		if( mLayoutListener != null )
			mLayoutListener.onLayoutChanged( changed, left, top, right, bottom );

		if( mBitmapDisplayed.getBitmap() != null ) {
			if( mHighlightView != null ) {
				mHighlightView.getMatrix().set( getImageMatrix() );
				mHighlightView.invalidate();
				if( mHighlightView.hasFocus() ) {
					//centerOnHighlightView( mHighlightView );
				}
			}
		}
	}

	public void centerOnHighlightView( HighlightView hv ) {
		Log.d( LOG_TAG, "centerOnHighlightView" );
		Rect drawRect = hv.getDrawRect();
		float width = drawRect.width();
		float height = drawRect.height();
		float thisWidth = getWidth();
		float thisHeight = getHeight();
		float z1 = thisWidth / width * .6F;
		float z2 = thisHeight / height * .6F;
		float zoom = Math.min( z1, z2 );
		zoom = zoom * this.getScale();
		zoom = Math.max( 1F, zoom );
		if( (Math.abs( zoom - getScale() ) / zoom) > .1 ) {
			float[] coordinates = new float[] { hv.getCropRectF().centerX(), hv.getCropRectF().centerY() };
			getImageMatrix().mapPoints( coordinates );
			zoomTo( zoom, coordinates[0], coordinates[1], 300F ); // CR: 300.0f.
		}
		ensureVisible( hv );
	}

	@Override
	protected void postTranslate( float deltaX, float deltaY ) {
		super.postTranslate( deltaX, deltaY );

		if( mHighlightView != null ) {

			if( getScale() != 1 ) {
				float[] mvalues = new float[9];
				getImageMatrix().getValues( mvalues );
				final float scale = mvalues[Matrix.MSCALE_X];
				mHighlightView.getCropRectF().offset( -deltaX / scale, -deltaY / scale );
			}

			mHighlightView.getMatrix().set( getImageMatrix() );
			mHighlightView.invalidate();
		}
	}

	@Override
	protected void postScale( float scale, float centerX, float centerY ) {
		if( mHighlightView != null ) {

			RectF cropRect = mHighlightView.getCropRectF();
			Rect rect1 = mHighlightView.getDisplayRect( getImageViewMatrix(), mHighlightView.getCropRectF() );

			super.postScale( scale, centerX, centerY );

			Rect rect2 = mHighlightView.getDisplayRect( getImageViewMatrix(), mHighlightView.getCropRectF() );

			float[] mvalues = new float[9];
			getImageViewMatrix().getValues( mvalues );
			final float currentScale = mvalues[Matrix.MSCALE_X];

			cropRect.offset( (rect1.left - rect2.left) / currentScale, (rect1.top - rect2.top) / currentScale );
			cropRect.right += -(rect2.width() - rect1.width()) / currentScale;
			cropRect.bottom += -(rect2.height() - rect1.height()) / currentScale;

			mHighlightView.getMatrix().set( getImageMatrix() );
			mHighlightView.getCropRectF().set( cropRect );
			mHighlightView.invalidate();
		} else {
			super.postScale( scale, centerX, centerY );
		}
	}

	private void ensureVisible( HighlightView hv ) {
		Rect r = hv.getDrawRect();
		int panDeltaX1 = Math.max( 0, getLeft() - r.left );
		int panDeltaX2 = Math.min( 0, getRight() - r.right );
		int panDeltaY1 = Math.max( 0, getTop() - r.top );
		int panDeltaY2 = Math.min( 0, getBottom() - r.bottom );
		int panDeltaX = panDeltaX1 != 0 ? panDeltaX1 : panDeltaX2;
		int panDeltaY = panDeltaY1 != 0 ? panDeltaY1 : panDeltaY2;

		Log.d( LOG_TAG, "ensureVisible. panDeltaX: " + panDeltaX + ", panDeltaY: " + panDeltaY );

		if( panDeltaX != 0 || panDeltaY != 0 ) {
			panBy( panDeltaX, panDeltaY );
		}
	}

	@Override
	protected void onDraw( Canvas canvas ) {
		super.onDraw( canvas );
		if( mHighlightView != null )
			mHighlightView.draw( canvas );
	}

	public void setHighlightView( HighlightView hv ) {
		if( mHighlightView != null ) {
			mHighlightView.dispose();
		}

		mMotionHighlightView = null;
		mHighlightView = hv;
		invalidate();
	}

	public HighlightView getHighlightView() {
		return mHighlightView;
	}

	@Override
	public boolean onTouchEvent( MotionEvent event ) {
		int action = event.getAction() & MotionEvent.ACTION_MASK;

		mScaleDetector.onTouchEvent( event );
		if( !mScaleDetector.isInProgress() )
			mGestureDetector.onTouchEvent( event );

		switch( action ) {
			case MotionEvent.ACTION_UP:

				if( mMotionHighlightView != null ) {
					if( mScaled == true )
						//centerOnHighlightView( mMotionHighlightView );
					mMotionHighlightView.setMode( HighlightView.Mode.None );
				}

				mMotionHighlightView = null;
				mMotionEdge = HighlightView.GROW_NONE;
				mMoved = false;
				mScaled = false;

				if( getScale() < 1f ) {
					zoomTo( 1f, 50 );
				}
				break;

		}

		return true;
	}

	static float distance( float x2, float y2, float x1, float y1 ) {
		return (float) Math.sqrt( Math.pow( x2 - x1, 2 ) + Math.pow( y2 - y1, 2 ) );
	}

	@Override
	protected float onDoubleTapPost( float scale, float maxZoom ) {
		return super.onDoubleTapPost( scale, maxZoom );
	}

	class CropGestureListener extends GestureDetector.SimpleOnGestureListener {

		@Override
		public boolean onDown( MotionEvent e ) {
			Log.d( LOG_TAG, "onDown" );

			mMoved = false;
			mScaled = false;
			mMotionHighlightView = null;
			HighlightView hv = mHighlightView;

			int edge = hv.getHit( e.getX(), e.getY() );
			if( edge != HighlightView.GROW_NONE ) {
				mMotionEdge = edge;
				mMotionHighlightView = hv;
				mMotionHighlightView.setMode( (edge == HighlightView.MOVE) ? HighlightView.Mode.Move : HighlightView.Mode.Grow );
			}
			return super.onDown( e );
		}

		@Override
		public boolean onSingleTapConfirmed( MotionEvent e ) {
			Log.d( LOG_TAG, "onSingleTapConfirmed" );
			mMoved = false;
			mScaled = false;
			mMotionHighlightView = null;
			return super.onSingleTapConfirmed( e );
		}

		@Override
		public boolean onSingleTapUp( MotionEvent e ) {
			Log.d( LOG_TAG, "onSingleTapUp" );
			mMoved = false;
			mScaled = false;
			mMotionHighlightView = null;
			return super.onSingleTapUp( e );
		}

		@Override
		public boolean onDoubleTap( MotionEvent e ) {
			if( mDoubleTapEnabled ) {
				Log.d( LOG_TAG, "onDoubleTap" );
				mMoved = false;
				mScaled = false;
				mMotionHighlightView = null;

				float scale = getScale();
				float targetScale = scale;
				targetScale = CropImageView.this.onDoubleTapPost( scale, getMaxZoom() );
				targetScale = Math.min( getMaxZoom(), Math.max( targetScale, 1 ) );
				mCurrentScaleFactor = targetScale;
				zoomTo( targetScale, e.getX(), e.getY(), 200 );
				// zoomTo( targetScale, e.getX(), e.getY() );
				invalidate();
			}
			return super.onDoubleTap( e );
		}

		@Override
		public boolean onScroll( MotionEvent e1, MotionEvent e2, float distanceX, float distanceY ) {
			if( e1 == null || e2 == null )
				return false;
			if( e1.getPointerCount() > 1 || e2.getPointerCount() > 1 )
				return false;
			if( mScaleDetector.isInProgress() )
				return false;

			if( mMotionHighlightView != null && mMotionEdge != HighlightView.GROW_NONE ) {
				mMoved = true;
				// mScaled = ( mMotionEdge != HighlightView.GROW_NONE && mMotionEdge
				// != HighlightView.MOVE );
				mMotionHighlightView.handleMotion( mMotionEdge, -distanceX, -distanceY );
				ensureVisible( mMotionHighlightView );
				return true;
			} else {
				scrollBy( -distanceX, -distanceY );
				invalidate();
				return true;
			}
		}

		@Override
		public boolean onFling( MotionEvent e1, MotionEvent e2, float velocityX, float velocityY ) {
			Log.d( LOG_TAG, "onFling" );
			if( e1.getPointerCount() > 1 || e2.getPointerCount() > 1 )
				return false;
			if( mScaleDetector.isInProgress() )
				return false;
			if( mMotionHighlightView != null )
				return false;

			float diffX = e2.getX() - e1.getX();
			float diffY = e2.getY() - e1.getY();

			if( Math.abs( velocityX ) > 800 || Math.abs( velocityY ) > 800 ) {
				scrollBy( diffX / 2, diffY / 2, 300 );
				invalidate();
			}
			return super.onFling( e1, e2, velocityX, velocityY );
		}
	}

	class CropScaleListener extends SimpleOnScaleGestureListener {

		@Override
		public boolean onScaleBegin( IScaleGestureDetector detector ) {
			return super.onScaleBegin( detector );
		}

		@Override
		public void onScaleEnd( IScaleGestureDetector detector ) {
			super.onScaleEnd( detector );
		}

		@Override
		public boolean onScale( IScaleGestureDetector detector ) {
			float targetScale = mCurrentScaleFactor * detector.getScaleFactor();
			if( true ) {
				targetScale = Math.min( getMaxZoom(), Math.max( targetScale, 1 ) );
				zoomTo( targetScale, detector.getFocusX(), detector.getFocusY() );
				mCurrentScaleFactor = Math.min( getMaxZoom(), Math.max( targetScale, 1 ) );
				mDoubleTapDirection = 1;
				invalidate();
			}
			return true;
		}
	}
}
