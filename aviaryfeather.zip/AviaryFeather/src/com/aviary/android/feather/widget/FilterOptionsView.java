package com.aviary.android.feather.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import com.aviary.android.feather.library.log.Logger;

public class FilterOptionsView extends LinearLayout {

	int mMinHeight;

	public FilterOptionsView( Context context ) {
		super( context );
	}

	public FilterOptionsView( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	public void setHeight( int value ){
		Logger.info( this, "setHeight: " + value );
		android.view.ViewGroup.LayoutParams params = getLayoutParams();
		params.height = value;
		setLayoutParams( params );
	}

	public int getMinimumHeight() {
		return mMinHeight;
	}

	@Override
	public void setMinimumHeight( int minHeight ) {
		Logger.info( this, "setMinimumHeight: " + minHeight );
		super.setMinimumHeight( minHeight );
		mMinHeight = minHeight;
		requestLayout();
	}

	public void onPanelClick( View v ) {

	}
}
