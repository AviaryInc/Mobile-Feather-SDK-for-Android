package com.aviary.android.feather.widget;

import java.util.ArrayList;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewParent;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.Scroller;

import com.aviary.android.feather.effects.EffectLoaderService.EffectEntry;
import com.aviary.android.feather.library.log.Logger;
import com.aviary.android.feather.widget.WorkspaceCellLayout.OnEggClickListener;

public class WorkspaceView extends LinearLayout implements OnEggClickListener {

	public static interface OnPageChangeListener {

		void onPageChanged( int pageNum, int totalPages );
	};

	public static interface OnLayoutChangeListener {

		void onLayoutChanged( boolean changed, int l, int t, int r, int b );
	};

	static final String LOG_TAG = "workspace";

	private Scroller mScroller;
	private VelocityTracker mVelocityTracker;
	private WorkspaceInterpolator mScrollInterpolator;
	private WorkspaceIndicator mIndicator;
	private float mLastMotionX;
	private float mLastMotionY;
	private int mDefaultScreen;
	private int mCurrentScreen;
	private int mNextScreen = INVALID_SCREEN;
	private int mTouchState = TOUCH_STATE_REST;
	private int mTouchSlop;
	private int mMaximumVelocity;
	private int mActivePointerId = INVALID_POINTER;
	private float mSmoothingTime;
	private float mTouchX;
	private boolean mFirstLayout;
	private OnEggClickListener mEggClickListener;
	private OnPageChangeListener mPageChangeListener;
	private OnLayoutChangeListener mLayoutChangeListener;

	private static final int INVALID_SCREEN = -1;
	private static final int SNAP_VELOCITY = 300;
	private final static int TOUCH_STATE_REST = 0;
	private final static int TOUCH_STATE_SCROLLING = 1;
	private static final int INVALID_POINTER = -1;
	private static final float NANOTIME_DIV = 1000000000.0f;
	private static final float SMOOTHING_SPEED = 0.75f;
	private static final float SMOOTHING_CONSTANT = (float) (0.016 / Math.log( SMOOTHING_SPEED ));
	private static final float BASELINE_FLING_VELOCITY = 500.f;
	private static final float FLING_VELOCITY_INFLUENCE = 0.4f;

	public WorkspaceView( Context context, AttributeSet attrs ) {
		super( context, attrs );
		setHapticFeedbackEnabled( false );
		initWorkspace( context, attrs );
	}

	public static interface WorkspaceInterpolator extends Interpolator {

		void setDistance( float distance );

		void disableSettle();
	};

	private static class WorkspaceOvershootInterpolator implements WorkspaceInterpolator {

		private static final float DEFAULT_TENSION = 1.3f;
		@SuppressWarnings("unused")
		private float mTension;

		public WorkspaceOvershootInterpolator() {
			mTension = DEFAULT_TENSION;
		}

		@Override
		public void setDistance( float distance ) {
			mTension = distance > 0 ? DEFAULT_TENSION / distance : DEFAULT_TENSION;
		}

		@Override
		public void disableSettle() {
			mTension = 0.f;
		}

		@Override
		public float getInterpolation( float t ) {
			t -= 1.0f;
			// mTension /= 2.0f;
			// return t * t * ((mTension + 1) * t + mTension) + 1.0f;
			return 1.0f * (t * t * t + 1);
		}
	}

	public void setOnEggClickListener( OnEggClickListener listener ) {
		mEggClickListener = listener;
	}

	public void setOnPageChangeListener( OnPageChangeListener listener ) {
		mPageChangeListener = listener;
	}

	public void setOnLayoutChangeListener( OnLayoutChangeListener listener ) {
		mLayoutChangeListener = listener;
	}

	@Override
	protected void onDetachedFromWindow() {
		super.onDetachedFromWindow();
		mEggClickListener = null;
		mPageChangeListener = null;
		mLayoutChangeListener = null;
	}

	/**
	 * Initializes various states for this workspace.
	 * 
	 * @param attrs
	 * @param context2
	 */
	private void initWorkspace( Context context2, AttributeSet attrs ) {
		Context context = getContext();
		mScrollInterpolator = new WorkspaceOvershootInterpolator();
		mScroller = new Scroller( context, mScrollInterpolator );
		mCurrentScreen = mDefaultScreen;
		final ViewConfiguration configuration = ViewConfiguration.get( getContext() );
		mTouchSlop = configuration.getScaledTouchSlop();
		mMaximumVelocity = configuration.getScaledMaximumFlingVelocity();
	}

	public void setInterpolator( WorkspaceInterpolator interpolator ) {
		mScrollInterpolator = interpolator;
		mScroller = new Scroller( getContext(), mScrollInterpolator );
	}

	@Override
	public void addView( View child, int index, android.view.ViewGroup.LayoutParams params ) {
		if( !(child instanceof WorkspaceCellLayout) ) {
			throw new IllegalArgumentException( "Only CellLayout is allowed here" );
		}

		((WorkspaceCellLayout) child).setOnEggClickListener( this );

		super.addView( child, index, params );
	}

	public void setIndicator( WorkspaceIndicator view ) {
		mIndicator = view;
		requestLayout();
	}

	public void onEggClick( View view, String tag ) {
		Logger.info( this, "onEggClick: " + tag );
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
	}

	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		int childLeft = 0;

		final int count = getChildCount();
		for( int i = 0; i < count; i++ ) {
			final View child = getChildAt( i );
			if( child.getVisibility() != View.GONE ) {
				final int childWidth = child.getMeasuredWidth();
				child.layout( childLeft, 0, childLeft + childWidth, child.getMeasuredHeight() );
				childLeft += childWidth;
			}
		}

		if( changed ) {
			mIndicator.setTotalScreens( getChildCount() );
			mIndicator.setCurrentScreen( 0 );
			mIndicator.hide( 0 );
		}

		if( mLayoutChangeListener != null ) {
			mLayoutChangeListener.onLayoutChanged( changed, left, top, right, bottom );
		}
	}

	@Override
	protected void onMeasure( int widthMeasureSpec, int heightMeasureSpec ) {
		super.onMeasure( widthMeasureSpec, heightMeasureSpec );

		final int width = MeasureSpec.getSize( widthMeasureSpec );

		// The children are given the same width and height as the workspace
		final int count = getChildCount();
		for( int i = 0; i < count; i++ ) {
			getChildAt( i ).measure( widthMeasureSpec, heightMeasureSpec );
		}

		if( mFirstLayout ) {
			setHorizontalScrollBarEnabled( false );
			scrollTo( mCurrentScreen * width, 0 );
			// setHorizontalScrollBarEnabled( true );
			mFirstLayout = false;
		}
	}

	@Override
	protected boolean onRequestFocusInDescendants( int direction, Rect previouslyFocusedRect ) {
		int focusableScreen;
		if( mNextScreen != INVALID_SCREEN ) {
			focusableScreen = mNextScreen;
		} else {
			focusableScreen = mCurrentScreen;
		}

		if( getChildAt( focusableScreen ) != null ) {
			getChildAt( focusableScreen ).requestFocus( direction, previouslyFocusedRect );
			return true;
		}
		return false;
	}

	@Override
	public void addFocusables( ArrayList<View> views, int direction, int focusableMode ) {
		if( true ) {
			getChildAt( mCurrentScreen ).addFocusables( views, direction );
			if( direction == View.FOCUS_LEFT ) {
				if( mCurrentScreen > 0 ) {
					getChildAt( mCurrentScreen - 1 ).addFocusables( views, direction );
				}
			} else if( direction == View.FOCUS_RIGHT ) {
				if( mCurrentScreen < getChildCount() - 1 ) {
					getChildAt( mCurrentScreen + 1 ).addFocusables( views, direction );
				}
			}

		}
	}

	@Override
	public boolean dispatchUnhandledMove( View focused, int direction ) {
		if( direction == View.FOCUS_LEFT ) {
			if( getCurrentScreen() > 0 ) {
				snapToScreen( getCurrentScreen() - 1 );
				return true;
			}
		} else if( direction == View.FOCUS_RIGHT ) {
			if( getCurrentScreen() < getChildCount() - 1 ) {
				snapToScreen( getCurrentScreen() + 1 );
				return true;
			}
		}
		return super.dispatchUnhandledMove( focused, direction );
	}

	@Override
	protected void onAttachedToWindow() {
		super.onAttachedToWindow();
		computeScroll();
	}

	@Override
	public boolean requestChildRectangleOnScreen( View child, Rect rectangle, boolean immediate ) {
		int screen = indexOfChild( child );
		if( screen != mCurrentScreen || !mScroller.isFinished() ) {
			snapToScreen( screen );
			return true;
		}
		return false;
	}

	boolean isDefaultScreenShowing() {
		return mCurrentScreen == mDefaultScreen;
	}

	public int getCurrentScreen() {
		return mCurrentScreen;
	}

	public int getTotalScreens() {
		return getChildCount();
	}

	void setCurrentScreen( int currentScreen ) {
		if( !mScroller.isFinished() )
			mScroller.abortAnimation();
		mCurrentScreen = Math.max( 0, Math.min( currentScreen, getChildCount() - 1 ) );

		scrollTo( mCurrentScreen * getWidth(), 0 );
		invalidate();
	}

	@Override
	public void scrollTo( int x, int y ) {
		super.scrollTo( x, y );
		mTouchX = x;
		mSmoothingTime = System.nanoTime() / NANOTIME_DIV;

		if( mIndicator != null )
			mIndicator.scroll( x, getWidth() );
	}

	@Override
	public void computeScroll() {
		if( mScroller.computeScrollOffset() ) {
			scrollTo( mScroller.getCurrX(), mScroller.getCurrY() );
			postInvalidate();
		} else if( mNextScreen != INVALID_SCREEN ) {
			mCurrentScreen = Math.max( 0, Math.min( mNextScreen, getChildCount() - 1 ) );
			mNextScreen = INVALID_SCREEN;
			clearChildrenCache();
		} else if( mTouchState == TOUCH_STATE_SCROLLING ) {
			final float now = System.nanoTime() / NANOTIME_DIV;
			final float e = (float) Math.exp( (now - mSmoothingTime) / SMOOTHING_CONSTANT );
			final float dx = mTouchX - getScrollX();
			scrollBy( (int) (dx * e), 0 );
			mSmoothingTime = now;

			// Keep generating points as long as we're more than 1px away from the
			// target
			if( dx > 1.f || dx < -1.f ) {
				postInvalidate();
			}
		}
	}

	@Override
	protected void dispatchDraw( Canvas canvas ) {
		boolean restore = false;
		int restoreCount = 0;

		boolean fastDraw = mTouchState != TOUCH_STATE_SCROLLING && mNextScreen == INVALID_SCREEN;

		if( getChildCount() > 0 ) {

			if( fastDraw ) {
				drawChild( canvas, getChildAt( mCurrentScreen ), getDrawingTime() );
			} else {
				final long drawingTime = getDrawingTime();
				final float scrollPos = (float) getScrollX() / getWidth();
				final int leftScreen = (int) scrollPos;
				final int rightScreen = leftScreen + 1;
				if( leftScreen >= 0 ) {
					drawChild( canvas, getChildAt( leftScreen ), drawingTime );
				}
				if( scrollPos != leftScreen && rightScreen < getChildCount() ) {
					drawChild( canvas, getChildAt( rightScreen ), drawingTime );
				}
			}
		}

		if( restore ) {
			canvas.restoreToCount( restoreCount );
		}
	}

	void snapToScreen( int whichScreen ) {
		snapToScreen( whichScreen, 0, false );

		if( mIndicator != null )
			mIndicator.show();
	}

	private void snapToScreen( int whichScreen, int velocity, boolean settle ) {
		whichScreen = Math.max( 0, Math.min( whichScreen, getChildCount() - 1 ) );
		enableChildrenCache( mCurrentScreen, whichScreen );

		mNextScreen = whichScreen;

		View focusedChild = getFocusedChild();
		if( focusedChild != null && whichScreen != mCurrentScreen && focusedChild == getChildAt( mCurrentScreen ) ) {
			focusedChild.clearFocus();
		}

		final int screenDelta = Math.max( 1, Math.abs( whichScreen - mCurrentScreen ) );
		final int newX = whichScreen * getWidth();
		final int delta = newX - getScrollX();
		int duration = (screenDelta + 1) * 100;

		if( !mScroller.isFinished() ) {
			mScroller.abortAnimation();
		}

		if( settle ) {
			mScrollInterpolator.setDistance( screenDelta );
		} else {
			mScrollInterpolator.disableSettle();
		}

		velocity = Math.abs( velocity );
		if( velocity > 0 ) {
			duration += (duration / (velocity / BASELINE_FLING_VELOCITY)) * FLING_VELOCITY_INFLUENCE;
		} else {
			duration += 100;
		}

		// awakenScrollBars( duration );

		mScroller.startScroll( getScrollX(), 0, delta, 0, duration );
		invalidate();

		if( mIndicator != null ) {
			mIndicator.setCurrentScreen( whichScreen );
			mIndicator.hide( duration );
		}

		if( mPageChangeListener != null )
			mPageChangeListener.onPageChanged( whichScreen, getTotalScreens() );
	}

	@Override
	public boolean onInterceptTouchEvent( MotionEvent ev ) {
		final int action = ev.getAction();
		if( (action == MotionEvent.ACTION_MOVE) && (mTouchState != TOUCH_STATE_REST) ) {
			return true;
		}

		acquireVelocityTrackerAndAddMovement( ev );

		switch( action & MotionEvent.ACTION_MASK ) {
			case MotionEvent.ACTION_MOVE: {
				final int pointerIndex = ev.findPointerIndex( mActivePointerId );
				final float x = ev.getX( pointerIndex );
				final float y = ev.getY( pointerIndex );
				final int xDiff = (int) Math.abs( x - mLastMotionX );
				final int yDiff = (int) Math.abs( y - mLastMotionY );

				final int touchSlop = mTouchSlop;
				boolean xMoved = xDiff > touchSlop;
				boolean yMoved = yDiff > touchSlop;

				if( xMoved || yMoved ) {

					if( xMoved ) {
						// Scroll if the user moved far enough along the X axis
						mTouchState = TOUCH_STATE_SCROLLING;
						mLastMotionX = x;
						mTouchX = getScrollX();
						mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
						enableChildrenCache( mCurrentScreen - 1, mCurrentScreen + 1 );
						mIndicator.show();
					}
				}
				break;
			}

			case MotionEvent.ACTION_DOWN: {
				final float x = ev.getX();
				final float y = ev.getY();
				// Remember location of down touch
				mLastMotionX = x;
				mLastMotionY = y;
				mActivePointerId = ev.getPointerId( 0 );

				mTouchState = mScroller.isFinished() ? TOUCH_STATE_REST : TOUCH_STATE_SCROLLING;
				break;
			}

			case MotionEvent.ACTION_CANCEL:
			case MotionEvent.ACTION_UP:
				clearChildrenCache();
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;

			case MotionEvent.ACTION_POINTER_UP:
				onSecondaryPointerUp( ev );
				break;
		}

		return mTouchState != TOUCH_STATE_REST;
	}

	@Override
	public void focusableViewAvailable( View focused ) {
		View current = getChildAt( mCurrentScreen );
		View v = focused;
		while( true ) {
			if( v == current ) {
				super.focusableViewAvailable( focused );
				return;
			}
			if( v == this ) {
				return;
			}
			ViewParent parent = v.getParent();
			if( parent instanceof View ) {
				v = (View) v.getParent();
			} else {
				return;
			}
		}
	}

	@Override
	public boolean onTouchEvent( MotionEvent ev ) {

		acquireVelocityTrackerAndAddMovement( ev );

		final int action = ev.getAction();

		switch( action & MotionEvent.ACTION_MASK ) {
			case MotionEvent.ACTION_DOWN:
				/*
				 * If being flinged and user touches, stop the fling. isFinished
				 * will be false if being flinged.
				 */
				if( !mScroller.isFinished() ) {
					mScroller.abortAnimation();
				}

				// Remember where the motion event started
				mLastMotionX = ev.getX();
				mActivePointerId = ev.getPointerId( 0 );
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					enableChildrenCache( mCurrentScreen - 1, mCurrentScreen + 1 );
				}
				break;
			case MotionEvent.ACTION_MOVE:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					// Scroll to follow the motion event
					final int pointerIndex = ev.findPointerIndex( mActivePointerId );
					final float x = ev.getX( pointerIndex );
					final float deltaX = mLastMotionX - x;
					mLastMotionX = x;

					if( deltaX < 0 ) {
						if( mTouchX > -(float) getWidth() ) {
							// mTouchX += Math.max( -mTouchX, deltaX );
							mTouchX += deltaX;
							mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
							invalidate();
						}
					} else if( deltaX > 0 ) {
						final float availableToScroll = getChildAt( getChildCount() - 1 ).getRight() - mTouchX;
						if( availableToScroll > 0 ) {
							mTouchX += Math.min( availableToScroll, deltaX );
							mSmoothingTime = System.nanoTime() / NANOTIME_DIV;
							invalidate();
						}
					} else {
						// awakenScrollBars();
						mIndicator.show();
					}
				}
				break;
			case MotionEvent.ACTION_UP:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					final VelocityTracker velocityTracker = mVelocityTracker;
					velocityTracker.computeCurrentVelocity( 1000, mMaximumVelocity );
					int velocityX = 0;

					if( android.os.Build.VERSION.SDK_INT < 8 )
						velocityX = (int) velocityTracker.getXVelocity();
					else
						velocityX = (int) velocityTracker.getXVelocity( mActivePointerId );

					final int screenWidth = getWidth();
					final int whichScreen = (getScrollX() + (screenWidth / 2)) / screenWidth;
					final float scrolledPos = (float) getScrollX() / screenWidth;

					if( velocityX > SNAP_VELOCITY && mCurrentScreen > 0 ) {
						final int bound = scrolledPos < whichScreen ? mCurrentScreen - 1 : mCurrentScreen;
						snapToScreen( Math.min( whichScreen, bound ), velocityX, true );
					} else if( velocityX < -SNAP_VELOCITY && mCurrentScreen < getChildCount() - 1 ) {
						final int bound = scrolledPos > whichScreen ? mCurrentScreen + 1 : mCurrentScreen;
						snapToScreen( Math.max( whichScreen, bound ), velocityX, true );
					} else {
						snapToScreen( whichScreen, 0, true );
					}
				}
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;
			case MotionEvent.ACTION_CANCEL:
				if( mTouchState == TOUCH_STATE_SCROLLING ) {
					final int screenWidth = getWidth();
					final int whichScreen = (getScrollX() + (screenWidth / 2)) / screenWidth;
					snapToScreen( whichScreen, 0, true );
				}
				mTouchState = TOUCH_STATE_REST;
				mActivePointerId = INVALID_POINTER;
				releaseVelocityTracker();
				break;
			case MotionEvent.ACTION_POINTER_UP:
				onSecondaryPointerUp( ev );
				break;
		}

		return true;
	}

	void clearChildrenCache() {
		final int count = getChildCount();
		for( int i = 0; i < count; i++ ) {
			final WorkspaceCellLayout layout = (WorkspaceCellLayout) getChildAt( i );
			layout.setChildrenDrawnWithCacheEnabled( false );
		}
	}

	void enableChildrenCache( int fromScreen, int toScreen ) {
		if( fromScreen > toScreen ) {
			final int temp = fromScreen;
			fromScreen = toScreen;
			toScreen = temp;
		}

		final int count = getChildCount();

		fromScreen = Math.max( fromScreen, 0 );
		toScreen = Math.min( toScreen, count - 1 );

		for( int i = fromScreen; i <= toScreen; i++ ) {
			final WorkspaceCellLayout layout = (WorkspaceCellLayout) getChildAt( i );

			layout.setChildrenDrawnWithCacheEnabled( true );
			layout.setChildrenDrawingCacheEnabled( true );
		}
	}

	private void acquireVelocityTrackerAndAddMovement( MotionEvent ev ) {
		if( mVelocityTracker == null ) {
			mVelocityTracker = VelocityTracker.obtain();
		}
		mVelocityTracker.addMovement( ev );
	}

	private void releaseVelocityTracker() {
		if( mVelocityTracker != null ) {
			mVelocityTracker.recycle();
			mVelocityTracker = null;
		}
	}

	private void onSecondaryPointerUp( MotionEvent ev ) {
		if( android.os.Build.VERSION.SDK_INT >= 8 ) {
			final int pointerIndex = (ev.getAction() & MotionEvent.ACTION_POINTER_INDEX_MASK) >> MotionEvent.ACTION_POINTER_INDEX_SHIFT;
			final int pointerId = ev.getPointerId( pointerIndex );
			if( pointerId == mActivePointerId ) {
				final int newPointerIndex = pointerIndex == 0 ? 1 : 0;
				mLastMotionX = ev.getX( newPointerIndex );
				mLastMotionY = ev.getY( newPointerIndex );
				mActivePointerId = ev.getPointerId( newPointerIndex );
				if( mVelocityTracker != null ) {
					mVelocityTracker.clear();
				}
			}
		}
	}

	public void scrollLeft() {
		if( mScroller.isFinished() ) {
			if( mCurrentScreen > 0 )
				snapToScreen( mCurrentScreen - 1 );
		} else {
			if( mNextScreen > 0 )
				snapToScreen( mNextScreen - 1 );
		}
	}

	public void scrollRight() {
		if( mScroller.isFinished() ) {
			if( mCurrentScreen < getChildCount() - 1 )
				snapToScreen( mCurrentScreen + 1 );
		} else {
			if( mNextScreen < getChildCount() - 1 )
				snapToScreen( mNextScreen + 1 );
		}
	}

	public int getScreenForView( View v ) {
		int result = -1;
		if( v != null ) {
			ViewParent vp = v.getParent();
			int count = getChildCount();
			for( int i = 0; i < count; i++ ) {
				if( vp == getChildAt( i ) ) {
					return i;
				}
			}
		}
		return result;
	}

	void moveToDefaultScreen( boolean animate ) {
		if( animate ) {
			snapToScreen( mDefaultScreen );
		} else {
			setCurrentScreen( mDefaultScreen );
		}
		getChildAt( mDefaultScreen ).requestFocus();
	}

	@Override
	public void onClick( EffectEntry tag ) {
		if( !isEnabled() )
			return;

		Logger.info( this, "onClick: " + tag );
		if( mEggClickListener != null )
			mEggClickListener.onClick( tag );
	}
}
