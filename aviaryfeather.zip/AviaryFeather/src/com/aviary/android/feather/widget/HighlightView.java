package com.aviary.android.feather.widget;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.view.View;

import com.aviary.android.feather.R;

public class HighlightView {

	@SuppressWarnings("unused")
	private static final String LOG_TAG = "hv";
	static final int GROW_NONE = 1 << 0;
	static final int GROW_LEFT_EDGE = 1 << 1;
	static final int GROW_RIGHT_EDGE = 1 << 2;
	static final int GROW_TOP_EDGE = 1 << 3;
	static final int GROW_BOTTOM_EDGE = 1 << 4;
	static final int MOVE = 1 << 5;
	private boolean mIsFocused;
	private boolean mHidden;
	private View mContext;

	enum Mode {
		None, Move, Grow
	}

	private Mode mMode = Mode.None;
	private Rect mDrawRect;
	private RectF mImageRect;
	private RectF mCropRect;
	private Matrix mMatrix;
	private boolean mMaintainAspectRatio = false;
	private float mInitialAspectRatio;
	private Drawable mResizeDrawableWidth;
	private Drawable mResizeDrawableHeight;
	private final Paint mOutlinePaint = new Paint();
	private final Paint mOutlineFill = new Paint();
	private int nofocus_color;
	private int focus_color;
	private int down_color;
	private int alpha_up = 102;
	private int alpha_down = 102;

	public HighlightView( View ctx ) {
		mContext = ctx;
		nofocus_color = mContext.getResources().getColor( R.color.highlight_nofocus );
		focus_color = mContext.getResources().getColor( R.color.highlight_focus );
		down_color = mContext.getResources().getColor( R.color.highlight_down );
	}

	private void init() {
		android.content.res.Resources resources = mContext.getResources();
		mResizeDrawableWidth = resources.getDrawable( R.drawable.camera_crop_width );
		mResizeDrawableHeight = resources.getDrawable( R.drawable.camera_crop_height );
	}

	public void dispose() {
		mContext = null;
	}

	public boolean hasFocus() {
		return mIsFocused;
	}

	public void setFocus( boolean f ) {
		mIsFocused = f;
	}

	public void setHidden( boolean hidden ) {
		mHidden = hidden;
	}

	protected void draw( Canvas canvas ) {
		if( mHidden )
			return;
		canvas.save();
		Path path = new Path();
		Path inverse = new Path();
		Rect viewDrawingRect = new Rect();
		mContext.getDrawingRect( viewDrawingRect );

		inverse.addRect( new RectF( viewDrawingRect ), Path.Direction.CW );
		inverse.addRect( new RectF( mDrawRect ), Path.Direction.CCW );
		if( !hasFocus() ) {
			mOutlinePaint.setColor( nofocus_color );
			mOutlineFill.setAlpha( alpha_up );
			canvas.drawRect( mDrawRect, mOutlinePaint );
			canvas.drawPath( inverse, mOutlineFill );
		} else {
			path.addRect( new RectF( mDrawRect ), Path.Direction.CW );

			mOutlinePaint.setColor( mMode != Mode.None ? down_color : focus_color );
			mOutlineFill.setAlpha( mMode != Mode.None ? alpha_down : alpha_up );
			canvas.clipPath( path, Region.Op.DIFFERENCE );
			canvas.restore();
			canvas.drawPath( path, mOutlinePaint );
			canvas.drawPath( inverse, mOutlineFill );
			if( mMode == Mode.Grow ) {
				int left = mDrawRect.left + 1;
				int right = mDrawRect.right + 1;
				int top = mDrawRect.top + 4;
				int bottom = mDrawRect.bottom + 3;
				if( mResizeDrawableWidth != null && mResizeDrawableHeight != null ) {
					int widthWidth = mResizeDrawableWidth.getIntrinsicWidth() / 2;
					int widthHeight = mResizeDrawableWidth.getIntrinsicHeight() / 2;
					int heightHeight = mResizeDrawableHeight.getIntrinsicHeight() / 2;
					int heightWidth = mResizeDrawableHeight.getIntrinsicWidth() / 2;
					int xMiddle = mDrawRect.left + ((mDrawRect.right - mDrawRect.left) / 2);
					int yMiddle = mDrawRect.top + ((mDrawRect.bottom - mDrawRect.top) / 2);
					mResizeDrawableWidth.setBounds( left - widthWidth, yMiddle - widthHeight, left + widthWidth, yMiddle + widthHeight );
					mResizeDrawableWidth.draw( canvas );
					mResizeDrawableWidth
							.setBounds( right - widthWidth, yMiddle - widthHeight, right + widthWidth, yMiddle + widthHeight );
					mResizeDrawableWidth.draw( canvas );
					mResizeDrawableHeight.setBounds( xMiddle - heightWidth, top - heightHeight, xMiddle + heightWidth, top
							+ heightHeight );
					mResizeDrawableHeight.draw( canvas );
					mResizeDrawableHeight.setBounds( xMiddle - heightWidth, bottom - heightHeight, xMiddle + heightWidth, bottom
							+ heightHeight );
					mResizeDrawableHeight.draw( canvas );
				}
			}
		}
	}

	public void setMode( Mode mode ) {
		if( mode != mMode ) {
			mMode = mode;
			mContext.invalidate();
		}
	}

	public int getHit( float x, float y ) {
		Rect r = computeLayout( false );
		final float hysteresis = 20F;
		int retval = GROW_NONE;
		boolean verticalCheck = (y >= r.top - hysteresis) && (y < r.bottom + hysteresis);
		boolean horizCheck = (x >= r.left - hysteresis) && (x < r.right + hysteresis);
		if( (Math.abs( r.left - x ) < hysteresis) && verticalCheck )
			retval |= GROW_LEFT_EDGE;
		if( (Math.abs( r.right - x ) < hysteresis) && verticalCheck )
			retval |= GROW_RIGHT_EDGE;
		if( (Math.abs( r.top - y ) < hysteresis) && horizCheck )
			retval |= GROW_TOP_EDGE;
		if( (Math.abs( r.bottom - y ) < hysteresis) && horizCheck )
			retval |= GROW_BOTTOM_EDGE;
		if( retval == GROW_NONE && r.contains( (int) x, (int) y ) )
			retval = MOVE;
		return retval;
	}

	void handleMotion( int edge, float dx, float dy ) {
		Rect r = computeLayout( false );
		if( edge == GROW_NONE ) {
			return;
		} else if( edge == MOVE ) {
			moveBy( dx * (mCropRect.width() / r.width()), dy * (mCropRect.height() / r.height()) );
		} else {
			if( ((GROW_LEFT_EDGE | GROW_RIGHT_EDGE) & edge) == 0 )
				dx = 0;
			if( ((GROW_TOP_EDGE | GROW_BOTTOM_EDGE) & edge) == 0 )
				dy = 0;
			// Convert to image space before sending to growBy().
			float xDelta = dx * (mCropRect.width() / r.width());
			float yDelta = dy * (mCropRect.height() / r.height());
			growBy( (((edge & GROW_LEFT_EDGE) != 0) ? -1 : 1) * xDelta, (((edge & GROW_TOP_EDGE) != 0) ? -1 : 1) * yDelta );
		}
	}

	void moveBy( float dx, float dy ) {
		Rect invalRect = new Rect( mDrawRect );
		mCropRect.offset( dx, dy );
		mCropRect.offset( Math.max( 0, mImageRect.left - mCropRect.left ), Math.max( 0, mImageRect.top - mCropRect.top ) );
		mCropRect.offset( Math.min( 0, mImageRect.right - mCropRect.right ), Math.min( 0, mImageRect.bottom - mCropRect.bottom ) );

		mDrawRect = computeLayout( false );

		invalRect.union( mDrawRect );
		invalRect.inset( -10, -10 );
		mContext.invalidate( invalRect );
	}

	void growBy( float dx, float dy ) {
		if( mMaintainAspectRatio ) {
			if( dx != 0 ) {
				dy = dx / mInitialAspectRatio;
			} else if( dy != 0 ) {
				dx = dy * mInitialAspectRatio;
			}
		}
		RectF r = new RectF( mCropRect );
		if( dx > 0F && r.width() + 2 * dx > mImageRect.width() ) {
			float adjustment = (mImageRect.width() - r.width()) / 2F;
			dx = adjustment;
			if( mMaintainAspectRatio ) {
				dy = dx / mInitialAspectRatio;
			}
		}
		if( dy > 0F && r.height() + 2 * dy > mImageRect.height() ) {
			float adjustment = (mImageRect.height() - r.height()) / 2F;
			dy = adjustment;
			if( mMaintainAspectRatio ) {
				dx = dy * mInitialAspectRatio;
			}
		}
		r.inset( -dx, -dy );
		final float widthCap = 25F;
		if( r.width() < widthCap ) {
			r.inset( -(widthCap - r.width()) / 2F, 0F );
		}
		float heightCap = mMaintainAspectRatio ? (widthCap / mInitialAspectRatio) : widthCap;
		if( r.height() < heightCap ) {
			r.inset( 0F, -(heightCap - r.height()) / 2F );
		}

		mCropRect.set( r );
		mDrawRect = computeLayout( true );
		mContext.invalidate();
	}

	private void adjustCropRect( RectF r ) {
		if( r.left < mImageRect.left ) {
			r.offset( mImageRect.left - r.left, 0F );
		} else if( r.right > mImageRect.right ) {
			r.offset( -(r.right - mImageRect.right), 0 );
		}

		if( r.top < mImageRect.top ) {
			r.offset( 0F, mImageRect.top - r.top );
		} else if( r.bottom > mImageRect.bottom ) {
			r.offset( 0F, -(r.bottom - mImageRect.bottom) );
		}

		if( r.width() > r.height() ) {
			if( r.width() > mImageRect.width() ) {
				if( r.left < mImageRect.left ) {
					r.left += mImageRect.left - r.left;
				}
				if( r.right > mImageRect.right ) {
					r.right += -(r.right - mImageRect.right);
				}
			}
		} else {
			if( r.height() > mImageRect.height() ) {
				if( r.top < mImageRect.top ) {
					r.top += mImageRect.top - r.top;
				}
				if( r.bottom > mImageRect.bottom ) {
					r.bottom += -(r.bottom - mImageRect.bottom);
				}
			}
		}

		if( mMaintainAspectRatio ) {
			if( mInitialAspectRatio >= 1 ) { // width > height
				final float dy = r.width() / mInitialAspectRatio;
				r.bottom = r.top + dy;
			} else { // height >= width
				final float dx = r.height() * mInitialAspectRatio;
				r.right = r.left + dx;
			}
		}

		r.sort();
	}

	private RectF adjustRealCropRect( Matrix matrix, RectF rect, RectF outsideRect ) {
		RectF r = new RectF( rect.left, rect.top, rect.right, rect.bottom );
		matrix.mapRect( r );

		float[] mvalues = new float[9];
		matrix.getValues( mvalues );
		final float scale = mvalues[Matrix.MSCALE_X];

		if( r.left < outsideRect.left )
			rect.offset( (outsideRect.left - r.left) / scale, 0 );
		else if( r.right > outsideRect.right )
			rect.offset( -(r.right - outsideRect.right) / scale, 0 );

		if( r.top < outsideRect.top )
			rect.offset( 0, (outsideRect.top - r.top) / scale );
		else if( r.bottom > outsideRect.bottom )
			rect.offset( 0, -(r.bottom - outsideRect.bottom) / scale );

		r = new RectF( rect.left, rect.top, rect.right, rect.bottom );
		matrix.mapRect( r );

		if( r.width() > outsideRect.width() ) {
			if( r.left < outsideRect.left )
				rect.left += (outsideRect.left - r.left) / scale;
			if( r.right > outsideRect.right )
				rect.right += -(r.right - outsideRect.right) / scale;
		}

		if( r.height() > outsideRect.height() ) {
			if( r.top < outsideRect.top )
				rect.top += (outsideRect.top - r.top) / scale;
			if( r.bottom > outsideRect.bottom )
				rect.bottom += -(r.bottom - outsideRect.bottom) / scale;
		}

		if( mMaintainAspectRatio ) {
			if( mInitialAspectRatio >= 1 ) { // width > height
				final float dy = rect.width() / mInitialAspectRatio;
				rect.bottom = rect.top + dy;
			} else { // height >= width
				final float dx = rect.height() * mInitialAspectRatio;
				rect.right = rect.left + dx;
			}
		}

		rect.sort();
		return rect;
	}

	public Rect computeLayout( boolean adjust ) {
		if( adjust ) {
			adjustCropRect( mCropRect );
			RectF cRect = new RectF( 0, 0, mContext.getWidth(), mContext.getHeight() );
			mCropRect = adjustRealCropRect( mMatrix, mCropRect, cRect );
		}

		return getDisplayRect( mMatrix, mCropRect );
	}

	protected Rect getDisplayRect( Matrix m, RectF supportRect ) {
		RectF r = new RectF( supportRect.left, supportRect.top, supportRect.right, supportRect.bottom );
		m.mapRect( r );
		return new Rect( Math.round( r.left ), Math.round( r.top ), Math.round( r.right ), Math.round( r.bottom ) );
	}

	public void invalidate() {
		mDrawRect = computeLayout( true );
	}

	public void setup( Matrix m, Rect imageRect, RectF cropRect, boolean maintainAspectRatio ) {
		mMatrix = new Matrix( m );
		mCropRect = cropRect;
		mImageRect = new RectF( imageRect );
		mMaintainAspectRatio = maintainAspectRatio;
		mInitialAspectRatio = mCropRect.width() / mCropRect.height();
		mDrawRect = computeLayout( true );
		mOutlinePaint.setStrokeWidth( 3F );
		mOutlinePaint.setStyle( Paint.Style.STROKE );
		mOutlinePaint.setAntiAlias( true );
		mOutlineFill.setColor( 0xFF000000 );
		mOutlineFill.setStyle( Paint.Style.FILL );
		mOutlineFill.setAntiAlias( true );
		mMode = Mode.None;
		init();
	}
	
	public void setAspectRatio( float value ){
		mInitialAspectRatio = value;
	}

	public void setMaintainAspectRatio( boolean value ) {
		mMaintainAspectRatio = value;
	}

	public void update( Matrix imageMatrix, Rect imageRect ) {
		mMatrix = new Matrix( imageMatrix );
		mImageRect = new RectF( imageRect );
		mDrawRect = computeLayout( true );
		mContext.invalidate();
	}

	public Matrix getMatrix() {
		return mMatrix;
	}

	public Rect getDrawRect() {
		return mDrawRect;
	}

	public RectF getCropRectF() {
		return mCropRect;
	}

	/**
	 * Returns the cropping rectangle in image space.
	 * 
	 * @return
	 */
	public Rect getCropRect() {
		return new Rect( (int) mCropRect.left, (int) mCropRect.top, (int) mCropRect.right, (int) mCropRect.bottom );
	}

}
