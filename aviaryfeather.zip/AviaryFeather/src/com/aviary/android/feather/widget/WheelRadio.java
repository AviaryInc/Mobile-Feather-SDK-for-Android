package com.aviary.android.feather.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.DrawFilter;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import com.aviary.android.feather.R;

// TODO: Auto-generated Javadoc
/**
 * The Class WheelRadio.
 */
public class WheelRadio extends View {

	/** The Constant LOG_TAG. */
	static final String LOG_TAG = "wheel-radio";

	/** The m shader. */
	Shader mShader;
	
	/** The m shader1. */
	Shader mShader1;
	
	/** The m indicator. */
	Bitmap mIndicator;
	
	/** The m paint. */
	Paint mPaint;
	
	/** The m fast. */
	DrawFilter mFast;
	
	/** The m padding left. */
	int mPaddingLeft = 10;
	
	/** The m padding right. */
	int mPaddingRight = 10;
	
	/** The m line tick size. */
	int mLineTickSize = 1;
	
	/** The m line big size. */
	int mLineBigSize = 3;

	/** The m small ticks count. */
	int mSmallTicksCount = 10;
	
	/** The m big ticks count. */
	int mBigTicksCount = 1;
	
	/** The m real rect. */
	Rect mRealRect;
	
	/** The m force layout. */
	boolean mForceLayout;

	/**
	 * Instantiates a new wheel radio.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 * @param defStyle the def style
	 */
	public WheelRadio( Context context, AttributeSet attrs, int defStyle ) {
		super( context, attrs, defStyle );
		init( context, attrs, defStyle );
	}

	/**
	 * Instantiates a new wheel radio.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 */
	public WheelRadio( Context context, AttributeSet attrs ) {
		this( context, attrs, -1 );
	}

	/**
	 * Instantiates a new wheel radio.
	 *
	 * @param context the context
	 */
	public WheelRadio( Context context ) {
		this( context, null );
	}

	/**
	 * Inits the.
	 *
	 * @param context the context
	 * @param attrs the attrs
	 * @param defStyle the def style
	 */
	private void init( Context context, AttributeSet attrs, int defStyle ) {
		mFast = new PaintFlagsDrawFilter( Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG, 0 );
		mPaint = new Paint( Paint.FILTER_BITMAP_FLAG );

		TypedArray a = context.obtainStyledAttributes( attrs, R.styleable.WheelRadio, defStyle, 0 );
		mSmallTicksCount = a.getInteger( R.styleable.WheelRadio_smallTicks, 25 ) - 1;
		mBigTicksCount = a.getInteger( R.styleable.WheelRadio_bigTicks, 5 ) - 1;
		a.recycle();
	}

	/**
	 * Sets the ticks number.
	 *
	 * @param value the value
	 * @param value2 the value2
	 */
	public void setTicksNumber( int value, int value2 ) {
		Log.i( LOG_TAG, "setTicksNumber: " + value + ", " + value2 );

		mSmallTicksCount = value;
		mBigTicksCount = value2;
		mForceLayout = true;
		requestLayout();
		postInvalidate();
	}

	/* (non-Javadoc)
	 * @see android.view.View#onLayout(boolean, int, int, int, int)
	 */
	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		super.onLayout( changed, left, top, right, bottom );

		int w = right - left;

		if ( w > 0 && changed || mForceLayout ) {
			mRealRect = new Rect( mPaddingLeft, 0, w - ( mPaddingRight ), bottom );
			Log.d( LOG_TAG, "real rect: " + mRealRect );
			mShader = new BitmapShader( makeBitmap2( w / mSmallTicksCount, bottom - top, mLineTickSize ), Shader.TileMode.REPEAT,
					Shader.TileMode.CLAMP );
			mShader1 = new BitmapShader( makeBitmap3( mRealRect.width() / mBigTicksCount, bottom - top, mLineBigSize ),
					Shader.TileMode.REPEAT, Shader.TileMode.CLAMP );
			mIndicator = makeIndicator( bottom - top, mLineBigSize );
			mForceLayout = false;
		}
	}

	/* (non-Javadoc)
	 * @see android.view.View#onDraw(android.graphics.Canvas)
	 */
	@Override
	protected void onDraw( Canvas canvas ) {
		super.onDraw( canvas );

		if ( mShader != null ) {
			canvas.setDrawFilter( mFast );

			int saveCount = canvas.save();
			canvas.translate( mPaddingLeft - mLineBigSize / 2, 0 );

			mPaint.setShader( mShader );
			canvas.drawRect( mRealRect, mPaint );

			mPaint.setShader( mShader1 );
			canvas.drawPaint( mPaint );

			mPaint.setShader( null );

			float w = (float) mRealRect.width() / 2;
			canvas.drawBitmap( mIndicator, ( w + ( w * mValue ) ), 0, mPaint );
			canvas.restoreToCount( saveCount );
		}
	}

	/** The m value. */
	float mValue = 0;

	/**
	 * Sets the value.
	 *
	 * @param value the new value
	 */
	public void setValue( float value ) {
		mValue = Math.min( Math.max( value, -1 ), 1 );
		postInvalidate();
	}

	/**
	 * Gets the value.
	 *
	 * @return the value
	 */
	public float getValue() {
		return mValue;
	}

	/**
	 * Make bitmap2.
	 *
	 * @param width the width
	 * @param height the height
	 * @param line_size the line_size
	 * @return the bitmap
	 */
	private static Bitmap makeBitmap2( int width, int height, int line_size ) {

		Log.d( LOG_TAG, "makeBitmap2: " + width + ", line_size: " + line_size );

		Bitmap bm = Bitmap.createBitmap( width, height, Bitmap.Config.ARGB_8888 );
		Canvas c = new Canvas( bm );

		int center_h = height * 2 / 3;

		Paint p = new Paint( Paint.ANTI_ALIAS_FLAG );
		p.setDither( true );

		p.setColor( 0xFF656565 );
		RectF rect = new RectF( 0, height - center_h, line_size, height - ( height - center_h ) );
		c.drawRect( rect, p );
		return bm;
	}

	/**
	 * Make bitmap3.
	 *
	 * @param width the width
	 * @param height the height
	 * @param line_size the line_size
	 * @return the bitmap
	 */
	private static Bitmap makeBitmap3( int width, int height, int line_size ) {

		Bitmap bm = Bitmap.createBitmap( width, height, Bitmap.Config.ARGB_8888 );
		Canvas c = new Canvas( bm );

		int center_h = height * 4 / 5;

		Paint p = new Paint( Paint.ANTI_ALIAS_FLAG );
		p.setDither( true );

		p.setColor( 0xFFb5b5b5 );
		RectF rect = new RectF( 0, height - center_h, line_size, height - ( height - center_h ) );
		c.drawRect( rect, p );
		return bm;
	}

	/**
	 * Make indicator.
	 *
	 * @param height the height
	 * @param line_size the line_size
	 * @return the bitmap
	 */
	private static Bitmap makeIndicator( int height, int line_size ) {

		Bitmap bm = Bitmap.createBitmap( line_size, height, Bitmap.Config.ARGB_8888 );
		Canvas c = new Canvas( bm );

		int center_h = height;

		Paint p = new Paint( Paint.ANTI_ALIAS_FLAG );
		p.setDither( true );

		p.setColor( 0xFF00bbff );
		RectF rect = new RectF( 0, height - center_h, line_size, height - ( height - center_h ) );
		c.drawRect( rect, p );
		return bm;
	}
}
