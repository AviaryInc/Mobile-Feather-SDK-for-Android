package com.aviary.android.feather.widget;

import it.sephiroth.android.library.imagezoom.IScaleGestureDetector;
import it.sephiroth.android.library.imagezoom.ImageViewTouch;
import it.sephiroth.android.library.imagezoom.OnScaleGestureListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.GestureDetector;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import com.aviary.android.feather.widget.DrawableHighlightView.Mode;

public class ImageViewDrawableOverlay extends ImageViewTouch {

	public interface OnLayoutListener {

		void onLayoutChanged( boolean changed, int left, int top, int right, int bottom );
	}

	public static interface OnDrawableEventListener {

		void onFocusChange( DrawableHighlightView newFocus, DrawableHighlightView oldFocus );
		void onDown( DrawableHighlightView view );
		void onMove( DrawableHighlightView view );
		void onClick( DrawableHighlightView view );
	};

	private int mMotionEdge = DrawableHighlightView.GROW_NONE;

	private List<DrawableHighlightView> mOverlayViews = new ArrayList<DrawableHighlightView>();
	private DrawableHighlightView mOverlayView;

	private OnLayoutListener mLayoutListener;
	private OnDrawableEventListener mDrawableListener;

	public ImageViewDrawableOverlay( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	@Override
	protected void init() {
		super.init();
		mTouchSlop = 20 * 20;
		mGestureDetector.setIsLongpressEnabled( false );
	}

	@Override
	protected OnGestureListener getGestureListener() {
		return new CropGestureListener();
	}

	@Override
	protected OnScaleGestureListener getScaleListener() {
		return new CropScaleListener();
	}

	public void setOnLayoutListener( OnLayoutListener listener ) {
		mLayoutListener = listener;
	}

	public void setOnDrawableEventListener( OnDrawableEventListener listener ) {
		mDrawableListener = listener;
	}

	@Override
	public void setImageBitmapReset( final Bitmap bitmap, final boolean reset, Matrix matrix ) {
		clearOverlays();
		super.setImageBitmapReset( bitmap, reset, matrix );
	}

	@Override
	protected void onLayout( boolean changed, int left, int top, int right, int bottom ) {
		super.onLayout( changed, left, top, right, bottom );

		if( mLayoutListener != null )
			mLayoutListener.onLayoutChanged( changed, left, top, right, bottom );

		if( mBitmapDisplayed.getBitmap() != null && changed ) {

			Iterator<DrawableHighlightView> iterator = mOverlayViews.iterator();
			while( iterator.hasNext() ) {
				DrawableHighlightView view = iterator.next();
				view.getMatrix().set( getImageMatrix() );
				view.invalidate();
			}
		}
	}

	@Override
	protected void postTranslate( float deltaX, float deltaY ) {
		Log.i( LOG_TAG, "postTranslate" );
		super.postTranslate( deltaX, deltaY );

		Iterator<DrawableHighlightView> iterator = mOverlayViews.iterator();
		while( iterator.hasNext() ) {
			DrawableHighlightView view = iterator.next();
			if( getScale() != 1 ) {
				float[] mvalues = new float[9];
				getImageMatrix().getValues( mvalues );
				final float scale = mvalues[Matrix.MSCALE_X];
				view.getCropRectF().offset( -deltaX / scale, -deltaY / scale );
			}

			view.getMatrix().set( getImageMatrix() );
			view.invalidate();
		}
	}

	@Override
	protected void postScale( float scale, float centerX, float centerY ) {
		Log.i( LOG_TAG, "postScale" );

		if( mOverlayViews.size() > 0 ) {
			Iterator<DrawableHighlightView> iterator = mOverlayViews.iterator();
			
			Matrix oldMatrix = new Matrix( getImageViewMatrix() );
			super.postScale( scale, centerX, centerY );
			
			while( iterator.hasNext() ) {
				DrawableHighlightView view = iterator.next();

				RectF cropRect = view.getCropRectF();
				RectF rect1 = view.getDisplayRect( oldMatrix, view.getCropRectF() );
				RectF rect2 = view.getDisplayRect( getImageViewMatrix(), view.getCropRectF() );

				float[] mvalues = new float[9];
				getImageViewMatrix().getValues( mvalues );
				final float currentScale = mvalues[Matrix.MSCALE_X];

				cropRect.offset( (rect1.left - rect2.left) / currentScale, (rect1.top - rect2.top) / currentScale );
				cropRect.right += -(rect2.width() - rect1.width()) / currentScale;
				cropRect.bottom += -(rect2.height() - rect1.height()) / currentScale;

				view.getMatrix().set( getImageMatrix() );
				view.getCropRectF().set( cropRect );
				view.invalidate();
			}
		} else {
			super.postScale( scale, centerX, centerY );
		}
	}

	private void ensureVisible( DrawableHighlightView hv ) {
		RectF r = hv.getDrawRect();
		int panDeltaX1 = (int) Math.max( 0, getLeft() - r.left );
		int panDeltaX2 = (int) Math.min( 0, getRight() - r.right );
		int panDeltaY1 = (int) Math.max( 0, getTop() - r.top );
		int panDeltaY2 = (int) Math.min( 0, getBottom() - r.bottom );
		int panDeltaX = panDeltaX1 != 0 ? panDeltaX1 : panDeltaX2;
		int panDeltaY = panDeltaY1 != 0 ? panDeltaY1 : panDeltaY2;

		if( panDeltaX != 0 || panDeltaY != 0 ) {
			panBy( panDeltaX, panDeltaY );
		}
	}

	@Override
	public void onDraw( Canvas canvas ) {
		super.onDraw( canvas );

		for( int i = 0; i < mOverlayViews.size(); i++ ) {
			mOverlayViews.get( i ).draw( canvas );
		}
	}

	public void clearOverlays() {
		setSelectedHighlightView( null );
		while( mOverlayViews.size() > 0 ) {
			DrawableHighlightView hv = mOverlayViews.remove( 0 );
			hv.dispose();
		}
		mOverlayView = null;
		mMotionEdge = DrawableHighlightView.GROW_NONE;
	}

	public boolean addHighlightView( DrawableHighlightView hv ) {
		for( int i = 0; i < mOverlayViews.size(); i++ ) {
			if( mOverlayViews.get( i ).equals( hv ) )
				return false;
		}
		mOverlayViews.add( hv );
		postInvalidate();
		return true;
	}
	
	public int getHighlightCount(){
		return mOverlayViews.size();
	}
	
	public DrawableHighlightView getHighlightViewAt( int index ){
		return mOverlayViews.get(index);
	}

	public boolean removeHightlightView( DrawableHighlightView view ) {
		for( int i = 0; i < mOverlayViews.size(); i++ ) {
			if( mOverlayViews.get( i ).equals( view ) ) {
				DrawableHighlightView hv = mOverlayViews.remove( i );
				if( hv.equals( mOverlayView ) ) {
					setSelectedHighlightView( null );
				}
				hv.dispose();
				return true;
			}
		}
		return false;
	}

	/**
	 * Return the current selected highlight view
	 * 
	 * @return
	 */
	public DrawableHighlightView getSelectedHighlightView() {
		return mOverlayView;
	}

	@Override
	public boolean onTouchEvent( MotionEvent event ) {
		int action = event.getAction() & MotionEvent.ACTION_MASK;

		mScaleDetector.onTouchEvent( event );

		if( !mScaleDetector.isInProgress() )
			mGestureDetector.onTouchEvent( event );

		switch( action ) {
			case MotionEvent.ACTION_UP:

				if( mOverlayView != null ) {
					mOverlayView.setMode( DrawableHighlightView.Mode.None );
				}
				mMotionEdge = DrawableHighlightView.GROW_NONE;

				if( getScale() < 1f ) {
					zoomTo( 1f, 50 );
				}
				break;
		}

		return true;
	}

	@Override
	protected float onDoubleTapPost( float scale, float maxZoom ) {
		return super.onDoubleTapPost( scale, maxZoom );
	}

	private DrawableHighlightView checkSelection( MotionEvent e ) {
		Iterator<DrawableHighlightView> iterator = mOverlayViews.iterator();
		DrawableHighlightView selection = null;
		while( iterator.hasNext() ) {
			DrawableHighlightView view = iterator.next();
			int edge = view.getHit( e.getX(), e.getY() );
			if( edge != DrawableHighlightView.GROW_NONE ) {
				selection = view;
			}
		}
		return selection;
	}
	
	public void setSelectedHighlightView( DrawableHighlightView newView ){
		
		final DrawableHighlightView oldView = mOverlayView;
		
		if( mOverlayView != null && !mOverlayView.equals( newView ) ){
			mOverlayView.setSelected( false );
		}
		
		if( newView != null ){
			newView.setSelected( true );
		}
		
		mOverlayView = newView;
		
		if( mDrawableListener != null ) {
			mDrawableListener.onFocusChange( newView, oldView );
		}
	}
	

	class CropGestureListener extends GestureDetector.SimpleOnGestureListener {
		
		@Override
		public boolean onDown( MotionEvent e ) {

			final DrawableHighlightView newSelection = checkSelection(e);
			setSelectedHighlightView( newSelection );

			if( mOverlayView != null ) {
				int edge = mOverlayView.getHit( e.getX(), e.getY() );
				if( edge != DrawableHighlightView.GROW_NONE ) {
					mMotionEdge = edge;
					mOverlayView
							.setMode( (edge == DrawableHighlightView.MOVE) ? DrawableHighlightView.Mode.Move
									: (edge == DrawableHighlightView.ROTATE ? DrawableHighlightView.Mode.Rotate
											: DrawableHighlightView.Mode.Grow) );
					if( mDrawableListener != null ) {
						mDrawableListener.onDown( mOverlayView );
					}
				}
			}
			return super.onDown( e );
		}

		@Override
		public boolean onSingleTapConfirmed( MotionEvent e ) {
			return super.onSingleTapConfirmed( e );
		}

		@Override
		public boolean onSingleTapUp( MotionEvent e ) {
			if( mOverlayView != null ) {

				int edge = mOverlayView.getHit( e.getX(), e.getY() );
				if( (edge & DrawableHighlightView.MOVE) == DrawableHighlightView.MOVE ) {
					if( mDrawableListener != null )
						mDrawableListener.onClick( mOverlayView );
					return true;
				}

				mOverlayView.setMode( Mode.None );
				setSelectedHighlightView( null );
			}

			return super.onSingleTapUp( e );
		}

		@Override
		public boolean onDoubleTap( MotionEvent e ) {
			
			if( !mDoubleTapEnabled ) return false;

			if( mOverlayView != null )
				mOverlayView.setMode( Mode.None );

			float scale = getScale();
			float targetScale = scale;
			targetScale = ImageViewDrawableOverlay.this.onDoubleTapPost( scale, getMaxZoom() );
			targetScale = Math.min( getMaxZoom(), Math.max( targetScale, 1 ) );
			mCurrentScaleFactor = targetScale;
			zoomTo( targetScale, e.getX(), e.getY(), 200 );
			invalidate();
			return super.onDoubleTap( e );
		}

		@Override
		public boolean onScroll( MotionEvent e1, MotionEvent e2, float distanceX, float distanceY ) {
			
			if( !mScrollEnabled ) return false;
			
			if( e1 == null || e2 == null )
				return false;
			if( e1.getPointerCount() > 1 || e2.getPointerCount() > 1 )
				return false;
			if( mScaleDetector.isInProgress() )
				return false;

			if( mOverlayView != null && mMotionEdge != DrawableHighlightView.GROW_NONE ) {
				mOverlayView.onMouseMove( mMotionEdge, e2, -distanceX, -distanceY );

				if( mDrawableListener != null ) {
					mDrawableListener.onMove( mOverlayView );
				}

				if( mMotionEdge == DrawableHighlightView.MOVE )
					ensureVisible( mOverlayView );
				return true;
			} else {
				scrollBy( -distanceX, -distanceY );
				invalidate();
				return true;
			}
		}

		@Override
		public boolean onFling( MotionEvent e1, MotionEvent e2, float velocityX, float velocityY ) {
			Log.i( LOG_TAG, "onFling" );
			
			if( !mScrollEnabled ) return false;
			
			if( e1.getPointerCount() > 1 || e2.getPointerCount() > 1 )
				return false;
			if( mScaleDetector.isInProgress() )
				return false;
			if( mOverlayView != null && mOverlayView.getMode() != Mode.None )
				return false;

			float diffX = e2.getX() - e1.getX();
			float diffY = e2.getY() - e1.getY();

			if( Math.abs( velocityX ) > 800 || Math.abs( velocityY ) > 800 ) {
				scrollBy( diffX / 2, diffY / 2, 300 );
				invalidate();
			}
			return super.onFling( e1, e2, velocityX, velocityY );
		}
	}

	class CropScaleListener extends ScaleListener {

		@Override
		public boolean onScaleBegin( IScaleGestureDetector detector ) {
			Log.i( LOG_TAG, "onScaleBegin" );
			if( !mScaleEnabled ) return false;
			return super.onScaleBegin( detector );
		}

		@Override
		public void onScaleEnd( IScaleGestureDetector detector ) {
			Log.i( LOG_TAG, "onScaleEnd" );
			if( !mScaleEnabled ) return;
			super.onScaleEnd( detector );
		}

		@Override
		public boolean onScale( IScaleGestureDetector detector ) {
			Log.i( LOG_TAG, "onScale" );
			if( !mScaleEnabled ) return false;
			return super.onScale( detector );
		}
	}
}
