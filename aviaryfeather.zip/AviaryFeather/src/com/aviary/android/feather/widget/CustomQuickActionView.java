package com.aviary.android.feather.widget;

import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.widget.LinearLayout;
import com.aviary.android.feather.R;

public class CustomQuickActionView extends QuickActionView {

	protected ViewGroup mTrack2;

	public CustomQuickActionView( View anchor, int contentView ) {
		super( anchor, contentView );
		mTrack2 = (ViewGroup) root.findViewById( R.id.tracks2 );
	}

	public static CustomQuickActionView Builder( View anchor, int contentView ) {
		return new CustomQuickActionView( anchor, contentView );
	}

	@Override
	protected void createActionList() {

		final int screenWidth = windowManager.getDefaultDisplay().getWidth();
		final int numItems = mAdapter.getCount();

		int rowsIndex = 0;
		int itemsIndex = 0;

		ViewGroup currentTrack = null;
		View view;
		ViewGroup parent = null;
		boolean needNewRow = true;

		for ( int i = 0; i < numItems; i++ ) {
			
			if( ( rowsIndex % ( numItems / 2 ) == 0 ) ){
				itemsIndex = 0;
			}

			if ( itemsIndex % mNumColumns == 0 && mNumColumns > 0 ) {
				needNewRow = true;
			}


			if ( needNewRow ) {
				parent = new LinearLayout( context );
				android.widget.LinearLayout.LayoutParams params = new LinearLayout.LayoutParams( LayoutParams.WRAP_CONTENT,
						LayoutParams.WRAP_CONTENT );
				params.weight = 1;
				parent.setLayoutParams( params );

				if ( currentTrack == null ) {
					currentTrack = mTrack;
				} else {
					if ( ( i + 1 ) > ( numItems / 2 ) ) currentTrack = mTrack2;
				}

				currentTrack.addView( parent );
			}

			view = mAdapter.getView( i, null, parent );
			view.setFocusable( true );
			view.setClickable( true );
			view.setOnClickListener( this );
			addActionView( view, parent );

			parent.measure( LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT );
			int padding = currentTrack.getPaddingLeft() + currentTrack.getPaddingRight();
			int parentWidth = parent.getMeasuredWidth() + padding;
			int childWidth = parentWidth / parent.getChildCount();

			needNewRow = false;
			if ( parentWidth + childWidth > screenWidth ) {
				mNumColumns = -1;
				needNewRow = true;
			}

			rowsIndex++;
			itemsIndex++;
		}
	}

	@Override
	protected int getChildIndex( View v ) {
		
		// linear layout parent of the clicked item
		ViewGroup parent = (ViewGroup) v.getParent();	 

		// it's the relative child index
		int index = getChildIndex( v, parent );
		int rowIndex = getRowIndex( parent, (ViewGroup)parent.getParent() );
		int totalIndex = index + rowIndex;
		
		ViewParent parentParent = parent.getParent();

		if ( parentParent == mTrack2 )
			return (mAdapter.getCount()/2) + totalIndex;
		else
			return totalIndex;
	}
}
