package com.aviary.android.feather.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

public class WorkspaceCellLayout extends LinearLayout {

	public WorkspaceCellLayout( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	@Override
	public void requestChildFocus( View child, View focused ) {
		super.requestChildFocus( child, focused );
		if( child != null ) {
			Rect r = new Rect();
			child.getDrawingRect( r );
			requestRectangleOnScreen( r );
		}
	}
	
	@Override
	protected void dispatchDraw( Canvas canvas ) {
		super.dispatchDraw( canvas );
	}
	
	@Override
	protected boolean drawChild( Canvas canvas, View child, long drawingTime ) {
		return super.drawChild( canvas, child, drawingTime );
	}
	
	@Override
	public void setDrawingCacheEnabled( boolean enabled ) {
		super.setDrawingCacheEnabled( enabled );
		setAlwaysDrawnWithCacheEnabled( enabled );
		setChildrenDrawingCacheEnabled( enabled );
		setAnimationCacheEnabled( enabled );
	}
}
