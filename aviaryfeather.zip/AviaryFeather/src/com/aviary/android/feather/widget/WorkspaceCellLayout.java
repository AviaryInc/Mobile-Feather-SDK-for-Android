package com.aviary.android.feather.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import com.aviary.android.feather.R;
import com.aviary.android.feather.effects.EffectLoaderService.EffectEntry;

public class WorkspaceCellLayout extends LinearLayout {

	public static interface OnEggClickListener {

		void onClick( EffectEntry tag );
	}

	private static final int MAX_CHILDREN = 4;
	private ViewGroup mCellContainer;
	private OnEggClickListener mListener;

	public WorkspaceCellLayout( Context context, AttributeSet attrs ) {
		super( context, attrs );
	}

	public void setOnEggClickListener( OnEggClickListener listener ) {
		mListener = listener;
	}

	@Override
	protected void onDetachedFromWindow() {
		mListener = null;
		super.onDetachedFromWindow();
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
		mCellContainer = (ViewGroup) findViewById( R.id.workspace_cell_container );

		for( int i = 0; i < mCellContainer.getChildCount(); i++ ) {
			View view = mCellContainer.getChildAt( i );
			view.setOnClickListener( new OnClickListener() {

				@Override
				public void onClick( View v ) {
					if( mListener != null ) {
						mListener.onClick( (EffectEntry) v.getTag() );
					}
				}
			} );
		}
	}

	public void addEggView( EggView child ) {
		// super.addView( child );
		mCellContainer.addView( child );
	}

	public EggView getEggAt( int index ) {
		return (EggView) mCellContainer.getChildAt( index );
	}

	public boolean isFull() {
		return mCellContainer.getChildCount() >= MAX_CHILDREN;
	}

	@Override
	public void requestChildFocus( View child, View focused ) {
		super.requestChildFocus( child, focused );
		if( child != null ) {
			Rect r = new Rect();
			child.getDrawingRect( r );
			requestRectangleOnScreen( r );
		}
	}

	@Override
	protected void setChildrenDrawnWithCacheEnabled( boolean enabled ) {
		super.setChildrenDrawnWithCacheEnabled( enabled );
	}

	@Override
	protected void setChildrenDrawingCacheEnabled( boolean enabled ) {
		final int count = getChildCount();
		for( int i = 0; i < count; i++ ) {
			final View view = getChildAt( i );
			view.setDrawingCacheEnabled( enabled );
			view.buildDrawingCache( true );
		}
	}

}
