package com.aviary.android.feather.widget;

import java.util.TimerTask;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Handler;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import com.aviary.android.feather.R;

public class WorkspaceIndicator extends RelativeLayout {

	private int mScreenCount = 0;
	private int mCurrentScreen;
	private View mImageView;
	private int mTotalWidth;
	private Animation mFadeOut;
	private boolean mUsePages;
	private boolean mAutoHide;
	private int mIndicatorResourceId;
	private LinearLayout mPageLayout;

	private Handler mHandler = new Handler();

	public WorkspaceIndicator( Context context, AttributeSet attrs ) {
		super( context, attrs );
		init( context, attrs );
	}

	@Override
	protected void onFinishInflate() {
		super.onFinishInflate();
	}

	private void init( Context context, AttributeSet attrs ) {

		LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );

		mFadeOut = AnimationUtils.loadAnimation( getContext(), R.anim.fade_out );
		mFadeOut.setAnimationListener( mFadeOutAnimListener );

		mUsePages = false;
		mIndicatorResourceId = R.layout.feather_workspace_indicator_layout;

		TypedArray a = context.obtainStyledAttributes( attrs, R.styleable.FeatherTheme );
		mUsePages = a.getBoolean( R.styleable.FeatherTheme_usePages, false );
		mIndicatorResourceId = a.getResourceId( R.styleable.FeatherTheme_layoutIndicator, -1 );
		mAutoHide = a.getBoolean( R.styleable.FeatherTheme_autoHide, true );
		
		a.recycle();
		

		if( mUsePages ) {
			mPageLayout = new LinearLayout( getContext() );
			mPageLayout.setOrientation( LinearLayout.HORIZONTAL );
			mPageLayout.setGravity( Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL );
			this.addViewInLayout( mPageLayout, -1, new LayoutParams( LayoutParams.FILL_PARENT, LayoutParams.FILL_PARENT ) );
		} else {
			mImageView = mInflater.inflate( mIndicatorResourceId, null );
			this.addView( mImageView );
		}

	}

	public void setTotalScreens( int childCount ) {
		if( mScreenCount != childCount ) {
			mScreenCount = childCount;
			mCurrentScreen = -1;

			if( mUsePages ) {
				LayoutInflater mInflater = (LayoutInflater) getContext().getSystemService( Context.LAYOUT_INFLATER_SERVICE );
				mPageLayout.removeAllViews();

				for( int i = 0; i < mScreenCount; i++ ) {
					View child = mInflater.inflate( mIndicatorResourceId, mPageLayout, false );
					LinearLayout.LayoutParams params = new LinearLayout.LayoutParams( LinearLayout.LayoutParams.WRAP_CONTENT,
							LinearLayout.LayoutParams.WRAP_CONTENT );
					mPageLayout.addView( child, -1, params );
					// image.setLayoutParams( new LinearLayout.LayoutParams(
					// android.widget.LinearLayout.LayoutParams.FILL_PARENT,
					// android.widget.LinearLayout.LayoutParams.FILL_PARENT ) );
					// mPageLayout.addView( image );
				}
			}
		}
		requestLayout();
	}

	@SuppressWarnings("unused")
	@Override
	protected void onLayout( boolean changed, int l, int t, int r, int b ) {

		mTotalWidth = r - l;
		final int mTotalHeight = b - t;
		LayoutParams params;

		super.onLayout( changed, l, t, r, b );

		if( mScreenCount > 0 ) {

			if( mUsePages ) {

				if( true ) {

					int margin = 3;
					int center_x = mTotalWidth / 2;
					int total_children_width = (mTotalHeight + margin) * (mPageLayout.getChildCount());
					int start_x = center_x - (total_children_width / 2);
					int width = mTotalHeight;
					int top = 0;
					int bottom = mTotalHeight;

					for( int i = 0; i < mPageLayout.getChildCount(); i++ ) {
						View view = mPageLayout.getChildAt( i );

						int left = start_x + (i * (mTotalHeight + margin));
						int right = left + mTotalHeight;

						view.layout( left, top, right, bottom );
						view.setEnabled( i == mCurrentScreen );
					}
				}

			} else {
				if( changed ) {
					params = (LayoutParams) mImageView.getLayoutParams();
					params.width = (mTotalWidth / mScreenCount) - (getPaddingLeft() + getPaddingRight());
					params.height = mTotalHeight;
					mImageView.setLayoutParams( params );
					mImageView.invalidate();
				}
			}
		}

		mPageLayout.requestLayout();
	}

	public void scroll( int x, int width ) {
		final float x1 = (((float) x / (float) width) * mTotalWidth);

		if( mUsePages ) {

		} else {
			scrollTo( (int) -(x1 / mScreenCount), 0 );
		}
	}

	public void setCurrentScreen( int pageNum ) {
		if( mUsePages ) {
			if( mPageLayout.getChildAt( mCurrentScreen ) != null ) {
				mPageLayout.getChildAt( mCurrentScreen ).setEnabled( false );
			}

			if( mPageLayout.getChildAt( pageNum ) != null ) {
				mPageLayout.getChildAt( pageNum ).setEnabled( true );
			}
		}
		mCurrentScreen = pageNum;
	}

	public void show() {
		//Logger.info( this, "show, autohide: " + mAutoHide + ", screens: " + mScreenCount );
		
		if( mScreenCount < 2 ) return;
		
		if( mAutoHide ) {
			mHandler.removeCallbacks( mFadeOutTimeTask );
			clearAnimation();
		}
		setVisibility( View.VISIBLE );
	}

	public void hide( long time ) {
		//Logger.info( this, "hide: " + time + ", autohide: " + mAutoHide + ", screens: " + mScreenCount );
		
		if( mScreenCount < 1 ) return;

		if( mScreenCount < 2 ){
			this.setVisibility( View.INVISIBLE );
			return;
		}
		
		if( mAutoHide ) {
			if( this.getVisibility() != View.INVISIBLE ){
				mHandler.removeCallbacks( mFadeOutTimeTask );
				mHandler.postDelayed( mFadeOutTimeTask, 1000 + time );
			}
		}
	}

	TimerTask mFadeOutTimeTask = new TimerTask() {

		@Override
		public void run() {
			WorkspaceIndicator.this.clearAnimation();
			WorkspaceIndicator.this.startAnimation( mFadeOut );
		}
	};

	AnimationListener mFadeOutAnimListener = new AnimationListener() {

		@Override
		public void onAnimationStart( Animation animation ) {
		}

		@Override
		public void onAnimationRepeat( Animation animation ) {
		}

		@Override
		public void onAnimationEnd( Animation animation ) {
			WorkspaceIndicator.this.setVisibility( View.INVISIBLE );
		}
	};
}
